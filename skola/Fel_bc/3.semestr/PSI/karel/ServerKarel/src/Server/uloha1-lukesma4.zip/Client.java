
import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author woxie alias Martin Lukes
 * zdroje: http://java.sun.com/reference/api/
 *
 */
public class Client {

    public static void main(String[] args) throws IOException {
        String nickname = "";                       //jmeno robota
         Socket echoSocket = new Socket(args[0],Integer.decode(args[1]));       //zalozeny socket
        PrintWriter out = null;                     //vystup
        BufferedReader in = null;                   //vstup
        String ip = args[0];         //ip adresa
        String incomingMessage = "";                //nactena zprava
        String outcomingCommand = "";               //posilana zprava
        Scanner sc=new Scanner(System.in);

        
        int commandCode = 0;                        //kod prichozi zpravy
        boolean automat = true;                     //moznost prepnout na automat
        int direction = -1;                         //smer(default 1)
        int x = 333, y = 0;                         //souradnice
        boolean skipRead = false;

       
      
        try {
            out = new PrintWriter(echoSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(
                    echoSocket.getInputStream()));
        } catch (UnknownHostException e) {
            System.err.println("Adresa : " + ip + " nenalezena.");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Data z " + ip + " nejsou citelna.");
            System.exit(1);
        }

        incomingMessage = readAndPrintIncomingMessage(in);
        nickname = getNick(incomingMessage);

        if (automat == false) {
            do {
                outcomingCommand = sc.nextLine();
                printAndSendCommand(nickname, outcomingCommand, out);    //zapsani prikazu bez nicku
                incomingMessage = readAndPrintIncomingMessage(in);
                commandCode = getCommandCode(incomingMessage);
            } while (!(commandCode == 221 || commandCode == 530 || commandCode == 550 || commandCode == 571 || commandCode == 572));
        } else {
            printAndSendCommand(nickname, "VLEVO", out);          //prvni prikaz = VLEVO
            incomingMessage = readAndPrintIncomingMessage(in);
            skipRead = true;
            commandCode = getCommandCode(incomingMessage);
            x = getPosition(x, y, incomingMessage)[0];
            y = getPosition(x, y, incomingMessage)[1];
            do {
                if (!skipRead) {
                    incomingMessage = readAndPrintIncomingMessage(in);
                    commandCode = getCommandCode(incomingMessage);
                } else {
                    skipRead = false;
                }
               switch (commandCode) {
                    case 570:
                        sendRepairCommand(nickname, incomingMessage, out);
                        break;

                    case 250:
                        if (incomingMessage.substring(incomingMessage.indexOf("(") + 1, incomingMessage.indexOf(",")).equals("0") && //dosel ke znacce
                                incomingMessage.substring(incomingMessage.indexOf(",") + 1, incomingMessage.indexOf(")")).equals("0")) {
                            printAndSendCommand(nickname, "ZVEDNI", out);
                        } else {
                            if (direction != -1) {
                                outcomingCommand = getActionCommand(incomingMessage, direction);
                                printAndSendCommand(nickname, outcomingCommand, out);
                                if (outcomingCommand.equals("VLEVO")) {
                                    direction = (direction + 1) % 4;
                                }
                                break;
                            } else {
                                outcomingCommand = "KROK";
                                printAndSendCommand(nickname, outcomingCommand, out);
                                incomingMessage = readAndPrintIncomingMessage(in);
                                commandCode = getCommandCode(incomingMessage);
                                if (commandCode != 570) {
                                    direction = getDirection(x, y, incomingMessage);
                                }
                                skipRead = true;
                            }
                        }
                }
            } while (!(commandCode == 221 || commandCode == 530 || commandCode == 550 || commandCode == 571 || commandCode == 572)); //dokud se nedostavi ukoncovaci prikaz

            out.close();
            in.close();                                         //vsechno se uzavre
            echoSocket.close();
        }
    }

    public static String getNick(String str) {            // ziskani prezdivky
        String callMe = "Oslovuj mne ";
        int count;                  //delka osloveni
        int j = 0;    // pom. pr. pro pruchod stringem
        boolean callMeFound = false;     //nalezeni stringu callMe
        while (true) {
            count = 0;
            for (int i = 0; j < str.length(); i++, j++) {
                if (callMe.charAt(i) != str.charAt(j)) {
                    i = -1;
                    if (str.charAt(j) == 'O') {
                        j--;
                    }
                }
                if (i + 1 == callMe.length()) {
                    callMeFound = true;
                    break;
                }
            }
            if (j + 1 == str.length()) {
                throw new IndexOutOfBoundsException();
            }
            if (callMeFound) {
                if (str.charAt(j + 1) == ' ') {
                    continue;
                }
                for (; j + count < str.length(); count++) {
                    if (str.charAt(count + j) == '.') {
                        break;
                    }
                }
                if (count < 8) {
                    continue;
                } else {
                    break;
                }
            }

        }
        return str.substring(j + 1, j + count);
    }

    public static String readLine(BufferedReader in) {   //nacteni radky
        String message = "";
        int countChars = 0;
        try {
            int incomingBit = 0;    //prichozi bit
            while (incomingBit != -1) {
                incomingBit = in.read();
                countChars++;
                if (countChars >= 512 * 1024) {
                    throw new IOException();
                }
                if (incomingBit == (int) '\r') {
                    incomingBit = in.read();
                    if (incomingBit == ((int) '\n')) {
                        break;
                    } else {
                        throw new Exception();
                    }
                } else {

                    message += (char) incomingBit;
                }
            }
        } catch (IOException e) {
            System.out.println("Je to moc dlouhy, sefe");
        } catch (Exception e) {
            System.out.println("Neco se pokazilo");
        }
        return message;
    }

    static void printAndSendCommand(String nickname, String command, PrintWriter out) {  //odeslani odpovedi serveru
        printAndSendCommand(nickname + " " + command, out);
    }

    static void printAndSendCommand(String outcomingCommand, PrintWriter out) {
        System.out.println(outcomingCommand);
        out.print(outcomingCommand + "\r\n");
        out.flush();
    }
 

    static String readAndPrintIncomingMessage(BufferedReader in) { // nacte a vytisknuti a zpracovani prichozi zpravy
        String incomingMessage = readLine(in);
        System.out.println(incomingMessage);
        return incomingMessage;
    }

       /*
     * vytiskne prichozi zpravu a dostane jeji kod
     */
    static int getCommandCode(String incomingMessage) {
        int commandCode = -1;
        try {
            commandCode = Integer.parseInt(incomingMessage.substring(0, incomingMessage.indexOf(" "))); //najde prikaz

        } catch (NumberFormatException e) {
            System.err.println("Chyba:Kod nebyl nalezen.");
        }
        return commandCode;
    }

    /* dostava jako parametr nickname, prichozi zpravu a Printwriter, ma odeslat opravovaci prikaz */
    static void sendRepairCommand(String nickname, String incomingMessage, PrintWriter out) {
        int porucha = (int) incomingMessage.charAt(incomingMessage.length() - 1) - (int) '0';
        printAndSendCommand(nickname, "OPRAVIT " + porucha, out);
    }
   
    public static String getActionCommand(String incomingMessage, int direction) {
        switch (direction) {
            case 0: {
                if (Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf(",") + 1, incomingMessage.indexOf(")"))) < 0) {
                    return "KROK";
                } else {
                    return "VLEVO";
                }
            }
            case 1: {
                if (Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf("(") + 1, incomingMessage.indexOf(","))) > 0) {
                    return "KROK";
                } else {
                    return "VLEVO";
                }
            }
            case 2: {
                if (Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf(",") + 1, incomingMessage.indexOf(")"))) > 0) {
                    return "KROK";
                } else {
                    return "VLEVO";
                }
            }
            case 3: {
                if (Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf("(") + 1, incomingMessage.indexOf(","))) < 0) {
                    return "KROK";
                } else {
                    return "VLEVO";
                }
            }
        }
        return "xxx";
    }

    public static int[] getPosition(int x, int y, String incomingMessage) {
        x = Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf("(") + 1, incomingMessage.indexOf(",")));
        y = Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf(",") + 1, incomingMessage.indexOf(")")));
        return new int[]{x, y};
    }

    public static int getDirection(int lastX, int lastY, String incomingMessage) {
        int direction = -1; //dir neni nastaven
        try {
            if (lastX == 333) {
                System.out.println("333");
                throw new Exception();
            }
            int x = Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf("(") + 1,
                    incomingMessage.indexOf(",")));
            int y = Integer.parseInt(incomingMessage.substring(incomingMessage.indexOf(",") + 1,
                    incomingMessage.indexOf(")")));
            if (lastX > x) {
                direction = 1;
            } else if (lastX < x) {
                direction = 3;
            } else if (lastY > y) {             //lastY > y a lastX = x
                direction = 2;
            } else if (lastY < y) {
                direction = 0;
            }
        } catch (Exception e) {
        }
        return direction;
    }
}
