#include "printWorld.h"

void printWorld(){
	printf("world!\n");
}
