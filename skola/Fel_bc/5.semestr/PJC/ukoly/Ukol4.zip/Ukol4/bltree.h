/* 
 * File:   bltree.h
 * Author: woxie aka Martin Lukes
 */


#include <cstddef>
#include <iostream>
using namespace std;
class AbstractNode{
public:
	static int countConstructors;
	AbstractNode * parent;
    
	AbstractNode(){
		countConstructors++;
		//cout << "volam konstruktor AbstractNode"<< endl;
		parent = NULL;
	}
	virtual void print()=0;
	virtual ~AbstractNode(){
		countConstructors--;
		//cout << "volam destructor AbstractNode " <<countConstructors<< endl;
    };
};

int AbstractNode::countConstructors=0;

class Leaf:public AbstractNode{
public:	
		static int CS;
        int _value;
        int count;
	Leaf(int value):AbstractNode(){
            count =1;
            _value = value;
			CS++;
			//cout << "Leaf konstruktor:" << _value << endl;
			
	}

    virtual ~Leaf(){
		CS--;
		//cout << "volam destruktor Leaf" << CS << endl;
	}

	virtual void print(){
		//cout << "("<<this->_value << "," <<this->count << "),";
	} 
};

int Leaf::CS = 0;

class InnerNode:public AbstractNode{
public:
	static int countInode;
    AbstractNode * left;
	AbstractNode * right;
        int leftMaximalBound;
        int rightMinimalBound;

	InnerNode():AbstractNode(){
		countInode++;
		left = NULL;
		right = NULL;
		//cout << "Volam InnerNode konstruktor "<<countInode << endl;
	}

	AbstractNode * getSecondSon(AbstractNode * son){
		if(this->left == son){
			return this->right;
		}
		if(this->right == son){
			return this->left;
		}
		return NULL;
	}

	virtual void print(){
	//cout << "(L"<<this->leftMaximalBound << ",R" << this->rightMinimalBound << "),";
	}

	void removeConnectionToChild(AbstractNode * child){
		if(child == ((InnerNode * )(this))->left){
			left = NULL;
		}

		if(child == ((InnerNode * )(this))->right){
			right = NULL;
		}

		child->parent = NULL;
	}

	void changeSonToNode(AbstractNode * son, AbstractNode * newSon){
		if(son!= left && son != right){
			return;
		}
		if(son == left){
			left = newSon;
		}else{
			right = newSon;
		}

		if(newSon != NULL){
			newSon->parent=this;
		}
		if(son!= NULL){
			son->parent = NULL;
		}
	}

        virtual ~InnerNode(){
			countInode--;
			//cout << "Volam destruktor InnerNode " << countInode <<"\n";
			//left->print();
			delete left;
            delete right;

	}
};

int InnerNode::countInode=0;

class BLTree {
private:
		int increaseCalled;
public:
	AbstractNode * root;
    BLTree(){
		root = NULL;
		increaseCalled = 0;
    }
	
	int getLeafDepth(int value, AbstractNode * temp, int &count){
		int depth = 0;
		//cout << "hloubka elementu:" << value<< endl;
		while(dynamic_cast<InnerNode *>(temp)  ){
			depth++;
            if(value <= ((InnerNode *)temp)->leftMaximalBound ){
                temp = ((InnerNode *)temp)->left;
            }else{        
				if(value >= ((InnerNode *)temp)->rightMinimalBound){
					temp = ((InnerNode *)temp)->right;
				} else{
					if( value > ((InnerNode *)temp)->leftMaximalBound && value < ((InnerNode *)temp)->rightMinimalBound){
						return -1;
					}
				}
			}

			//if(dynamic_cast<InnerNode *> (temp)) cout << "temp:L"<<((InnerNode *)temp) ->leftMaximalBound<< ",R" <<((InnerNode *)temp) ->rightMinimalBound << endl;
        }

		if(dynamic_cast<Leaf *> (temp)){
			count = dynamic_cast<Leaf *> (temp) ->count; 
		}
		
		if(value != ((Leaf *)temp )->_value){
			return -1;
		}
		return depth;
	}

	Leaf * getLeaf(int value){
		AbstractNode * temp = root;
		while(dynamic_cast<InnerNode *>(temp)  ){
            if(value <= ((InnerNode *)temp)->leftMaximalBound ){
                temp = ((InnerNode *)temp)->left;
            }else{        
				if(value >= ((InnerNode *)temp)->rightMinimalBound){
					temp = ((InnerNode *)temp)->right;
				}
			}
		}

		if(dynamic_cast<Leaf *> (temp))
		{
			if( ((Leaf *)temp)->_value == value){
				//cout << "get leaf\n";
				return (Leaf *)temp;
			}
		}
		return NULL;
	}

	Leaf * findLeafAndRepairParrents(int value, AbstractNode * node){
		AbstractNode * temp = node;
		while(dynamic_cast<InnerNode *>(temp)  ){
            if(value <= ((InnerNode *)temp)->leftMaximalBound ){
                temp = ((InnerNode *)temp)->left;
                continue;
            }        
            if(value >= ((InnerNode *)temp)->rightMinimalBound){
                temp = ((InnerNode *)temp)->right;
                continue;
            }
            
            if(value <= ((InnerNode *)temp)->leftMaximalBound + (((InnerNode *)temp)->rightMinimalBound - ((InnerNode *)temp)->leftMaximalBound) / 2){
                ((InnerNode *)temp)->leftMaximalBound = value;
                temp = ((InnerNode *)temp)->left;
                continue;
            } else{
                ((InnerNode *)temp)->rightMinimalBound = value;
                temp = ((InnerNode *)temp)->right;
                continue;
            }
        }


		//cout << "findVal" << ((Leaf *)temp)->_value << endl;
		return (Leaf *) temp;
	}

	void addLeafes(InnerNode * node, Leaf * firstLeaf, Leaf * secondLeaf ){
		//cout << firstLeaf->_value << "   " << secondLeaf ->_value << endl;
		if(firstLeaf->_value > secondLeaf->_value){
			node->left = secondLeaf;
			node->right	= firstLeaf;
			node->leftMaximalBound = secondLeaf->_value;
			node->rightMinimalBound = firstLeaf->_value;
		}else{
			node->left = firstLeaf;
			node->right	= secondLeaf;
			node->rightMinimalBound = secondLeaf->_value;
			node->leftMaximalBound = firstLeaf->_value;
		}
		//cout << "firstLeaf: " << firstLeaf->_value << "secondLeaf: " << secondLeaf->_value << endl;
		//cout << "InnerNode: L="<<node->leftMaximalBound << "  R=" << node->rightMinimalBound << endl;
		firstLeaf->parent = node;
		secondLeaf->parent = node;
	}

	void addValue(int value, Leaf * leaf){
		//cout << " Pred: nova hodnota: " << value << "  stara leafVal:" << leaf->_value<< endl;
		if( value == leaf ->_value ){
            (leaf->count)++;
			//cout << "current leaf value   "<< leaf->_value << "  count   "<< leaf->count << endl;
        } else{
			//cout << "leaf: "<< leaf->_value << "  val  " << value << endl;
            Leaf * newLeaf = new Leaf(value);
            InnerNode * newInnerNode = new InnerNode();
			if(leaf == root){
				root = newInnerNode;
			}
			newInnerNode->parent = leaf->parent;

			if(dynamic_cast<InnerNode *>(newInnerNode->parent)){
				((InnerNode *)newInnerNode->parent) ->changeSonToNode(leaf,newInnerNode);
			}
			addLeafes(newInnerNode, newLeaf, leaf);			 
        }		
	}

	//vlozeni elementu
    BLTree & operator <<(int value){
		if(root == NULL){
		    root = new Leaf(value);
            return *this;
        }
        AbstractNode * temp = root; 
		Leaf * leaf = this->findLeafAndRepairParrents(value, temp);

		//cout << ((Leaf *)temp)->_value << "temp value" << endl;
		//cout << leaf->_value << "LeafValue" << endl;
		this->addValue(value, leaf);
        return *this;
    }

	void increaseParentsUnusedInterval(AbstractNode * child, int value){
		increaseCalled++;
		if(increaseCalled == 200){
			cout << "fail";
		}
		 AbstractNode * node = child->parent;
		 if(((InnerNode *)node)->left == child){
            if(value < ((InnerNode *)node)->leftMaximalBound ){
                ((InnerNode *)node)->leftMaximalBound = value;
            }
        }else{
            if(value > ((InnerNode *)node)->rightMinimalBound){
                ((InnerNode *)node)->rightMinimalBound = value;
            }
        }
        if(! (node-> parent == NULL)){
			increaseParentsUnusedInterval(node ->parent,value);
        }
    }

	int getValueFromSibling(AbstractNode * sibling){
		if(dynamic_cast<Leaf *> (sibling)){
			return ( (Leaf *)sibling)->_value;
		}
		if(dynamic_cast<InnerNode *> (sibling)){
			if(((InnerNode *)(sibling->parent))->left == sibling){
				return ((InnerNode *)sibling)->rightMinimalBound;
			} else{
				return ((InnerNode *)sibling)->leftMaximalBound;
			}
		}
		return INT_MIN;
	}

	BLTree & operator >>(int value){
		Leaf * temp = getLeaf(value);
		
		//leaf s value nenalezen
		if(temp == NULL ){
			return *this;
		}

		//count je vic nez 1	
		if( temp-> count > 1 ){
			temp-> count--;
			return *this;
		} 
		
		//count je 1
		AbstractNode * tempParent = temp ->parent;
		

		if(tempParent == NULL){
			delete temp;
			root = NULL;
			return *this;
		}

		AbstractNode * grandParent = tempParent->parent;
		AbstractNode * tempSibling = ((InnerNode *)tempParent)->getSecondSon(temp);
		
		if(grandParent == NULL ) {
			((InnerNode *)tempParent)->removeConnectionToChild(tempSibling);
			root = tempSibling;
		}else{
				int newBound = getValueFromSibling(tempSibling);
				((InnerNode *)tempParent)->removeConnectionToChild(tempSibling);
				((InnerNode *)grandParent)->changeSonToNode(temp->parent, tempSibling);
				increaseParentsUnusedInterval(tempSibling,newBound);
		}
		delete tempParent;
			
		

		return * this;
    }

	//vypise hloubku elementu
    int operator[](int element){
		AbstractNode * temp = root;
		int i =0;
		int result = getLeafDepth(element, temp, i);
		return result;
    }

	//vypise pocet elementu v stromu
    int operator()(int element){
		AbstractNode * temp = root;
		int i=0;
		if(getLeafDepth(element, temp,i) != -1 ) {
			// tady by program spadl pri reseni pres dynamic_cast
			//Leaf* leaf = dynamic_cast<Leaf *>(temp);
			//cout << leaf ->count << endl;
			return i;
		}
		return -1;
    }

	void printTree(){
		//AbstractNode * node = root;
		//printNode(node);
		//cout << endl;
	}

	void printNode(AbstractNode * node){
		if(node == NULL) return;
		if(dynamic_cast<InnerNode *> (node)){
			printNode(((InnerNode *)node)->left);
			node->print();
			printNode(((InnerNode *)node)->right);
		}else{
			if(dynamic_cast<Leaf *> (node)){
				node->print();
			}
		}
	}

	virtual ~BLTree(){
		//cout << "volam destruktor BLTree\n";
		delete root;
	}

};
