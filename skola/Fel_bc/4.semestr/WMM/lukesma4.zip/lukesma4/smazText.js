// JavaScript Document
  function smazText(textArea){
        
  }
  
  function upozorneni(stranka)
{             
if(document.getElementById(stranka).value=='Váš vzkaz'){
   document.getElementById(stranka).value='';
}
}

