/* 
 * File:   square.cpp
 * Author: woxie
 *
 * Created on 12. říjen 2011, 23:53
 */

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
bool isIn(double x_A, double y_A, double length_A, double x_B, double y_B, double length_B);
double countDifference(double x_A, double y_A, double length_A, double x_B, double y_B, double length_B);
bool isBetween(double firstBound, double secondBound, double value);
void validInput(const istream & stream);
void printAndExit();
bool hasTogetherVertex(double x_A, double y_A, double length_A, double x_B, double y_B, double length_B);

int main(int argc, char** argv) {
    cout << "Zadejte delku hrany prvniho ctverce: ";
    double length_A, length_B, x_A, x_B, y_A, y_B;        
    cin >> length_A;
    validInput(cin);
    if(length_A < 0){
        printAndExit();
    }
    cout << "Zadejte x-ovou souradnici stredu prvniho ctverce: ";
    cin >> x_A;
    validInput(cin);
    cout << "Zadejte y-ovou souradnici stredu prvniho ctverce: ";
    cin >> y_A;
    validInput(cin);
    cout << "Zadejte delku hrany druheho ctverce: ";
    cin >> length_B;
    validInput(cin);
    if(length_B < 0){
        printAndExit();
    }
    cout << "Zadejte x-ovou souradnici stredu druheho ctverce: ";
    cin >> x_B;
    validInput(cin);
    cout << "Zadejte y-ovou souradnici stredu druheho ctverce: ";
    cin >> y_B;
    validInput(cin);
    
    double sum = length_A * length_A + length_B * length_B;
    if(!isIn(x_A, y_A, length_A, x_B, y_B, length_B)){
        cout << "Ctverce se ani nedotykaji." << endl;
    }else{
        sum -= countDifference(x_A, y_A, length_A, x_B, y_B, length_B);
        cout << "Obsah sjednoceni dvou ctvercu je " << sum << "." << endl;
    } 
    return 0;
}

bool isIn(double x_A, double y_A, double length_A, double x_B, double y_B, double length_B){
    double max_A_B = max(abs(x_A-x_B),abs(y_A-y_B));
    double length_2 = (length_A +length_B) /2;
    return max_A_B <= length_2;
}


double countDifference(double x_A, double y_A, double length_A, double x_B, double y_B, double length_B){
    double x1_a = x_A - (length_A)/2;
    double x2_a = x_A + (length_A)/2;
    double y1_a = y_A - (length_A)/2;
    double y2_a = y_A + (length_A)/2;
    
    double x1_b = x_B - (length_B)/2;
    double x2_b = x_B + (length_B)/2;
    double y1_b = y_B - (length_B)/2;
    double y2_b = y_B + (length_B)/2;
    
    double x1_diff = 0;
    double x2_diff = 0;
    double y1_diff = 0;
    double y2_diff = 0;
    if(isBetween(x1_a, x2_a, x1_b)){
        x1_diff = x1_b;
    }
    if(isBetween(x1_b, x2_b, x1_a)){
        x1_diff = x1_a;
    }
    
    if(isBetween(x1_a, x2_a, x2_b)){
        x2_diff = x2_b;
    }
    if(isBetween(x1_b, x2_b, x2_a)){
        x2_diff = x2_a;
    }
    
    if(isBetween(y1_a, y2_a, y1_b)){
        y1_diff = y1_b;
    }
    if(isBetween(y1_b, y2_b, y1_a)){
        y1_diff = y1_a;
    }
    
    if(isBetween(y1_a, y2_a, y2_b)){
        y2_diff = y2_b;
    }
    if(isBetween(y1_b, y2_b, y2_a)){
        y2_diff = y2_a;
    }
    
    return abs((y1_diff - y2_diff) * (x1_diff - x2_diff));
    
}

bool isBetween(double firstBound, double secondBound, double value){
    if((value >= firstBound && value <= secondBound)  || (value <= firstBound && value >= secondBound)){
        return true;
    }
    return false;
}

void validInput(const istream & stream){
    if(stream.bad() || stream.fail()){
        printAndExit();
    }
}

void printAndExit(){
    cout << "Spatny vstup." << endl;
    exit(0);
}
