/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CORE;

/**
 *
 * @author sprinkler
 */
public class PlayerDataException extends Exception{

    public PlayerDataException(String message) {
        super(message);
    }

}
