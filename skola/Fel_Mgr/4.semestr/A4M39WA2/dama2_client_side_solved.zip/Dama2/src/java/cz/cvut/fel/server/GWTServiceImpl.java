/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.cvut.fel.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import cz.cvut.fel.client.GWTService;

/**
 *
 * @author xklima
 */
public class GWTServiceImpl extends RemoteServiceServlet implements GWTService {
    public String myMethod(String s) {
        // Do something interesting with 's' here on the server.
        return "Server says: " + s;
    }
}
