#include <iostream.h>
#include <iomanip.h>

int main ( int argc, char * argv [] )
 {
   cout << "Hello world !" << endl;   
   return ( 0 );
 }
