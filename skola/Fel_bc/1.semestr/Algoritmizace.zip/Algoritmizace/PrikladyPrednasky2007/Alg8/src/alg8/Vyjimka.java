package alg8;
import java.io.*;
import java.util.*;
class Vyjimka {
  static FileInputStream vstup() {
   Scanner sc = new Scanner(System.in);
   for (;;) {
     System.out.print("zadejte vstupn� soubor: ");
     String jmeno = sc.nextLine();
     if (jmeno.equals("")) System.exit(0);
     try {
       FileInputStream in = new FileInputStream(jmeno);
       return in;
     } catch (FileNotFoundException e) {
       System.out.println("soubor neexistuje");
     }
   }
 }

 static FileOutputStream vystup() {
 Scanner sc = new Scanner(System.in);
 for (;;) {
    System.out.print("zadejte v�stupn� soubor: ");
    String jmeno = sc.nextLine();
    if (jmeno.equals("")) System.exit(0);
    try {
      FileOutputStream out = new FileOutputStream(jmeno);
      return out;
    } catch (FileNotFoundException e) {
      System.out.println("soubor nelze vytvo�it");
    }
  }
}

public static void main(String[] args) {
   FileInputStream in = vstup();
   FileOutputStream out = vystup();
   try {
     int b = in.read();
     while (b!=-1) {
       out.write(b);
       b = in.read();
     }
     in.close();
     out.close();
   } catch (IOException e) {
     e.printStackTrace();
   }
 }


}