'''
Created on Sep 22, 2011

@author: vikturek
'''

import sys
import os
import random

if __name__ == '__main__':
    score = 0
    rand = random
    testing = False
    tests1 = ["4 2 2 2 2 2 ",
              "4 2 2 4 4 4 ",
              "2 2 2 4 2 2 ",
              "2 -2 2 4 0 0 ",
              "2 -2 -2 4 0 0 ",
              "4 0 0 2 0 -2 ",
              "4 0 0 2 0 -3 ",
              "2 -3 -3 4 0 0 ",
              "4 0 0 2 -4 0 ",
              "4 0 0 4 0 0 "]
    tests2 = ["4 2 2 e 2 3",
              "\t4   \t0 0 \n2\n0   \t-3 ",
              "2.0 -3.1\t -3.0 4.0 1e-20 0.0 ",
              "2e10 -2.3 -2     4e10\n 1e-20 \t0\n ",
              "ahoj, ja jsem spatny vstup",
              "2 3 44 ",
              "0 0 0 0 0 0 ",
              "4 0 0 0 1 1 ",
              "-10 0 0 4 0 0",
              "1 0 0 -2 0 0"]
    
    print "\nTester pro domaci ukol 1 predmetu PJC v zimnim semestru 2011\n"
    if len(sys.argv) != 3:
        print "\tTester vyzaduje jako prvni argument referencni reseni a jako druhy nazev zdrojoveho kodu k testovani."
        sys.exit(0)
    else:
        if os.path.exists(sys.argv[1]):
            open(sys.argv[1])
        else:
            print "Chyba: Nemohu najit zadane referencni reseni!"
            sys.exit(1)
        if os.path.exists(sys.argv[2]):
            open(sys.argv[2])
        else:
            print "Chyba: Nemohu najit zadany zdrojovy soubor!"
            sys.exit(1)
                
    printOut = "\tKompiluji zadany zdrojovy soubor ... "
    retVal = os.system("g++ -o testApp -Wall -pedantic -Werror -pedantic-errors " + sys.argv[2] + " 2> compileLog.txt" )
    if retVal != 0:
        printOut += "Chyba!"
        print printOut
        print "\n\tZdrojovy kod se nepodarilo prelozit."
        print "\tKompletni log kompilace je ulozen v souboru compileLog"
        sys.exit()
    printOut += "OK"
    print printOut
    
    print "\nTestovaci sada 1 - zakladni funkcnost"
    for i in range(0, len(tests1)):
        testFile = file("test1." + str(i), "w")
        testFile.write(tests1[i])
        testFile.close()
        printOut = "\n\tTest 1." + str(i) + " ... "
        os.system("./" + sys.argv[1] + " < test1." + str(i) + " > refOutput1." + str(i))
        os.system("./testApp < test1." + str(i) + " > testOutput1." + str(i))
        if os.system("diff refOutput1." + str(i) + " testOutput1." + str(i) + " > /dev/null") == 0:
            printOut += "OK"
            score += 1
        else:
            printOut += "Chyba!"
            printOut += "\n\tVystupy refOutput1." + str(i) + " a testOutput1." + str(i) + " nejsou stejne!"
        print printOut
        
    print "\nTestovaci sada 2 - kontrola vstupnich dat"
    for i in range(0, len(tests2)):
        testFile = file("test2." + str(i), "w")
        testFile.write(tests2[i])
        testFile.close()
        printOut = "\n\tTest 2." + str(i) + " ... "
        os.system("./" + sys.argv[1] + " < test2." + str(i) + " > refOutput2." + str(i))
        os.system("./testApp < test2." + str(i) + " > testOutput2." + str(i))
        if os.system("diff refOutput2." + str(i) + " testOutput2." + str(i) + " > /dev/null") == 0:
            printOut += "OK"
            score += 1
        else:
            printOut += "Chyba!"
            printOut += "\n\tVystupy refOutput2." + str(i) + " a testOutput2." + str(i) + " nejsou stejne!"
        print printOut
    
    print "\nTestovaci sada 3 - nahodne generovana vstupni data"
    print "\n\tTest 3 - vyckejte prosim..."
    for i in range(0, 100):
#        testFile = file("test3." + str(i), "w")
        testFile = file("test3", "w")
        testFile.write(str(rand.uniform(0, 10000)) + " ")
        testFile.write(str(rand.uniform(-5000, 5000)) + " ")
        testFile.write(str(rand.uniform(-5000, 5000)) + " ")
        testFile.write(str(rand.uniform(0, 10000)) + " ")
        testFile.write(str(rand.uniform(-5000, 5000)) + " ")
        testFile.write(str(rand.uniform(-5000, 5000)) + " ")
        testFile.close()      
        os.system("./" + sys.argv[1] + " < test3 > refOutput3")
        os.system("./testApp < test3 > testOutput3")
        if os.system("diff refOutput3 testOutput3 > /dev/null") == 0:
            score += 1
        else:
            printOut += "Chyba!"
            printOut += "\n\tVystupy refOutput3 a testOutput3 nejsou stejne!"
            printOut += "\n\tPrerusuji testovaci sadu 3."
            printOut += "\nDosazena uspesnost je " + str(score / 120 * 100) + "%.\n"
            print printOut
            sys.exit()
    print "\n\n\tTest 3 ... OK"
    print "\nDosazena uspesnost je " + str(score / 120 * 100) + "%.\n"

