package knihovna.dl.entity;


import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;



/**
 * @author Jirka
 * @version 1.0
 * @created 16-VIII-2009 20:21:24
 */
@Entity
public class Kniha implements Serializable {

	@Id
	private int knihaid;
	private String isbn;
	private String klicovaslova;
	private String nazev;
	private String obsah;
	private int rokvydani;
	private int regalid;
	private int nakladatelstviid;
	
	private static final long serialVersionUID = 1L;

	public Kniha(){

	}

	public int getKnihaid(){
		return knihaid;
	}

	/**
	 * 
	 * @param knihaid
	 */
	public void setKnihaid(int knihaid){
		this.knihaid=knihaid;
	}

	public String getIsbn(){
		return isbn;
	}

	/**
	 * 
	 * @param isbn
	 */
	public void setIsbn(String isbn){
		this.isbn=isbn;
	}

	public String getKlicovaslova(){
		return klicovaslova;
	}

	/**
	 * 
	 * @param klicovaslova
	 */
	public void setKlicovaslova(String klicovaslova){
		this.klicovaslova=klicovaslova;
	}

	public String getNazev(){
		return nazev;
	}

	/**
	 * 
	 * @param nazev
	 */
	public void setNazev(String nazev){
		this.nazev=nazev;
	}

	public String getObsah(){
		return obsah;
	}

	/**
	 * 
	 * @param obsah
	 */
	public void setObsah(String obsah){
		this.obsah=obsah;
	}

	public int getRokvydani(){
		return rokvydani;
	}

	/**
	 * 
	 * @param rokvydani
	 */
	public void setRokvydani(int rokvydani){
		this.rokvydani=rokvydani;
	}

	public int getRegalid(){
		return regalid;
	}

	/**
	 * 
	 * @param regalid
	 */
	public void setRegalid(int regalid){
		this.regalid=regalid;
	}

	public int getNakladatelstviid(){
		return nakladatelstviid;
	}

	/**
	 * 
	 * @param nakladatelstviid
	 */
	public void setNakladatelstviid(int nakladatelstviid){
		this.nakladatelstviid=nakladatelstviid;
		
	}

	
}