package cz.cvut.fel.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import cz.cvut.fel.shared.ChessCell;
import java.util.ArrayList;

public class Chessboard extends VerticalPanel {

    protected ChessCellViz[][] cells;
    protected ChessCellViz firstSelected = null;
    protected ArrayList<ChessCellListener> listeners = new ArrayList<ChessCellListener>();

    public ChessCellViz getFirstSelected() {
        return firstSelected;
    }

    public void setFirstSelected(ChessCellViz firstSelected) {
        this.firstSelected = firstSelected;
    }

    public ChessCellViz getSecondSelected() {
        return secondSelected;
    }

    public void setSecondSelected(ChessCellViz secondSelected) {
        this.secondSelected = secondSelected;
    }
    protected ChessCellViz secondSelected = null;

    // protected ChessCellClickHandler ch = new ChessCellClickHandler();
    public Chessboard(ChessCell[][] chessboard) {
        super();
        this.cells = new ChessCellViz[chessboard.length][];
        final Chessboard chb = this;
        // ChessCellClickHandler clickHandler = new ChessCellClickHandler(this);
        ChessActionHandler.getInstance().setListeners(this.listeners);
        for (int x = 0; x < chessboard.length; x++) {
            HorizontalPanel row = new HorizontalPanel();
            this.add(row);
            this.cells[x] = new ChessCellViz[chessboard[x].length];
            for (int y = 0; y < chessboard[x].length; y++) {
                ChessCellViz cell = new ChessCellViz(chessboard[x][y]);
                this.cells[x][y] = cell;
                row.add(cell);
                cell.addClickHandler(new ClickHandler() {

                    @Override
                    public void onClick(ClickEvent event) {
                        ChessActionHandler.getInstance().cellClicked(
                                (ChessCellViz) event.getSource(), chb);
                    }
                });
            }
        }
    }

    public void addChessCellListener(ChessCellListener listener) {
        this.listeners.add(listener);
    }

    public void removeChessCellListener(ChessCellListener listener) {
        this.listeners.remove(listener);
    }

    
    public ChessCellViz getCell(int x, int y) {
        if (x < 0 || y < 0) {
            return null;
        }
        if (x >= this.cells.length) {
            return null;
        }
        if (y >= this.cells[x].length) {
            return null;
        }
        return this.cells[x][y];
    }
}
