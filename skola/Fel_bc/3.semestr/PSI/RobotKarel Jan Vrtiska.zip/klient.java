/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robot_klient;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author Jan Vrtiška
 */
public class klient {
    static PrintWriter out2;
    static BufferedReader in2;
    static boolean konec = false;
    public static Point souradniceOld = new Point(0,0);
    static Point souradniceAct = new Point(100,100);
    static String jmeno,prijataZprava,zprava;
    static int blok;
    static int tah=0;
    static String cislo;
    static    int volba;



    private static void souradnice() {
        otoc(1);
        souradniceOld=parserSouradnice();
        krok(1);
        souradniceAct=parserSouradnice();
  }
    public static void posunovac() {
        int x1, x2, y1, y2;
        x1 = Math.abs(souradniceOld.x);
        y1 = Math.abs(souradniceOld.y);
        x2 = Math.abs(souradniceAct.x);
        y2 = Math.abs(souradniceAct.y);
        System.out.println("x stara: "+x1 );
        System.out.println("x nova: "+x2 );
        System.out.println("ystara: "+y1 );
        System.out.println("y nova: "+y2 );
        if (x2 > x1) {
            otoc(2);
            krok(x2);
            if ((souradniceOld.x < 0 && souradniceOld.y < 0) || (souradniceOld.x > 0 && souradniceOld.y > 0)) {
                otoc(1);
            } else {
                otoc(3);
            }
            krok(y2);
            return;
        }
        if(y2>y1) {
            otoc(2);
            krok(y2);
            if ((souradniceOld.x < 0 && souradniceOld.y < 0) || (souradniceOld.x > 0 && souradniceOld.y  > 0)) {
                otoc(3);
            } else {
                otoc(1);
            }
            krok(x2);
            return;
        }
        if(x1>x2){
        krok(x2);
        if ((souradniceOld.x < 0 && souradniceOld.y < 0) || (souradniceOld.x > 0 && souradniceOld.y > 0)) {
                otoc(1);
            } else {
                otoc(3);
            }
            krok(y2);
            return;
        }
        else{
        krok(y2);
        if ((souradniceOld.x < 0 && souradniceOld.y < 0) || (souradniceOld.x > 0 && souradniceOld.y  > 0)) {
                otoc(3);
            } else {
                otoc(1);
            }
            krok(x2);
            return;

        }


    }
    
    public static Point parserSouradnice() {
        Point souradnice = new Point(100,100);
        String hodnota = "";
        int q, p;
        System.out.println("prijata zprava: "+prijataZprava);
        for (int i = 0; i < prijataZprava.length(); i++) {
            if (prijataZprava.charAt(i) == '(') {
                q = i;
                while (prijataZprava.charAt(q) != ',') {
                    q++;
                }
                p = q;
                hodnota = "" + prijataZprava.substring(i + 1, q);
                souradnice.x = Integer.parseInt(hodnota);
                while (prijataZprava.charAt(q + 1) != ')') {
                    q++;
                }
                hodnota = prijataZprava.substring(p + 1, q + 1);
                souradnice.y = Integer.parseInt(hodnota);
            }
        }
        System.out.println("prectena souradnice x: "+souradnice.x);
        System.out.println("prectena souradnice y: "+souradnice.y);
        return souradnice;
    }

    static int reader() {
        
        cislo = prijataZprava.substring(0, 3);
        volba = Integer.parseInt(cislo);
        return volba;
    }


    private static void parserOsloveni(String _zprava) {
        System.out.println(_zprava);
        try {
            _zprava=_zprava.replaceAll("(\\r|\\n)","");
            _zprava+="\\r\\n";
           // Pattern q = Pattern.compile("^.*\\n*\\r*\\n*.*Oslovuj\\smne(.*)\\..*\\n*.*$",Pattern.MULTILINE);
            Pattern q = Pattern.compile("^.*Oslovuj mne([^\\.]+)\\..*\\z");
            Matcher m = q.matcher(_zprava);
            m.matches();
            String ret = m.group(1);
            ret=ret.substring(1);
            System.out.println(ret);
            jmeno=ret;
        } catch (Exception e) {
            System.out.println("nenalezeno");            
        }

    }
    public static boolean stav(){
        //System.out.println("kontroluji stav");
        System.out.println(reader());
//    if(reader()==570){
////        Porucha();
//        System.out.println("volám opravu");
//        }
    return true;
    }
    public static void main(String[] args) throws IOException {

         Socket soket = new Socket(args[0],Integer.decode(args[1]));
         OutputStream out = soket.getOutputStream();
         InputStream in = soket.getInputStream();
         out2= new PrintWriter(out);
         in2 = new BufferedReader(new InputStreamReader(in));
         parserOsloveni(precti());
//         parserOsloveni("220 Ahoj, tady je robot verze 1.5.Myslim, ze je vhodny cas pro nekolik nadhernych korejskych versu:          Nad horami Kwanaksan se protrhavaji mraky         Nikdo a nic nezahali          i plynouci oblaka maji co delat:         vzletat od dalekych brehu,         kupit se a znovu mizet v sirem nebi.        [basne z pavilonu Cchokkumhon,          Dest v horach rozezniva bambusy]Nyni zatlacim roboti slzu a jsem pripraven prijmou prikaz.Aha, jeste to podstatne: Oslovuj mne skvely robote, ktery jsi kremikovym zazrakem. Pripraven ?");
        // System.out.println(jmeno);
         souradnice();
         posunovac();
         posli("ZVEDNI");
         System.out.println(precti());
         soket.close();
         System.exit(0);

        }

    private static void posli(String zprava) {
        System.out.println(jmeno+" "+zprava);
        out2.write(jmeno+" "+zprava+"\r\n");
        out2.flush();
        precti();
    }
    private static String precti()
    {
        String precteno="";
        char predposledni='a';
        char posledni='a';

        konec=false;
    while(konec==false){
            try {predposledni=posledni;
                posledni= (char)in2.read();
                precteno+=posledni;
                if((predposledni=='\r') & (posledni=='\n')) konec=true;
               } catch (IOException ex) {
                Logger.getLogger(klient.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
        System.out.println(precteno);
        prijataZprava=precteno;
        return precteno;
    }

      
    private static void otoc(int otoceni) {
        for (int d = 0; d < otoceni; d++) {
         posli("VLEVO");
             while(reader()==570){
        int o = prijataZprava.length() - 3;
        prijataZprava=prijataZprava.replaceAll("(\\r|\\n)","");
        int tBlok = Integer.parseInt(prijataZprava.substring(o));
        System.out.println("BLOK " + tBlok);
        zprava="OPRAVIT "+tBlok;
        posli(zprava);
        posli("VLEVO");
        }
        
            
        }
    }

    private static void krok(int kroky) {
        for (int k = 0; k < kroky; k++) {
        posli("KROK");
        while(reader()==570){
        int o = prijataZprava.length() - 3;
        prijataZprava=prijataZprava.replaceAll("(\\r|\\n)","");        
        int tBlok = Integer.parseInt(prijataZprava.substring(o));
        System.out.println("BLOK " + tBlok);
        zprava="OPRAVIT "+tBlok;
        posli(zprava);
        posli("KROK");
        }
       
        }
    }

   

    public static class Robot {

        Robot robot = null;
        Point souradniceNow, souradniceNext;
        int smer;

        public Robot(int x, int y) {
            souradniceNow.x = x;
            souradniceNow.y = y;
        }
    }

}




