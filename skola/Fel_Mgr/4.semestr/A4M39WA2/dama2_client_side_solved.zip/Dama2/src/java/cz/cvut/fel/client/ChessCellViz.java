package cz.cvut.fel.client;

import com.google.gwt.user.client.ui.FocusPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Widget;

import cz.cvut.fel.shared.ChessCell;
import cz.cvut.fel.shared.Jewel;

public class ChessCellViz extends FocusPanel {
	protected ChessCell cell;
	protected Widget jewelviz;

	public ChessCellViz(ChessCell cell) {
		super();
		this.setChessCell(cell);
	}

	public ChessCell getChessCell() {
		return this.cell;
	}

	public void setChessCell(ChessCell cell) {
		System.out.println(cell.getX());
		this.cell = cell;
		if (cell.getType() == ChessCell.BLACK) {
			this.setStyleName("black");
		} else {
			this.setStyleName("white");
		}

		Jewel jewel = this.cell.getJewel();
			Widget w = ChessCellViz.getJewelWidget(jewel);
			if (this.jewelviz == null && w == null) {
				// nic tu nebylo a ani nema byt, zadna zmena
				return;
			}
			// odstran existujici widget
			if (jewelviz != null) {
				this.remove(this.jewelviz);
			}
			if (w != null) {
				this.add(w);
			}
			this.jewelviz = w;
	}

	public static Widget getJewelWidget(Jewel j) {
		if (null == j)
			return new Image("images/no_dama.png");
		if (j.getColor() == Jewel.BLACK) {
			if (j.getType() == Jewel.NORMAL) {
				return new Image("images/black.png");
			} else {
				return new Image("images/black_dama.png");
			}
		} else {
			if (j.getType() == Jewel.NORMAL) {
				return new Image("images/white.png");
			} else {
				return new Image("images/white_dama.png");
			}
		}
	}
	
	public void select() {
		this.removeStyleName("deselected");
		this.addStyleName("selected");
		
	}
	
	public void unselect() {
		this.removeStyleName("seleted");
		this.addStyleName("deselected");
	}
}
