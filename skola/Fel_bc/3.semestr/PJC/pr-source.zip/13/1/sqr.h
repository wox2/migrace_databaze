/* sqr.h  - poskytuje funkci pro druhou mocninu */
#ifndef __sqr_h__3490304930493__
#define __sqr_h__3490304930493__

double sqr ( double x );

#endif  /* __sqr_h__3490304930493__ */
