#include "printHello.h"

void printHello(){
	printf("Hello ");
}

