/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import Core.Edge;
import Core.Graph;
import Core.Node;

/**
 * Tridy implementujici tento interface by mely "kreslit" prubeh algoritmu.
 * @author woxie
 */
public interface IPainter {
    /**
     * Metoda nakresli dany Node
     * @param node Node, ktery se ma nakreslit.
     */
    public void paintNode(Node node);
    /**
     * Metoda, ktera nakresli danou hranu.
     * @param edge Hrana, ktera se ma nakreslit.
     */
    public void paintEdge(Edge edge);
    /**
     * Nakresli danou Relaxovanou hranu
     * @param edge Relaxovana hrana, ktera se ma nakreslit.
     */
    public void paintRelaxedEdge(Edge edge);
    /**
     * Vymaze okno, kde probiha algoritmus.
     */
    public void clear();

    /**
     * Vykresli graf
     * @param graph Graph, ktery se ma vykreslit.
     */
    public void paintGraph(Graph graph);

    /**
     * Prekresli Graf
     * @param graph Graph, ktery se ma prekreslit.
     */
    public void repaintGraph(Graph graph);
}
