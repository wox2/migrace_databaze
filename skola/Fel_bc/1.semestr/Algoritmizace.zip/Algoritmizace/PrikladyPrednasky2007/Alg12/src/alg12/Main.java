/*
 * Main.java
 *
 * Created on 24. z��� 2006, 14:10
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package alg12;

/**
 *
 * @author ivan
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
