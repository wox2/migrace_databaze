#include <iostream>
#include <stdlib.h>

using namespace std;

#define SIZE 10

struct DataStruct {
	int jedna;
	int dva;
};

int funkce1(int cislo){
	// Second error
	cislo += atoi(NULL);
	cout << "Cislo: " << cislo << endl;
	return cislo;
}

int funkce2(int cislo){
	cislo ++;
	cislo = funkce1(cislo);
	return cislo;
}

int main(int argc, char *argv[]){
    int pole[SIZE];
    int *pole_d = new int[sizeof(int) * SIZE];
    int multiplikator;
    bool petIteraci = false;
    DataStruct dataStruct1;
    DataStruct *dataStruct2 = new DataStruct;

    
    for(int i = 0; i < SIZE; i ++){
	pole[i] = i;
	pole_d[i] = i;
	if(i == 5){
		petIteraci = true;
	}
    }
    // First error
    multiplikator = atoi(argv[1]);
    for(int i = 0; i < SIZE; i++){
	pole[i] = pole[i] * multiplikator;
    }
    
    funkce2(10);

    int a, b;
    
    cout << "Zadej hranu a: ";
    cin >> a;
    cout << endl << "Zadej hranu b: ";
    // Third error
    cin >> a;
    cout << endl;
    
    cout << "Obsah obdelniku je " << a * b << "." << endl;
    return 0;
}
