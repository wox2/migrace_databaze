package knihovna.dl.entity;



import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Vytisk implements Serializable {
	@Id
	private int vytiskid;

	private Date datumvyrazeni;

	private String evidencnicislo;

	private double porizovacicena;

	private int roknakupu;

	private String stav;

	public String getStav() {
		return stav;
	}

	public void setStav(String stav) {
		this.stav = stav;
	}

	@ManyToOne
	@JoinColumn(name="knihaID")
	private Kniha knihaid;

	private static final long serialVersionUID = 1L;

	public Vytisk() {
		super();
	}

	public int getVytiskid() {
		return this.vytiskid;
	}

	public void setVytiskid(int vytiskid) {
		this.vytiskid = vytiskid;
	}

	public Date getDatumvyrazeni() {
		return this.datumvyrazeni;
	}

	public void setDatumvyrazeni(Date datumvyrazeni) {
		this.datumvyrazeni = datumvyrazeni;
	}

	public String getEvidencnicislo() {
		return this.evidencnicislo;
	}

	public void setEvidencnicislo(String evidencnicislo) {
		this.evidencnicislo = evidencnicislo;
	}

	public double getPorizovacicena() {
		return this.porizovacicena;
	}

	public void setPorizovacicena(double porizovacicena) {
		this.porizovacicena = porizovacicena;
	}

	public int getRoknakupu() {
		return this.roknakupu;
	}

	public void setRoknakupu(int roknakupu) {
		this.roknakupu = roknakupu;
	}


	public Kniha getKnihaid() {
		return this.knihaid;
	}

	public void setKnihaid(Kniha knihaid) {
		this.knihaid = knihaid;
	}

}
