function g = getgraph(varargin)
    g = varargin{1};
    assignin('base','g',g);