package cz.swing.knihovna.dl;

import junit.framework.TestCase;
import knihovna.dl.dao.hibernate.VypujckaDAO;
import knihovna.dl.entity.Vypujcka;



public class TestKnihaDAO extends TestCase{
	public void onSetUp(){
	  
	}
	
	public void testA(){
		VypujckaDAO vypujckaDAO = new VypujckaDAO();
		/*List<Vypujcka> vypujcky = vypujckaDAO.vratVypujckyCtenare(new Ctenar());
		for (Vypujcka vypujcka:vypujcky){
			System.out.print(vypujcka);
		}
	*/
		Vypujcka vypujcka = vypujckaDAO.getVypujcka();
		System.out.print(vypujcka);
		assert(false);
	}
	
	
	public void onTearDown(){
		
	}

}
