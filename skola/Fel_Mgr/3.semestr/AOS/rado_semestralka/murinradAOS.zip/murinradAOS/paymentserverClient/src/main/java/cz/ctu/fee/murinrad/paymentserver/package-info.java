@javax.xml.bind.annotation.XmlSchema(namespace = "http://paymentserver.murinrad.fee.ctu.cz/")
package cz.ctu.fee.murinrad.paymentserver;
