@javax.xml.bind.annotation.XmlSchema(namespace = "http://printingserver.murinrad.fee.ctu.cz/")
package cz.ctu.fee.murinrad.printingserver;
