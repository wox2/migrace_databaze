/* Soubor Kap14\01-1_0\Prvni.java
 * Vytvo�� okno a zobraz� ho
 * Podrobn�j�� koment�� najdete v souboru 
 * Kap14\01-1_0\vokno\Vokno.java
 */
	
public class Prvni
{
	public static void main(String[] a)
	{
		vokno.Vokno okno = new vokno.Vokno();
		okno.setVisible(true);
	}
}