/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;


import javax.swing.JTextField;

/**
 *
 * @author já
 */
public class MCell extends JTextField {

    private int[] position;
   
    public MCell(int xPosition, int yPosition) {
        super(6);
        position = new int[]{xPosition, yPosition};
    }

    public int getXPosition() {
        return position[0];
    }
    public int getYPosition(){
    return position[1];
    }

  


}