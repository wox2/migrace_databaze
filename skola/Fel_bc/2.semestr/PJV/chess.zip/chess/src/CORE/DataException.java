/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CORE;

/**
 *
 * @author sprinkler
 */
public class DataException extends Exception{

    public DataException(String message) {
        super(message);
    }

}
