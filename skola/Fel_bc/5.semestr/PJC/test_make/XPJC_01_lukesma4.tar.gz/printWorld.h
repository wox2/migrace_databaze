#include <stdio.h>

void printWorld();
