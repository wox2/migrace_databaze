%CHARTOSTRUCT convert char to struct.
%    struct = CHARTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml

%   Author(s): M. Kutil
%   Copyright (c) 2005
%   $Revision: 2892 $  $Date: 2009-03-18 10:20:37 +0100 (st, 18 III 2009) $

