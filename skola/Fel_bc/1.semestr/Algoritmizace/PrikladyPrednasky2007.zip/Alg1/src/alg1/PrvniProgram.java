package alg1;

public class PrvniProgram {
  public static void main(String[] args) {
    System.out.println("Nazdar, toto je prvn� program");
  }
}
