/* Soubor Kap14\03\vokno\Vokno.java 
 * pr�zdn� okno 
 */
package vokno;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Vokno extends JFrame {

	public Vokno() {		
		//enableEvents(AWTEvent.WINDOW_EVENT_MASK); /* JDK 1.0*/
	}


	// JDK 1.0
/*  	protected void processWindowEvent(WindowEvent e) 
	{
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			System.exit(0);
		}
	}
*/
}
