package knihovna.pl.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import knihovna.bl.vypujcky.IPohled;
import knihovna.bl.vypujcky.IViewVypujckyController;
import knihovna.bl.vypujcky.VytiskDTO;
import knihovna.pl.KonstantyUI;
import knihovna.pl.controller.VypujckaController;

public class KnihovnaGUI extends JFrame implements IPohled{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8719584194076001335L;
	
	private JTextField cisloPrukazkyCtenareTextField;
	private JList seznamVracenychKnih;
	private JList seznamVypujcenychVytisku;
	private JTextField evidencniCisloTextField;
	private DefaultListModel listModelVolne;
	private DefaultListModel listModelVypujcene;
	
	private VypujckaController vypujckaController; 
	public VypujckaController getVypujckaController() {
		return vypujckaController;
	}
	public void setVypujckaController(VypujckaController vypujckaController) {
		this.vypujckaController = vypujckaController;
	}

	private IViewVypujckyController viewVypujckyController;
	public IViewVypujckyController getViewVypujckyController() {
		return viewVypujckyController;
	}
	public void setViewVypujckyController(
			IViewVypujckyController viewVypujckyController) {
		this.viewVypujckyController = viewVypujckyController;
	}

	
	JButton zpracovatVytiskButton;
	
	public KnihovnaGUI() {
		super();
		setTitle(KonstantyUI.NAZEV_OKNA);
		final BorderLayout borderLayout = new BorderLayout();
		borderLayout.setHgap(10);
		borderLayout.setVgap(10);
		getContentPane().setLayout(borderLayout);
		this.setSize(500, 300);

		final JPanel vypujceneVytiskyPanel = new JPanel();
		vypujceneVytiskyPanel.setLayout(new GridBagLayout());
		getContentPane().add(vypujceneVytiskyPanel, BorderLayout.WEST);

		final JLabel vypujceneVytiskyLabel = new JLabel();
		vypujceneVytiskyLabel.setVerticalAlignment(SwingConstants.TOP);
		vypujceneVytiskyLabel.setHorizontalAlignment(SwingConstants.CENTER);
		vypujceneVytiskyLabel.setText(KonstantyUI.SEZNAM_VYPUJCENE_VYTISKY);
		final GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 0;
		gridBagConstraints.ipadx = 45;
		gridBagConstraints.ipady = 5;
		vypujceneVytiskyPanel.add(vypujceneVytiskyLabel, gridBagConstraints);

		
		listModelVypujcene = new DefaultListModel();
		seznamVypujcenychVytisku = new JList(listModelVypujcene);
		final GridBagConstraints gridBagConstraints_1 = new GridBagConstraints();
		gridBagConstraints_1.gridx = 0;
		gridBagConstraints_1.gridy = 1;
		gridBagConstraints_1.ipady = 200;
		vypujceneVytiskyPanel.add(seznamVypujcenychVytisku, gridBagConstraints_1);
		seznamVypujcenychVytisku.setPreferredSize(new Dimension(150, 0));
		seznamVypujcenychVytisku.setEnabled(false);

		final JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(9, 0));
		getContentPane().add(panel, BorderLayout.CENTER);

		final JLabel naposledyZpracovanaKnihaLabel = new JLabel();
		naposledyZpracovanaKnihaLabel.setHorizontalAlignment(SwingConstants.CENTER);
		naposledyZpracovanaKnihaLabel.setText(KonstantyUI.POPISEK_AKTUALNI_INFORMACE);
		panel.add(naposledyZpracovanaKnihaLabel);

		final JLabel prihlasenyUzivatelLabel = new JLabel();
		prihlasenyUzivatelLabel.setText(KonstantyUI.POPISEK_UZIVATEL);
		panel.add(prihlasenyUzivatelLabel);

		final JLabel prihlasenyUzivatelJmenoLabel = new JLabel();
		prihlasenyUzivatelJmenoLabel.setText("");
		panel.add(prihlasenyUzivatelJmenoLabel);

		final JLabel knihaLabel = new JLabel();
		knihaLabel.setText("");
		panel.add(knihaLabel);

		final JLabel evidencniCisloLabel = new JLabel();
		evidencniCisloLabel.setText(KonstantyUI.POPISEK_EVIDENCNI_CISLO);
		panel.add(evidencniCisloLabel);

		evidencniCisloTextField = new JTextField();
		panel.add(evidencniCisloTextField);
		evidencniCisloTextField.setText("10");

		final JPanel panel_1 = new JPanel();
		panel_1.setLayout(new GridLayout(0, 1));
		panel.add(panel_1);

		zpracovatVytiskButton = new JButton();
		zpracovatVytiskButton.setText(KonstantyUI.TLACITKO_ZPRACOVAT_VYTISK);
		panel_1.add(zpracovatVytiskButton);

		cisloPrukazkyCtenareTextField = new JTextField();
		cisloPrukazkyCtenareTextField.setEnabled(false);
		panel.add(cisloPrukazkyCtenareTextField);

		final JButton prihlaseniCtenareButton = new JButton();
		prihlaseniCtenareButton.setText(KonstantyUI.TLACITKO_PRIHLASIT_CTENARE);
		prihlaseniCtenareButton.setEnabled(false);
		panel.add(prihlaseniCtenareButton);

		final JPanel panel_3 = new JPanel();
		panel_3.setLayout(new GridBagLayout());
		getContentPane().add(panel_3, BorderLayout.EAST);

		final JLabel vracenevytiskypopisekLabel = new JLabel();
		vracenevytiskypopisekLabel.setVerticalAlignment(SwingConstants.TOP);
		vracenevytiskypopisekLabel.setHorizontalAlignment(SwingConstants.CENTER);
		vracenevytiskypopisekLabel.setText(KonstantyUI.SEZNAM_VOLNE_VYTISKY);
		final GridBagConstraints gridBagConstraints_2 = new GridBagConstraints();
		gridBagConstraints_2.gridx = 0;
		gridBagConstraints_2.gridy = 0;
		gridBagConstraints_2.ipadx = 60;
		gridBagConstraints_2.ipady = 5;
		panel_3.add(vracenevytiskypopisekLabel, gridBagConstraints_2);
		
		listModelVolne = new DefaultListModel();
		seznamVracenychKnih = new JList(listModelVolne);
		seznamVracenychKnih.setEnabled(false);
		
		
		
		final GridBagConstraints gridBagConstraints_3 = new GridBagConstraints();
		gridBagConstraints_3.insets = new Insets(0, 0, 20, 0);
		gridBagConstraints_3.gridx = 0;
		gridBagConstraints_3.gridy = 1;
		gridBagConstraints_3.ipady = 200;
		panel_3.add(seznamVracenychKnih, gridBagConstraints_3);
		seznamVracenychKnih.setPreferredSize(new Dimension(150, 0));
		final JLabel label = new JLabel();
		label.setFont(new Font("Arial", Font.BOLD, 18));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setText(KonstantyUI.NADPIS);
		getContentPane().add(label, BorderLayout.NORTH);
		
		
	}

	@Override
	public void aktualizuj() {
		List<VytiskDTO> vytisky = viewVypujckyController.getVolneVytisky();
		
		listModelVolne.removeAllElements();
		for (VytiskDTO vytisk : vytisky) {
			listModelVolne.addElement(vytisk.getEvidencniCislo());
		}
		
		vytisky = viewVypujckyController.getVypujceneVytisky();
		listModelVypujcene.removeAllElements();
		for (VytiskDTO vytisk : vytisky) {
			listModelVypujcene.addElement(vytisk.getEvidencniCislo());
		}
		
	}
	
	public String getEvidencniCislo(){
		return evidencniCisloTextField.getText();
	}

	public void init(){
		zpracovatVytiskButton.addActionListener(this.vypujckaController);
		viewVypujckyController.pridatPohled(this);
		this.aktualizuj();
	}
}
