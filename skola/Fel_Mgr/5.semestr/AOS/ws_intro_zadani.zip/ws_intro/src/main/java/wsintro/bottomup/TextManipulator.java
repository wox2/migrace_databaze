package wsintro.bottomup;

public interface TextManipulator {

    String concatenate(
            String prefix,
            String suffix
    ) throws InputException;
}
