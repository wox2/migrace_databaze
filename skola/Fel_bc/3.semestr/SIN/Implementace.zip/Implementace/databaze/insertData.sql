
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '10', 1, 1, 'Volny', NULL, 10, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '11', 2, 2, 'Volny', NULL, 11, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '12', 2, 2, 'Volny', NULL, 12, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '13', 2, 2, 'Volny', NULL, 13, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '14', 2, 2, 'Volny', NULL, 14, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '15', 2, 2, 'Volny', NULL, 15, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '16', 2, 2, 'Volny', NULL, 16, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '17', 2, 2, 'Volny', NULL, 17, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '17', 2, 2, 'Volny', NULL, 18, NULL);
INSERT INTO vytisk (datumVyrazeni, evidencniCislo, porizovaciCena, rokNakupu, stav, vypujckaID, vytiskID, knihaID) VALUES ('2009-08-28', '19', 2, 2, 'Volny', NULL, 19, NULL);

