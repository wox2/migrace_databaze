package knihovna.pl.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import knihovna.bl.vypujcky.IZpracovaniVypujckyController;
import knihovna.pl.view.KnihovnaGUI;

public class VypujckaController implements ActionListener {
	
	private KnihovnaGUI knihovnaGUI;

	public KnihovnaGUI getKnihovnaGUI() {
		return knihovnaGUI;
	}

	public void setKnihovnaGUI(KnihovnaGUI knihovnaGUI) {
		this.knihovnaGUI = knihovnaGUI;
	}

	private IZpracovaniVypujckyController zpracovaniVypujckyController;
	
	public IZpracovaniVypujckyController getZpracovaniVypujckyController() {
		return zpracovaniVypujckyController;
	}

	public void setZpracovaniVypujckyController(
			IZpracovaniVypujckyController zpracovaniVypujckyController) {
		this.zpracovaniVypujckyController = zpracovaniVypujckyController;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		zpracovaniVypujckyController.zapisKnihu(knihovnaGUI.getEvidencniCislo());
	}

}
