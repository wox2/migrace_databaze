package cz.cvut.fel.shared;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Jewel implements Serializable {

	public static final int NORMAL = 1;
	public static final int ADVANCED = 2;
	public static final int WHITE = 3;
	public static final int BLACK = 4;
	
	int type = Jewel.NORMAL; 
	int color = Jewel.WHITE;
        private boolean moved = false;
	
	public Jewel () {
		this.type = Jewel.NORMAL;
	}
	
	public Jewel(int type) {
		setType(type);
	}
	
	public Jewel(int type, int color){
		this(type);
		setColor(color);
	}
	
	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		if (color == Jewel.WHITE || color == Jewel.BLACK){
			this.color = color;
		}
	}

	public static int getNormal() {
		return NORMAL;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		switch (type) {
		case Jewel.NORMAL: 
		case Jewel.ADVANCED:
			this.type = type; break;
			default: this.type = Jewel.NORMAL;
		}
	}


	
	public int upgrade () {
		if (this.type == Jewel.NORMAL) {
			this.type = Jewel.ADVANCED;
		}
		return getType();
	}
	
	public String getName() {
		String type = getType() == Jewel.NORMAL?"N":"D";
		String color = getColor() == Jewel.BLACK?"B":"W";
		return type+" ("+color+")";
	}

    /**
     * @return the moved
     */
    public boolean isMoved() {
        return moved;
    }

    /**
     * @param moved the moved to set
     */
    public void setMoved(boolean moved) {
        this.moved = moved;
    }
}
