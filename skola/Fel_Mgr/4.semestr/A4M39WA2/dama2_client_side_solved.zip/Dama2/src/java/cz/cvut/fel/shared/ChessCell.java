package cz.cvut.fel.shared;

import java.io.Serializable;



@SuppressWarnings("serial")
public class ChessCell implements Serializable {
	public static final int WHITE = 1;
	public static final int BLACK = 2;
	
	
	protected int type = ChessCell.BLACK;
	protected Jewel jewel = null;
	protected int x = 0;
	protected int y = 0;
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Jewel getJewel() {
		return jewel;
	}

	public void setJewel(Jewel jewel) {
		this.jewel = jewel;
	}
	public ChessCell() {
		super();
	}
	
	public ChessCell(int type) {
		this();
		this.setType(type);
	}
	
	public ChessCell(int type, Jewel jewel) {
		this(type);
		setJewel(jewel);
	}
	
	public int setType(int type){
		switch (type) {
		case ChessCell.WHITE:
		case ChessCell.BLACK:
			this.type = type; 
			break;
		}
		return this.type;
	}
	
	public int getType() {
		return this.type;
	}
}
