package cz.cvut.fel.server;

import java.io.Serializable;

import cz.cvut.fel.shared.ChessCell;
import cz.cvut.fel.shared.Jewel;

/**
 * 
 * @author xklima
 * 
 */
@SuppressWarnings("serial")
public class Dama implements Serializable {
	protected ChessCell[][] chessboard;

	public Dama() {
		chessboard = new ChessCell[8][8];
		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				int type = (x + y) % 2 == 1 ? ChessCell.BLACK : ChessCell.WHITE;
				ChessCell cell = new ChessCell(type);
				cell.setX(x);
				cell.setY(y);

				if (x <= 1) {
					cell.setJewel(new Jewel(Jewel.NORMAL, Jewel.BLACK));
				} else {
					if (x >= 6) {
						cell.setJewel(new Jewel(Jewel.NORMAL, Jewel.WHITE));
					}
				}
				chessboard[x][y] = cell;
			}
		}
	}

	public ChessCell[][] getAllCells() {
		return this.chessboard;
	}

	public ChessCell getCell(int x, int y) {
		if (x <= 7 && x >= 0 && y <= 7 && y >= 0) {
			return chessboard[x][y];
		} else
			return null;
	}

	public void setCell(ChessCell cell) {
		int x = cell.getX();
		int y = cell.getY();
		if (x <= 7 && x >= 0 && y <= 7 && y >= 0) {
			chessboard[x][y] = cell;
		}
	}

	public void setCells(ChessCell[] cells) {
		for (int i = 0; i < cells.length; i++) {
			setCell(cells[i]);
		}
	}
}
