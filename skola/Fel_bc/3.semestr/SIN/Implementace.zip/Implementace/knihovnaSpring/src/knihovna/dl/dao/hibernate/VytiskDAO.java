package knihovna.dl.dao.hibernate;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import knihovna.dl.dao.IVytiskDAO;
import knihovna.dl.entity.Vytisk;


/**
 * T��da umo��uje ukl�d�n� a na��t�n� v�tisk� a jejich stav�.
 * @author Ji�� Mlejnek
 * @version 1.0
 * @updated 04-IX-2009 19:36:44
 */
public class VytiskDAO extends HibernateDaoSupport implements IVytiskDAO {

	public VytiskDAO(){

	}

	/**
	 * Vr�t� seznam v�tisk�, kter� jsou v knihovn� pr�v� k dispozici.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Vytisk> vratVolneVytisky() {
		return this.getHibernateTemplate().find("FROM Vytisk WHERE Stav = ? ", "Volny");
	}

	/**
	 * Vr�t� v�tisk knihy na z�klad� jeho eviden�n�ho ��sla.
	 * 
	 * @param evidencniCislo
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Vytisk vratVytisk(String evidencniCislo) {
		List<Vytisk> vytisky = this.getHibernateTemplate().find("FROM knihovna.dl.entity.Vytisk WHERE EvidencniCislo = ? ", evidencniCislo);
		return vytisky.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
    public List<Vytisk> vratVypujceneVytisky() {
		List<Vytisk> vypujceneVytisky = this.getHibernateTemplate().find("FROM  knihovna.dl.entity.Vytisk WHERE Stav = ? ", "Vypujceny");
		return vypujceneVytisky;
	}
	
	public void ulozVytisk(Vytisk vytisk){
		this.getHibernateTemplate().saveOrUpdate(vytisk);
	}

	/**
	 * Vr�t� v�tisk knihy na z�klad� jeho eviden�n�ho ��sla.
	 * 
	 * @param evidencniCislo    evidencniCislo
	 */
	@Override
	public Vytisk vratVytisk(int evidencniCislo){
		return null;
	}

	
}