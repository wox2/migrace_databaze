#include <stdio.h>

void printHello();
