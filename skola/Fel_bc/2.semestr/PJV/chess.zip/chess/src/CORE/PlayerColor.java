/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CORE;

/**
 *
 * @author sprinkler
 */
public class PlayerColor {

    public final String BLACK = "black";

    public final String WHITE = "white";

}
