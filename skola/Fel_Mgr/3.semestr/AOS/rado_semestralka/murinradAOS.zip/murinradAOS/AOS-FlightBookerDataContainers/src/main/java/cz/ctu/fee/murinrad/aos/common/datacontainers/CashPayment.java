/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.datacontainers;

/**
 * Represents a cash payment
 * @author murinr
 */
public class CashPayment extends Payment {

    public CashPayment() {
    }
    
    
    
}
