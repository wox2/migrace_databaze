/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.exceptions;

/**
 *
 * @author murinr
 */
public class PaymentException extends Exception {

    public PaymentException(String message, Throwable cause) {
        super(message, cause);
    }
    
    
    
}
