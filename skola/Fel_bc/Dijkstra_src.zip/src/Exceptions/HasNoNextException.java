/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Exceptions;

/**
 * Vyjimka vyhozena, pokud Iterator jiz nema co iterovat
 * @author woxie
 */
public class HasNoNextException extends Exception{
    public HasNoNextException(){
    }
}
