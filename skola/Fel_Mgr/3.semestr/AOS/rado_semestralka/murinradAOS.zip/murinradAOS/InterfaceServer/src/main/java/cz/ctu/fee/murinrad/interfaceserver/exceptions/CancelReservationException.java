/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.interfaceserver.exceptions;

/**
 *
 * @author Radovan Murin
 */
public class CancelReservationException extends Exception {

    public CancelReservationException(String message, Throwable cause) {
        super(message, cause);
    }
    
    
    
}
