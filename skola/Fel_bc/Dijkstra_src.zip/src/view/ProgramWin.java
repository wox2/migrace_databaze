/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Core.DijkstraAlgorithm;
import Core.Examples;
import Core.Graph;
import Core.Steppable;
import Aplication.Controller;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/**
 *
 * @author woxie
 */
public class ProgramWin extends JFrame {

  
    private JButton nextButton;
    private JComboBox exampleChoiceButton;
    private JButton restoreButton;
    private JButton runButton;
    private static ProgramWin window;
    private Graph graph;

    private Thread th;

    private Controller controller;

    private ProgramWin() {
        graph = Examples.getExample1();
        Steppable algorithm = new DijkstraAlgorithm(graph, graph.getNode("a"));
        controller = new Controller(algorithm);
        controller.setGraph(graph);

        createButtons();
        setTitle("Vizualizace Dijkstrova algoritmu");
        FlowLayout flowLayout = new FlowLayout();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(flowLayout);

        add(exampleChoiceButton);

        add(restoreButton);
        add(nextButton);
        add(runButton);

        setSize(new Dimension(800, 600));
        this.setResizable(false);

        setVisible(true);

    }

    /**
     * Vytvori buttony a navesi na ne listenery.
     */
    private void createButtons() {
        nextButton = new JButton("Dalsi krok");

        nextButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                    controller.doStep();
                
            }
        });

        String[] examples = {"priklad1", "priklad2", "priklad3"};
        exampleChoiceButton = new JComboBox(examples);
        exampleChoiceButton.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                if (ItemEvent.SELECTED == e.getStateChange()) {
                    String str = e.getItem().toString();
                    graph =Examples.getExample(str);
                    Steppable algorithm = new DijkstraAlgorithm(graph,graph.getNode("a"));
                    controller.setAlgorithm(algorithm);
                    controller.setGraph(graph);
                    controller.drawGraph();
                }
            }
        });
        restoreButton = new JButton("Zacit znovu (zobrazit znovu)");
        restoreButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                controller.setAlgorithm(new DijkstraAlgorithm(graph, graph.getNode("a")));
                controller.setGraph(graph);

                controller.drawGraph();
            }
        });

        runButton = new JButton("Run");
        runButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
              th = new Thread(controller);
              th.start();
            }
        });
    }

    /*
     * Tovarni metoda. Vytvori okno, prida Paintera, prida painterovi Componenty, ktere nema mazat,
     * nakresli prvni graf, ktery se zobrazi.
     */
    public static ProgramWin getProgramWindow() {
        if (window == null) {
             window = new ProgramWin();
             window.controller.addView(window);
             window.draw();
        }
        return window;
    }

    /**
     * Upozorni controllera, ze je nutne nakreslit graph.
     */
    public void draw(){
        controller.drawGraph();
    }

   

    @Override
    public void paint(Graphics gr){
        try{
        controller.clear();
        paintComponents(gr);
        controller.drawGraph();
        } catch(NullPointerException ex){
            paint(gr);
            // System.out.println("Vyjimka odchycena");
        }
    }
}
