/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Core.Edge;
import Core.Graph;
import Core.Node;
import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Trida, ktera kresli prubeh algoritmu.
 * @author woxie
 */
public class Painter implements IPainter {
    /**
     * Ukazatel na okno
     */
    private ProgramWin programWin;
    /**
     *  Sirkova konstanta vycentrovani mazani.
     */
    private static final int RUBBER_CENTER_WIDTH = 0;
    /**
     *  Vyskova konstanta vycentrovani mazani.
     */
    private static final int RUBBER_CENTER_HEIGHT = -12;
    /**
     *  Sirkova konstanta mazani textu - jak siroke pasmo se ma vymazat.
     */
    private static final int RUBBER_TEXT_WIDTH = 20;
    /**
     *  Vyskova konstanta mazani textu - jak vysoke pasmo se ma vymazat.
     */
    private static final int RUBBER_TEXT_HEIGHT = 12;
    /**
     * Polomer kreslenych Nodu.
     */
    private static final int VELIKOST_NODU = Node.velikostNodu;
    /**
     *  Konstanta zajistujici, ze hrany budou vychazet ze stredu Nodu.
     */
    private static final int CENTER_EDGE_X_AND_Y = VELIKOST_NODU / 2;
    /**
     *  Konstanta barvy, kterou se budou zobrazovat Nody.
     */
    private static final Color NODE_COLOR = Color.BLACK;
    /**
     *  Konstanta barvy, kterou se budou zobrazovat Edge ihned po nakresleni grafu
     */
    private static final Color EDGE_COLOR = Color.RED;
    /**
     *  Konstanta barvy, kterou se budou zobrazovat relaxovane Edge
     */
    private static final Color RELAXED_EDGE_COLOR = Color.BLUE;
    /**
     *  Konstanta barvy, kterou se bude zobrazovat Text
     */
    private static final Color DISTANCE_COLOR = Color.BLACK;
    /**
     *  Konstanta barvy, kterou se budou zobrazovat popisek delky
     */
    private static final Color NODE_LABEL_COLOR = Color.WHITE;

    /**
     * Radiany rozsireni sipek
     */
    private static final double ARROW_DEVIATION = 2 * Math.PI/36*3;
    /**
     * Delka sipek
     */
     private static final int ARROW_LENGTH = 15;


    /**
     * Atribut Graphics, jenz kresli.
     */
    
    private Graphics2D graphics;


    /**
     *  Konstruktor. Vytvori Paintera k danemu ProgramWin.
     * @param programWin ProgramWin, ke kteremu je Painter vazan
     */
    public Painter(ProgramWin programWin) {
        this.programWin = programWin;
        graphics = (Graphics2D) programWin.getGraphics();

    }

    /**
     * Nakresli Node. Barva Nodu, popisneho Stringu, Stringu
     * @param node Node k nakresleni
     */
    public void paintNode(Node node) {

        graphics.setColor(Painter.NODE_COLOR);
        int x = node.getX();
        int y = node.getY();
        graphics.fillOval(x, y,VELIKOST_NODU, VELIKOST_NODU);
        String str = "";
        if (node.getDistance() == Integer.MAX_VALUE) {
            str = "infi";
        } else {
            str = "" + node.getDistance();
        }
        // graphics.setColor(Color.blue);
        // graphics.fillRect(x+RUBBER_CENTER_WIDTH, y+RUBBER_CENTER_HEIGHT,RUBBER_TEXT_WIDTH, RUBBER_TEXT_HEIGHT);

        graphics.clearRect(x + RUBBER_CENTER_WIDTH, y + RUBBER_CENTER_HEIGHT, RUBBER_TEXT_WIDTH, RUBBER_TEXT_HEIGHT);

        graphics.setColor(Painter.DISTANCE_COLOR);
        graphics.drawString(str, x, y);

        graphics.setColor(NODE_LABEL_COLOR);
        graphics.drawString(node.getName(), x + VELIKOST_NODU / 2 - 2, y + VELIKOST_NODU / 2 + 2);
    }

    /**
     * Nakresli Edge edge danou barvou. Mela by nakreslit i sipku, znacici orientaci hrany(ATM neimplementovano).
     * @param edge kreslena hrana
     * @param color barva, kterou se kresli
     */
    private void paintEdge(Edge edge, Color color) {
        int xEnd = edge.getEndX();
        int yEnd = edge.getEndY();
        int xStart = edge.getStartX();
        int yStart = edge.getStartY();

        //posun po x, y, aby se hrana zakoncila u Nodu
        int xDelta = xEnd - xStart;
        int yDelta = yEnd - yStart;
        /* registruje, jestli se maji delta souradnice pricitat nebo odecitat - 
        vlastne kombinace techto dvou je kvadrant urceny uhlem alpha
         */
        int xNeg = 1;
        int yNeg = 1;
        if (xDelta < 0) {
            xDelta = -xDelta;
            xNeg = -1;
        }

        if (yDelta < 0) {
            yDelta = -yDelta;
            yNeg = -1;
        }
        /*
         * Odchylka(uhel) hrany od osy x, pomocne uhly k vytvoreni sipky
         */
        double alpha=0, alphaPlus10=ARROW_DEVIATION, alphaMinus10=-ARROW_DEVIATION;
        int xInSquareTriangle = 0, yInSquareTriangle = 0;
        if (xDelta != 0) {
            alpha = Math.atan((double) yDelta / xDelta);
            xInSquareTriangle = (int) (Math.cos(alpha) * VELIKOST_NODU/2);
            yInSquareTriangle = (int) (Math.sin(alpha) * VELIKOST_NODU/2);
            alphaMinus10 = alpha-ARROW_DEVIATION;
            alphaPlus10 = alpha+ARROW_DEVIATION;
        }
      //  System.out.println("Alpha je: "+alpha);
        /*
         * Souradnice konce hrany pred stredem uzlu.
         */
        int xPreEnd = xEnd + CENTER_EDGE_X_AND_Y - xNeg * xInSquareTriangle;
        int yPreEnd = yEnd + CENTER_EDGE_X_AND_Y - yNeg * yInSquareTriangle;
        int xPreStart = xStart + CENTER_EDGE_X_AND_Y + xNeg * xInSquareTriangle;
        int yPreStart = yStart + CENTER_EDGE_X_AND_Y + yNeg * yInSquareTriangle;

        graphics.setColor(color);
        graphics.drawLine(xPreEnd, yPreEnd, xPreStart, yPreStart);

        /*
         * souradnice bodu prvni casti sipky
         */
        int x1Arrow =  (int) (Math.cos(alphaPlus10) * ARROW_LENGTH);
        int y1Arrow = (int) (Math.sin(alphaPlus10) * ARROW_LENGTH);
        graphics.setColor(color);
        graphics.drawLine(xPreEnd, yPreEnd, xPreEnd-xNeg*x1Arrow, yPreEnd-yNeg*y1Arrow);

        int x2Arrow =  (int) (Math.cos(alphaMinus10) * ARROW_LENGTH);
        int y2Arrow = (int) (Math.sin(alphaMinus10) * ARROW_LENGTH);
        graphics.setColor(color);
        graphics.drawLine(xPreEnd, yPreEnd, xPreEnd-xNeg*x2Arrow, yPreEnd-yNeg*y2Arrow);


        graphics.setColor(EDGE_COLOR);

        /*
         * Stred hrany
         */
        int centerLineX = (xEnd + xStart + CENTER_EDGE_X_AND_Y) / 2;
        int centerLineY = (yEnd + yStart + CENTER_EDGE_X_AND_Y) / 2;

        graphics.drawString("" + edge.getLength(), centerLineX, centerLineY);
    }

    /**
     * Vymaze celou plochu okna, ale znovuzobrazi buttony
     */
    public void clear() {
        int width = programWin.getBounds().width;
        int height = programWin.getBounds().height;
        int x = programWin.getBounds().x;
        int y = programWin.getBounds().y;
        graphics.clearRect(x, y + 60, width, height);
    }

    /**
     * Nakresli relaxovanou hranu
     * @param edge hrana k nakresleni
     */
    public void paintRelaxedEdge(Edge edge) {
        paintEdge(edge, RELAXED_EDGE_COLOR);
    }

    /**
     * nerelaxovana hrana k nakresleni.
     * @param edge hrana k nakresleni
     */
    public void paintEdge(Edge edge) {
        paintEdge(edge, EDGE_COLOR);
    }

    /**
     * Vykresli dany graf. Vykresluje hrany jako nerelaxovane.
     * @param graph
     */
    public void paintGraph(Graph graph) {
        for (Node node : graph.getNodes()) {
            for (Edge edge : node.getEdges()) {
                paintEdge(edge);
            }
        }
        for (Node node : graph.getNodes()) {
            paintNode(node);
        }
    }

    /**
     * Prekresli graf. Hrany, ktere maji byt relaxovane budou zvyrazneny relaxovane
     * @param graph Graph k prekresleni
     */
    public void repaintGraph(Graph graph) {
        clear();
        paintGraph(graph);
        for (Node node : graph.getNodes()) {
            if (node.getPredecessor() != null) {
                paintRelaxedEdge(node.getEdgeFromPredecessor());

            }
        }
    }
}




