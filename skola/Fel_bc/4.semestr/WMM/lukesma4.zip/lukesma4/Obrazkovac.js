// JavaScript Document

function otevriNoveOkno(soubor)
{window.open(soubor, "Obrazek","width=1011,height=757");}
