#include <iostream>
using namespace std;

int main ( int argc, char * argv [] )
 {              
   int a, c;
                  
   a = 1;               
   c = a ++ + a ++;
   cout << "a = " << a << " c = " << c << endl;
   return ( 0 );
 }
