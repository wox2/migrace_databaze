/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.cvut.fel.client;

import cz.cvut.fel.shared.ChessCell;

/**
 *
 * @author xklima
 */
class CellEvent {
    public static final int CELL_CLICKED = 1;
    public static final int CELL_SELECTED = 2;
    public static final int CELL_DESELECTED = 3;
    public static final int CELL_LEAVED = 4;
    public static final int CELL_OCUPED = 5;
    private ChessCell source = null;
    private int event;

    public CellEvent(ChessCell source, int type) {
        this.source = source;
        this.event = type;
    }

    /**
     * @return the source
     */
    public ChessCell getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(ChessCell source) {
        this.source = source;
    }

    /**
     * @return the event
     */
    public int getEvent() {
        return event;
    }

    /**
     * @param event the event to set
     */
    public void setEvent(int event) {
        this.event = event;
    }
}
