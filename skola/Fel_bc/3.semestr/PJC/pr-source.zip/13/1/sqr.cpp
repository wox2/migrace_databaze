/* sqr.cpp � implementace modulu */
#include "sqr.h"

double sqr ( double x )
 {
   return ( x * x );
 }
