package kontrola;

/* Soubor Kap11\01\kontrola\Kontrola.java
 * Obsahuje rozhran� Kontrola, ve kter�m je
 * deklarov�na jedin� metoda zkontroluj() slou��c�
 * ke kontrole vnit�n� konzistence instance
 */

public interface Kontrola {
    public boolean zkontroluj();
}