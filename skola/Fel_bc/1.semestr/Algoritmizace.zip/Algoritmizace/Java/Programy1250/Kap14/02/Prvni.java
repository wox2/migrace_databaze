// Soubor Kap14\02\Prvni.java
// Hlavn� program k pokus�m s oknem

//import java.awt.*;

public class Prvni
{
	public static void main(String[] a)
	{
		vokno.Vokno okno = new vokno.Vokno();
		okno.setVisible(true);
	}
}