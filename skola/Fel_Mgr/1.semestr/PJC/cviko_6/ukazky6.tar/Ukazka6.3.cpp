//============================================================================
// Name        : Ukazka6.3.cpp
// Author      : vikturek
// Description : Vicerozmerny ukazatel
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int a = 10;
	int *p_a = &a;
	int **p_p_a = &p_a;

	cout << a << endl;
	cout << *p_a << endl;
	cout << **p_p_a << endl;
	return 0;
}
