/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Core;

import Exceptions.AlgorithmFinishedException;

/**
 * Tridy implementujici toto rozhrani musi zastupovat grafgove algoritmy, ktere lze krokovat.
 * @author woxie
 */
public interface Steppable  {

    /**
     * Metoda provede jeden krok algoritmu. V pripade, ze jiz neni mozne ucinit zadny krok
     * (algoritmus je u konce) metoda vyhodi vyjimku
     * @return Graf po provedeni jednoho kroku
     * @throws AlgorithmFinishedException
     */
    Graph doStep() throws AlgorithmFinishedException;
}
