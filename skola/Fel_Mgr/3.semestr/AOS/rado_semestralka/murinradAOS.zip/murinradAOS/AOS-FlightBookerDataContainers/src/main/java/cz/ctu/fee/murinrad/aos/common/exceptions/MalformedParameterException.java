/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.exceptions;

/**
 *
 * @author Radovan Murin
 */
public class MalformedParameterException extends Exception {

    public MalformedParameterException(String message, Throwable cause) {
        super(message, cause);
    }
    
    
}
