package kontrola;

/* Soubor Kap11\02\kontrola\Kontrola.java - stejn� jako v Kap11\01
 * Obsahuje rozhran� Kontrola, ve kter�m je
 * deklarov�na jedin� metoda zkontroluj() slou��c�
 * ke kontrole vnit�n� konzistence instance
 */

public interface Kontrola {
    public boolean zkontroluj();
}