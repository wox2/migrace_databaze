  	
    function date(){
        document.getElementById("date").innerHTML="Retrieve date from <a href=http://support.felk.cvut.cz/aos-wsf/services/rest/simple/date>http://support.felk.cvut.cz/aos-wsf/services/rest/simple/date</a>.";
    }