package Core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import Core.*;
import Exceptions.*;

/**
 * Trida nechava probihat Dijkstruv algoritmus.
 * @author woxie
 */
public class DijkstraAlgorithm implements Steppable {

    /**
     * Graph, na kterem se provadi Dijkstruv algoritmus.
     */
    private Graph graph;
    /**
     * Iterator hran.
     */
    private DijkstraEdgeIterator iterator;
    /**
     * Node, ktery je aktualne zpracovavan.
     */
    private Node actualNode;
    /**
     * Nody, ktere jsou closed a algoritmus je uz nebude prochazet.
     */
    private Set<Node> setClosedNodes;
    /**
     * Nody, ktere jsou ve stavu open
     */
    private PriorityQueue priorityFreshQueue;

    /**
     * Konstruktor, ktery potrebuje parametry - graf, ktery bude algoritmus prochazet a Node,
     * z ktereho se snazime najit nejkratsi vzdalenost do ostatnich uzlu
     * @param graphUsedWithDijkstra Graf, ktery bude zpracovavan danou instanci teto tridy.
     * @param sourceNode Node, od ktereho se pocita vzdalenost
     */
    public DijkstraAlgorithm(Graph graphUsedWithDijkstra, Node sourceNode) {
        try {
            graph = (Graph)graphUsedWithDijkstra.clone();
            setClosedNodes = new HashSet<Node>();
            priorityFreshQueue = new PriorityQueue(graph.getNodesCount());
            graph.setInfinityDistances();
            graph.setNullPrecedessors();
            actualNode = graph.getNode(sourceNode.getName());
            actualNode.setDistance(0);
            List<Node> nodes = graph.getNodes();
            for (Node node : nodes) {
                priorityFreshQueue.enqueue(node);
            }
            actualNode = priorityFreshQueue.dequeue();
            iterator = new DijkstraEdgeIterator(actualNode);
        } catch (PriorityQueueEmptyException ex) {
            print("Chyba pri prvnim vyplyvavani nodu z prioritni fronty");
            System.exit(1);
        }
    }

    /**
     *  Metoda, ktera udela jeden krok v algoritmu. Provede relaxaci jedne hrany.
     * @return Graf po jednom kroku algoritmu
     * @throws AlgorithmFinishedException
     */
    public Graph doStep() throws AlgorithmFinishedException {
        try {
            Edge relaxedEdge = iterator.next();
            relax(relaxedEdge);
        } catch (HasNoNextException ex) {
            try {
                print("pridavam tento node do closed:                 " + actualNode.getName());
                setClosedNodes.add(actualNode);
                actualNode = priorityFreshQueue.dequeue();
                iterator.setActualNode(actualNode);
            } catch (PriorityQueueEmptyException ex1) {
                for (Node node : graph.getNodes()) {
                    String res;
                    String predchudce;
                    if (node.getDistance() != Integer.MAX_VALUE) {
                        res = "" + node.getDistance();
                    } else {
                        res = "nekonecno";
                    }
                    if (node.getPredecessor() == null) {
                        predchudce = "nema";
                    } else {
                        predchudce = "\"" + node.getPredecessor().getName() + "\"";
                    }
                    print("Node \"" + node.getName() + "\" skoncil s predchudcem            "
                            + predchudce + "     a vzdalenosti od zdroje \""
                            + "\"    rovnou          " + res);
                }
                throw new AlgorithmFinishedException();
            }
            return doStep();
        }

        return graph.clone();
    }

    /**
     * Pomocna metoda relaxujici parametricky zadanou hranu v grafu. Pokud je koncovy uzel teto hrany jiz uzavreny, tak metoda neudela nic.
     * Relaxace znamena test, zdali neni dosud nalezena cesta delsi nez cesta do Nodu actualNode + delka hrany edge, ktera ma jako koncovy uzel endNode.
     * Pokud ano, tak se zmeni vzdalenost na tuto hodnotu a dal se zmeni predchudce Nodu endNode na actualNode
     * @param edge hrana k relaxaci
     */
    private void relax(Edge edge) {
        Node endNode = edge.getEnd();
        print("Relaxuju hranu z            " + actualNode.getName() + "           do          " + edge.getEnd().getName());
        for (Node node : setClosedNodes) {
            print("zavreny uzel:               " + node.getName());
        }
        if (setClosedNodes.contains(endNode)) {
            return;
        }
        int distance = edge.getLength() + actualNode.getDistance();
        if (endNode.getDistance() > distance) {
            endNode.setDistance(distance);
            endNode.setPredecessor(actualNode);
            priorityFreshQueue.actualize(endNode);
        }
    }

    /**
     * Pomocna metoda slouzici k vytisknuti textove reprezentace daneho kroku. 
     * Tato metoda je urcena k kontrole funkcnosti algoritmu.
     * @param string Zprava, ktera se ma vytisknout
     */
    private void print(String string) {
        System.out.println(string);
    }
}
