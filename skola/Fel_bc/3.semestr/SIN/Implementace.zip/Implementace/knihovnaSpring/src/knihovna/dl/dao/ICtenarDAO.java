package knihovna.dl.dao;

import knihovna.dl.entity.Ctenar;

/**
 * @author Jirka
 * @version 1.0
 * @created 16-VIII-2009 20:21:24
 */
public interface ICtenarDAO {
	
	/**
	 * Vyhled� �ten��e, na z�klad� jeho ��sla pr�kazky.
	 * @param cisloPrukazky	��slo pr�kazky �ten��e.
	 */
	public Ctenar vratCtenare(int cisloPrukazky);

}