%XMLSAVE save variables to file in xml format.
%    XMLSAVE(filename,variable1,variable2,variable3,...) save variables
%    into filename.
% 
%    See also vartostruct

%   Author(s): M. Kutil
%   Copyright (c) 2005
%   $Revision: 2892 $  $Date: 2009-03-18 10:20:37 +0100 (st, 18 III 2009) $

