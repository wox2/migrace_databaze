/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CORE;

/**
 *
 * @author sprinkler
 */
public class FigureException extends Exception{

    public FigureException(String text) {
        super(text);
    }

}
