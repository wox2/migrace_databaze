function graphtoworkspace(g)
    assignin('base','g',g);