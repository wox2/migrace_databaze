/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplication;

import view.ProgramWin;
import view.Painter;
import view.IPainter;
import Core.*;
import Exceptions.AlgorithmFinishedException;

/**
 * Trida, ktera zajistuje spravne rozesilani udalosti ostatnim tridam.
 * @author woxie
 */
public class Controller implements Runnable {

    private Steppable algorithm;
    private ProgramWin programWin;
    private IPainter painter;
    private Graph graph;
    private boolean finished;
    private boolean runAlgorithm;
    private int SLEEPING_TIME = 1000;

    /**
     * Konstruktor, dostane algoritmus Steppable jako parametr, nastavi si potrebne atributy na false
     * @param algorithm algoritmus, nad kterym Controller pracuje
     */
    public Controller(Steppable algorithm) {
        this.algorithm = algorithm;
        finished = false;
        runAlgorithm=false;
    }

    /**
     * Prida view tomuto Controlleru, nastavi Paintera.
     * @param view pridavane ProgramWin
     */
    public void addView(ProgramWin view) {
        this.programWin = view;
        painter = new Painter(programWin);

    }

    /**
     * Udela krok algoritmu a necha vykreslit painterem
     */
    public void doStep() {
        try {
            graph = algorithm.doStep();
            painter.repaintGraph(graph);
        } catch (AlgorithmFinishedException ex) {
            finished = true;
            runAlgorithm = false;
        }
    }
/**
 * Vykresli graph.
 * @param graph graph k vykresleni.
 */
    public void drawGraph(Graph graph) {
        clear();
        painter.paintGraph(graph);
    }

    public void drawGraph(){
        clear();
        System.out.println("kresl"+graph);
        painter.repaintGraph(graph);
    }

    /**
     * Nastavi algoritmus, ktery se ma provadet.
     * @param algorithm algoritmus k provadeni
     */
    public void setAlgorithm(Steppable algorithm) {
        this.algorithm = algorithm;
        finished = false;
    }
    
    /**
     *  Smaze obrazovku s predchozim prubehem algoritmu.
     */
    public void clear() {
        painter.clear();
    }

    public void run() {
        runAlgorithm=true;
        while (true) {
            while (!finished && runAlgorithm) {
                try {
                    Thread.sleep(SLEEPING_TIME);
                    doStep();
                } catch (InterruptedException ex) {
                    System.out.println("Error");
                    System.exit(1);
                }
            }

        }

    }
    /**
     * Nastavi graf sobe, je nutne pred prvnim pouzitim.
     * @param graph
     */
    public void setGraph(Graph graph){
        this.graph=graph;
    }
}
