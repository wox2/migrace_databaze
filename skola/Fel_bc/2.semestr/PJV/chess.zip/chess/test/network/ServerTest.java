/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sprinkler
 */
public class ServerTest {

//    Client client = new Client();
//    TestServerRunnable testServerRunnable = new TestServerRunnable();
//    Thread serverThread = new Thread(testServerRunnable);

    public ServerTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Test
    public void testAcceptData() {
//        try {
//            serverThread.start();
//            client.sendData("test");
//            serverThread.join();
//            assertTrue(testServerRunnable.data.equals("test"));
//        } catch (InterruptedException ex) {
//            System.err.println(ex);
//        }
    }
}