
What files do you have to edit:
TASK 1:
 -> render_stuff.cpp: 238, 251, 350
 -> data.h: 41
TASK 2:
 -> render_stuff.cpp: 264, 273, 285, 355
 -> data.h: 49, 55
TASK 3:
 -> render_stuff.cpp: 299, 326, 359
 -> data.h: 62
TASK 4:
 -> render_stuff.cpp: 312, 363
 -> data.h: 68
TASK 5:
 -> data.h: 74
