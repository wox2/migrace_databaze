/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.datacontainers;

/**
 * Represents a bank payment.
 * NOT IMPLEMENTED
 * @author murinr
 */
public class BankPayment extends Payment{

    public BankPayment() {
    }
    
    
    
}
