/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.client;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import cz.cvut.fel.shared.ChessCell;
import cz.cvut.fel.shared.Jewel;

/**
 *
 * @author xklima
 */
public class InformationPanel extends VerticalPanel implements ChessCellListener {

    Label label = new Label();

    public InformationPanel() {
        this.add(label);
    }

    public void cellUpdated(CellEvent e) {
        ChessCell cell = e.getSource();
        if (e.getEvent() == CellEvent.CELL_SELECTED) {
            String text = "Vybráno pole " + cell.getX() + ", " + cell.getY();

            text += ", barva: "
                    + (cell.getType() == ChessCell.WHITE ? "bílá" : "černá");
            if (cell.getJewel() != null) {
                text += ", kámen "
                        + (cell.getJewel().getColor() == Jewel.BLACK ? "černý" : "bílý");
            } else {
                text += "bez kamene";
            }
            setMessage(text);
            return;
        }

        if (e.getEvent() == CellEvent.CELL_DESELECTED) {
            this.setMessage("-----------");
            return;
        }
    }

    public void setMessage(String message) {
        this.label.setText(message);
    }
}
