#include "printHello.h"
#include "printWorld.h"

int main(){
	printHello();
	printWorld();

	return 0;
}

