//============================================================================
// Name        : Cviceni6-example2.cpp
// Author      : vikturek
// Version     :
// Copyright   : 
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

vector<int> serad1(vector<int> cisla){
	sort(cisla.begin(), cisla.end());
	return cisla;
}

void serad2(vector<int> &cisla){
	sort(cisla.begin(), cisla.end());
}

void serad3(vector<int> *cisla){
	sort(cisla->begin(), cisla->end());
}


int main() {
	vector<int> cisla;
	for(int i = 9; i >= 0; --i){
		cisla.push_back(i);
	}
	// cisla = serad1(cisla);
	// serad2(cisla);
	// serad3(&cisla);
	for(unsigned int i = 0; i < cisla.size(); ++i){
		cout << cisla[i] << " ";
	}
	cout << endl;
	return 0;
}
