package knihovna.bl.vypujcky;
import java.util.*;
import knihovna.dl.dao.IVytiskDAO;
import knihovna.dl.entity.Vytisk;

/**
 * T��da zapouzdr�uj�c� logiku souvisej�c� s evidenc� v�tisk�, jejich n�kupem a
 * vy�azov�n�m z knihovny.
 * @author Ji�� Mlejnek
 * @version 1.0
 * @updated 07-IX-2009 21:37:58
 */
public class SpravceVytisku {

	/**
	 * Rozhran� umo��uj�c� persistentn� ukl�d�n� z�znam� o v�tisc�ch.
	 */
	public IVytiskDAO vytiskDAO;
	
	/**
	 * Umo��uje nastavit t��du implementuj�c� rozhran� IVytiskDAO
	 * @param vytiskDAO	Instance t��dy implementuj�c� rozhran� IVytiskDAO.
	 */
	public void setVytiskDAO(IVytiskDAO vytiskDAO) {
		this.vytiskDAO = vytiskDAO;
	}

	/**
	 * Na z�klad� eviden�n�ho ��sla vyhled� konkr�tn� v�tisk
	 * @param evidencniCislo	Eviden�n� ��slo v�tisku, kter� m� b�t vyhled�n.
	 */
	public VytiskDTO vyhledejVytisk(String evidencniCislo){
		Vytisk vytisk=this.vytiskDAO.vratVytisk(evidencniCislo);
		VytiskDTO vytiskDTO = new VytiskDTO(vytisk);
		return vytiskDTO;
	}
	
	/**
	 * Trvale ulo�� zm�ny ve v�tisku.
	 * 
	 * @param vytisk    V�tisk, kter� m� b�t ulo�en.
	 */
	public void ulozVytisk(VytiskDTO vytisk){
		this.vytiskDAO.ulozVytisk(vytisk.getVytisk());
	}
	
	/**
	 * Vr�t� seznam v�tisk�, kter� jsou aktu�ln� vyp�j�eny.
	 */
	public List<VytiskDTO> vratVypujceneVytisky(){
		List<Vytisk> vypujceneVytisky = this.vytiskDAO.vratVypujceneVytisky();
		List<VytiskDTO> volneVytiskyDTO = konvertujVytisky(vypujceneVytisky);
		return volneVytiskyDTO;
	}

	/**
	 * P�evede kolekci t��dy Vytisk na kolekci t��dy VytiskDTO.
	 * @param volneVytisky 	Kolekce v�tisk�, kter� m� b�t p�evedena.
	 * @return	Kolekce p�eveden�ch v�tisk�.
	 */
	private List<VytiskDTO> konvertujVytisky(List<Vytisk> volneVytisky) {
		List<VytiskDTO> volneVytiskyDTO = new ArrayList<VytiskDTO>();
		VytiskDTO vytiskDTO;
		for (Vytisk vytisk : volneVytisky) {
			vytiskDTO = new VytiskDTO(vytisk);
			volneVytiskyDTO.add(vytiskDTO);
		}
		return volneVytiskyDTO;
	}

	
	/**
	 * Vr�t� seznam v�tisk�, kter� jsou v knihovn� k dispozici.
	 * @return	Seznam voln�ch v�tisk�
	 */
	public List<VytiskDTO> vratVolneVytisky(){
		List<Vytisk> volneVytisky = this.vytiskDAO.vratVolneVytisky();
		List<VytiskDTO> volneVytiskyDTO = konvertujVytisky(volneVytisky);
		return volneVytiskyDTO;
	}
}