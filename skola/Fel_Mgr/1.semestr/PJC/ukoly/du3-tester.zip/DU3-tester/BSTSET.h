/*
 * BSTSET.h
 *
 *  Created on: ...
 *      Author: ...
 */

#ifndef BSTSET_H_
#define BSTSET_H_

/*****************************************************
*  Zde je misto pra vasi implementaci tridy BSTSET.  *
*****************************************************/

#endif /* BSTSET_H_ */
