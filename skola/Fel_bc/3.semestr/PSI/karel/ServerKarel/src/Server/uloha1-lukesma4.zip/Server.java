
import java.net.*;
import java.io.*;
import java.util.Random;

/**
 * @author woxie alias Martin Lukes         
 */
public class Server implements Runnable{
    String message = "";                         //prichozi zprava
    Robot karel;                                 //robot
    PrintWriter out = null;
    BufferedReader in = null;
    Socket client;
    String nick = "Ty pekelny stroji Ty pekelny stroji Ty pekelny stroji";          //osloveni
    String inBuffer = "";

    public static void main(String[] args) throws IOException {     
        Socket clientSocket = null;             //socket clienta
        int  port = Integer.decode(args[0]);    // port
        ServerSocket serverSocket = new ServerSocket(port);
        boolean isReady = true;

        while (isReady) {

            try {
                clientSocket = serverSocket.accept();
                clientSocket.setSoTimeout(600000);
                clientSocket.setTcpNoDelay(true);
            } catch (IOException e) {
                System.err.println("Accept failed.");
                System.exit(1);
            }
            System.out.println("client accepted from: " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());
            if (clientSocket != null) {
                Thread vlakno = new Thread(new Server(clientSocket));
                vlakno.start();
            }
            if (!isReady) {
                break;
            }
        }
        clientSocket.close();
        serverSocket.close();
    }

    public Server(Socket clientSocket){
        this.client = clientSocket;
    }


    public void printAndSendCommand(String command, PrintWriter out) {
        System.out.println(command);
        out.print(command + "\r\n");
        out.flush();
    }

    public String readLn(BufferedReader in) {
        String incomingMessage = "";
            int nummerOfChar = -1;                       //cislo znaku

            boolean isRFound = false;                          //boolean znaci, jestli se provedlo \r
            while (true) {
                try {
                    nummerOfChar = in.read();
                } catch (Exception e) {
                    System.out.println(e);
                    return "";
                }
                if (nummerOfChar == -1) {
                    break;
                }
                if (nummerOfChar == (int) '\r') {                   //\r objeven
                    isRFound = true;
                } else if (nummerOfChar == (int) ('\n') && isRFound) {    //nasleduje-li \n
                    break;
                } else {
                    incomingMessage = incomingMessage + ((char) nummerOfChar);
                    isRFound = false;
                    if (incomingMessage.length() > 512) {
                        incomingMessage = "";
                    }
                }
            }


        return incomingMessage;
    }

    @Override
    public void run() {
        try {
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        } catch (IOException e) {
            System.err.println(e);
            System.exit(1);
        }
        karel = new Robot();

        printAndSendCommand("220 Dokazal jsi se pripojit, peklo zacalo. Oslovuj mne " + nick + ".", out);

        while (true) {
            /*               */
            try {
                message = readLn(in);
            } catch (Exception exc) {
                System.out.println(exc);
                continue;
            }
            if (message.equals("")) {
                printAndSendCommand("500 NEZNAMY PRIKAZ", out);
                continue;
            }
            System.out.println(message);
            if ((message.equals(nick + " VLEVO"))) {
                karel.turnLeft();
                printAndSendCommand("250 OK " + karel.getLocation(), out);
            } else if (message.equals(nick + " KROK")) {
                try {
                    karel.doStep();
                } catch (RobotDestroyedException e) {
                    printAndSendCommand("572 ROBOT SE ROZPADL", out);
                    break;
                } catch (RobotBrokenException e) {
                    printAndSendCommand("570 PORUCHA BLOK " + e.brokenBlock, out);
                    continue;
                }
                if (karel.isInsideTheCity()) {
                    printAndSendCommand("250 OK " + karel.getLocation(), out);
                } else {
                    printAndSendCommand("530 HAVARIE", out);
                    break;
                }
            } else if ((message.equals(nick + " ZVEDNI"))) {
                if (karel.isAtZeroZero()) {   // pokud je na pocatku, vyzvedne tajemstvi
                    printAndSendCommand("221 USPECH Vsichni milujeme progtest...", out);
                    break;
                } else {
                    printAndSendCommand("550 NELZE ZVEDNOUT ZNACKU", out);
                    break;
                }
            } else {
                if (message.equals(nick + " OPRAVIT 1") || message.equals(nick + " OPRAVIT 2") || message.equals(nick + " OPRAVIT 3") || message.equals(nick + " OPRAVIT 4") ||
                        message.equals(nick + " OPRAVIT 5") || message.equals(nick + " OPRAVIT 6") || message.equals(nick + " OPRAVIT 7") || message.equals(nick + " OPRAVIT 8") || message.equals(nick + " OPRAVIT 9")) {
                    if (karel.getBrokenBlock() == (int) message.charAt(message.length() - 1) - (int) '0') {
                        printAndSendCommand("250 OK " + karel.getLocation(), out);
                        karel.repair(karel.getBrokenBlock());
                    } else {
                        printAndSendCommand("571 NENI PORUCHA", out);
                        break;
                    }
                } else {
                    printAndSendCommand("500 NEZNAMY PRIKAZ", out);
                }
            }
        }
        out.close();
        try {
            in.close();
        } catch (IOException ex) {
        }
    }
}

class RobotDestroyedException extends Exception {

    public RobotDestroyedException() {
    }
}

class RobotBrokenException extends Exception {

    int brokenBlock;

    public RobotBrokenException(int block) {
        brokenBlock = block;
    }
}


 

class Robot {

    private int x;
    private int y;
    private int dir;
    private int count = 0;
    private boolean broken = false;
    private int brokenBlock = 0;

    public Robot() {                  //konsturktor
        Random r = new Random();             //random location
        x = r.nextInt(33) - 16;
        y = r.nextInt(33) - 16;
        dir = r.nextInt(4);
    }

    String getLocation() {                       //vrati umisteni robota
        return "(" + x + "," + y + ")";
    }

    void turnLeft() {                                //otoci se doleva
        dir = ((dir + 1) % 4);
    }

    void repair(int repairedBlock) {
        broken = false;
    }

    void doStep() throws RobotDestroyedException, RobotBrokenException {                                // udela krok
        Random rand = new Random();
        if (broken) {
            throw new RobotDestroyedException();
        }
        int random = rand.nextInt(10);
        if (count == 10 || random == 5) {
            broken = true;
            brokenBlock = rand.nextInt(9) + 1;
            count = 0;
            throw new RobotBrokenException(brokenBlock);
        } else {
            count++;
            switch (dir) {
                case 0:
                    y++;
                    break;
                case 1:
                    x--;
                    break;
                case 2:
                    y--;
                    break;
                case 3:
                    x++;
                    break;
            }
        }
    }

    int getBrokenBlock() {
        return brokenBlock;
    }

    boolean isAtZeroZero() {                         //overi, jestli je u znacky
        if (y == 0 && x == 0) {
            return true;
        } else {
            return false;
        }
    }

    boolean isInsideTheCity() {                             //je v meste
        if (y > 17 || x > 17 || y < -17 || x < -17) {
            return false;
        } else {
            return true;
        }
    }
}
