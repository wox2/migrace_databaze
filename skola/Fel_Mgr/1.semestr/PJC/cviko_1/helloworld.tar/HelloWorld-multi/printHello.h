#include <iostream>

void printHello();
