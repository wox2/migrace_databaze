/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Core;

import Core.MyIterator;
import Core.Node;
import Core.Edge;
import Exceptions.HasNoNextException;
import java.util.List;

/**
 * Iterator hran v prubehu algoritmu Dijkstra.
 * @author woxie
 */

public class DijkstraEdgeIterator implements MyIterator {
    List <Edge>edgeList;
    int actualEdge;
    Node actualNode;

    /**
     * Konstruktor
     * @param node Node, jehoz hrany se budou iterovat.
     */
    public DijkstraEdgeIterator(Node node) {
        edgeList = node.getEdges();
        actualEdge=0;
        actualNode = node;
    }
    /**
     * Vymena Nodu, ktery se iteruje
     * @param node Node, jehoz hrany se prochazeji.
     */
    public void setActualNode(Node node){
        actualNode=node;
        edgeList = node.getEdges();
        actualEdge = 0;
    }

    /**
     * Kontroluje, jestli ma Node dalsi hranu nebo uz byly proiterovany vsechny.
     * Pokud byly proiterovany vsechny hrany, vrati false, jinak true
     * @return boolean znacici, jestli byly proiterovany vsechny hrany nebo ne
     */
    public boolean hasNext() {
        if(actualEdge>edgeList.size()) return false;
        return true;
    }

    /**
     * Vrati dalsi hranu, v pripade, ze neni dalsi vyhodi vyjimku.
     * @return dalsi hranu, ktera se ma zpracovavat.
     * @throws HasNoNextException vyhozena vyjimka, pokud jiz neni dalsi hrana.
     */
    public Edge next() throws HasNoNextException{
        actualEdge++;
        if(!hasNext()) throw new HasNoNextException();
        return edgeList.get(actualEdge-1);
    }



}
