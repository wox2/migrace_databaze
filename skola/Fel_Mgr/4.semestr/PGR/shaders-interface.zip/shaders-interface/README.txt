
What files do you have to edit:
TASK 1:
 -> shaders-interface.cpp: 96
TASK 2:
 -> shaders-interface.cpp: 151, 168, 181
TASK 3:
 -> shaders-interface.cpp: 105, 129
