/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import cz.cvut.fel.shared.ChessCell;

/**
 * Main entry point.
 *
 * @author xklima
 */
public class DamaEntryPoint implements EntryPoint {

    private static final DamaServiceAsync damaService = GWT.create(DamaService.class);
    private Chessboard ch = null;

    /**
     * This is the entry point method.
     */
    public static DamaServiceAsync getDamaService() {
        return damaService;
    }

    public void onModuleLoad() {
        final Button start = new Button();
        start.setText("Nová hra");
        start.addClickHandler(new ClickHandler() {
            @Override
            public void onClick(ClickEvent event) {
                damaService.startDama(new AsyncCallback<ChessCell[][]>() {

                    public void onFailure(Throwable caught) {
                        // todo on failure
                    }

                    public void onSuccess(ChessCell[][] result) {
                        Chessboard chessboard = new Chessboard(result);
                        if (null != ch) {
                            RootPanel.get("sachovnice").remove(ch);
                        }
                        RootPanel.get("sachovnice").add(chessboard);
                        ch = chessboard;

                    }
                });
            }
        });

        final InformationPanel infopanel = new InformationPanel();
        RootPanel.get("infopanel").add(infopanel);

        damaService.getDama(new AsyncCallback<ChessCell[][]>() {

            public void onFailure(Throwable caught) {
                // todo on failure
                System.out.println("error");
            }

            public void onSuccess(ChessCell[][] result) {
                RootPanel.get("ovladani").add(start);
                Chessboard chessboard = new Chessboard(result);
                if (null != ch) {
                    RootPanel.get("sachovnice").remove(ch);
                }
                RootPanel.get("sachovnice").add(chessboard);
                ch = chessboard;
                ch.addChessCellListener(infopanel);
            }
        });

       
    }
    //}
}
