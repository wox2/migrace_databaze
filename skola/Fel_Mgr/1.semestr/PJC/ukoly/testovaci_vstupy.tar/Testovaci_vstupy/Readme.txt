
**********************************************************************
* Testovaci vstupy pro domaci ukol 1 predmetu PJC zimni semestr 2011 *
**********************************************************************

Sady vstupu test1.X a test2.X jsou i v testeru porad stejne.

Sada vstupu test3.X je v testeru generovana primo za chodu a uzivatel 
ma k dispozici vzdy pouze ten vstup, na kterem jeho aplikace selhala.
V teto slozce je k dispozici sada 100 vygenerovanych vstupu, ktere
jsou ekvivalentni s temi, se kterymi se testovana aplikace setka
v testeru!

