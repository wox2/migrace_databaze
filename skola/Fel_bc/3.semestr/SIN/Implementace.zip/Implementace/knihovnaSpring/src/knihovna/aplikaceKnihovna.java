package knihovna;

import knihovna.pl.view.KnihovnaGUI;

import org.springframework.context.*;
import org.springframework.context.support.*;

public class aplikaceKnihovna {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		ApplicationContext ctx= new ClassPathXmlApplicationContext(new String[]{"knihovna/application-context-dl.xml","knihovna/application-context-bl.xml","knihovna/application-context-pl.xml"});
		KnihovnaGUI knihovna = (KnihovnaGUI)ctx.getBean("knihovnaGUI");
		knihovna.setVisible(true);

	}

}
