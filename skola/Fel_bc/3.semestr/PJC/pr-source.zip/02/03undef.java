class undef
 {
  
   public static void main ( String argv [] )
    {
      int a, c;
      
      a = 1;
      
      c = a ++ + a ++;
      
      System . out . println ( "a = " + a );
      System . out . println ( "c = " + c );
    }
 };