class MyClass{
public:
	bool empty(){
		return true;
	}
};

