@javax.xml.bind.annotation.XmlSchema(namespace = "http://interfaceserver.murinrad.fee.ctu.cz/")
package cz.ctu.fee.murinrad.ifaceserver;
