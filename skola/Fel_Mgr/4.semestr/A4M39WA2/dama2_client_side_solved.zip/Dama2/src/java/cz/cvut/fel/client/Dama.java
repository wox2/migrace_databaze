package cz.cvut.fel.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.RootPanel;
import cz.cvut.fel.shared.ChessCell;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Dama implements EntryPoint {

    private static final DamaServiceAsync damaService = GWT.create(DamaService.class);
    private Chessboard ch = null;
    /**
     * This is the entry point method.
     */
    public static DamaServiceAsync getDamaService() {
        return damaService;
    }

    public void onModuleLoad() {
        // Chessboard chessboard = new Chessboard();
        // RootPanel.get("sachovnice").add(chessboard);

        final Button start = new Button();
        start.setText("Start");
        start.addClickHandler(new ClickHandler() {

            @Override
            public void onClick(ClickEvent event) {
                damaService.getDama(new AsyncCallback<ChessCell[][]>() {

                    public void onFailure(Throwable caught) {
                        // todo on failure
                    }

                    public void onSuccess(ChessCell[][] result) {
                        Chessboard chessboard = new Chessboard(result);
                        if (null != ch) {
                            RootPanel.get("sachovnice").remove(ch);
                        }
                        RootPanel.get("sachovnice").add(chessboard);
                        ch = chessboard;

                    }
                });
            }
        });
     //   RootPanel.get("ovladani").add(start);
        damaService.getDama(new AsyncCallback<ChessCell[][]>() {

            public void onFailure(Throwable caught) {
                // todo on failure
            }

            public void onSuccess(ChessCell[][] result) {
                RootPanel.get("ovladani").add(start);
                Chessboard chessboard = new Chessboard(result);
                if (null != ch) {
                    RootPanel.get("sachovnice").remove(ch);
                }
                RootPanel.get("sachovnice").add(chessboard);
                ch = chessboard;

            }
        });
    }
}
