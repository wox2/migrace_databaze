/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplication;

import view.ProgramWin;

/**
 *
 * @author woxie
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    ProgramWin pwin = ProgramWin.getProgramWindow();
    pwin.draw();
    }
}

