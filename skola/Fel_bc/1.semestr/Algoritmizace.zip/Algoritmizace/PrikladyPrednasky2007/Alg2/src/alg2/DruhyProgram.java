package alg2;

public class DruhyProgram {
  public static void main(String[] args) {
    int x = 10, y;
    y = x + 20;
    System.out.print("hodnota prom�nn� x je "+x);
    System.out.println("hodnota prom�nn� y je "+y);
    int a = 1, c = 2;
    System.out.println("sou�et je" +a+c+"hhyyuiki");
  }
}