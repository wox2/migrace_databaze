#include "printHello.h"

void printHello(){
	std::cout << "Hello ";
}

