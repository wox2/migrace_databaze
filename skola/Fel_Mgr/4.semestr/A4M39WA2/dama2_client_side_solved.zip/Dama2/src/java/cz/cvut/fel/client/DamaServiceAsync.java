/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import cz.cvut.fel.shared.ChessCell;

/**
 *
 * @author xklima
 */
public interface DamaServiceAsync {

    void startDama(AsyncCallback<ChessCell[][]> callback)
            throws IllegalArgumentException;

    void cellClicked(ChessCell chessCell, AsyncCallback<ChessCell[]> callback)
            throws IllegalArgumentException;

    void move(ChessCell from, ChessCell to, AsyncCallback<ChessCell[]> callback);

    public void getDama(AsyncCallback<ChessCell[][]> asyncCallback);
}
