package knihovna.dl.dao.hibernate;

import java.util.List;

import knihovna.dl.dao.IVypujckaDAO;
import knihovna.dl.entity.Ctenar;
import knihovna.dl.entity.Vypujcka;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * T��da umo��uje ukl�d�n� a na��t�n� z�znam� o proveden�ch v�puj�k�ch
 * jednotliv�ch v�tisk�.
 * @author Ji�� Mlejnek
 * @version 1.0
 * @updated 04-IX-2009 19:57:03
 */
public class VypujckaDAO extends HibernateDaoSupport implements IVypujckaDAO {
	
	
	public VypujckaDAO(){
	}

	/**
	 * Vr�t� seznam v�ech v�puj�en�ch v�tisk� dan�ho �ten��e.
	 * @param ctenar    �ten�� jeho� v�p�j�ky m� metoda vr�tit.
	 */
	public List<Vypujcka> vratVypujckyCtenare(Ctenar ctenar) {
		//TODO
		return this.getHibernateTemplate().loadAll(Vypujcka.class);
	}
	
	public Vypujcka getVypujcka(){
		return this.getHibernateTemplate().get(Vypujcka.class,1);
	}


}