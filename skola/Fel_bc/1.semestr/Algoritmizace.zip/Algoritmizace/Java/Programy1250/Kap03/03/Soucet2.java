/* S��t�n� dvou ��sel - druh� pokus
   soubor kap03\04\Soucet2.java
*/

public class Soucet2 {
  public static void main(String[] arg){
    int i = 12; // Prvn� s��tanec
    int j = 25; // Druh� s��tanec
    int k = i+j;// Sou�et
    System.out.print("Soucet cisel ");
    System.out.print(i);
    System.out.print(" + ");
    System.out.print(j);
    System.out.print(" je ");
    System.out.println(k);
  }
};