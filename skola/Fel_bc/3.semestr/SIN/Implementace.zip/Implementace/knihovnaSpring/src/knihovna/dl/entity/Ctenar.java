package knihovna.dl.entity;

import java.io.Serializable;

import javax.persistence.*;





/**
 * @author Jirka
 * @version 1.0
 * @created 16-VIII-2009 20:21:16
 */
@Entity
public class Ctenar implements Serializable {

	/**
	 * Jendozna�n� identifik�tor �ten��e v datab�zi.
	 */
	@Id
	private int ctenarid;
	/**
	 * ��slo pr�kazky �ten��e.
	 */
	private int cisloprukazky;
	/**
	 * Emailov� adresa �ten��e.
	 */
	private String email;
	/**
	 * Jm�no �ten��e.
	 */
	private String jmeno;
	/**
	 * P��jmen� �ten��e.
	 */
	private String prijmeni;
	/**
	 * Telefonn� ��slo �ten��e.
	 */
	private String telefon;
	private static final long serialVersionUID = 1L;

	public Ctenar(){

	}

	public int getCtenarid(){
		return ctenarid;
	}

	/**
	 * 
	 * @param ctenarid
	 */
	public void setCtenarid(int ctenarid){
		this.ctenarid=ctenarid;
	}

	public int getCisloprukazky(){
		return cisloprukazky;
	}

	/**
	 * 
	 * @param cisloprukazky
	 */
	public void setCisloprukazky(int cisloprukazky){
		this.cisloprukazky=cisloprukazky;
	}

	public String getEmail(){
		return this.email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email){
		this.email=email;
	}

	public String getJmeno(){
		return this.jmeno;
	}

	/**
	 * 
	 * @param jmeno
	 */
	public void setJmeno(String jmeno){
		this.jmeno=jmeno;
	}

	public String getPrijmeni(){
		return this.prijmeni;
	}

	/**
	 * 
	 * @param prijmeni
	 */
	public void setPrijmeni(String prijmeni){
		this.prijmeni=prijmeni;
	}

	public String getTelefon(){
		return this.telefon;
	}

	/**
	 * 
	 * @param telefon
	 */
	public void setTelefon(String telefon){
		this.telefon=telefon;
	}

}