/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import java.awt.geom.Dimension2D;

/**
 * Trida reprezentuje ORIENTOVANOU hranu vedouci do Nodu end.
 * Je tu chyba v tom, ze hrana je pridavana pocatecnimu  Nodu jako atribut, sice dostava pocatecni
 * Node jako parametr, ale uchovava si jen jeho souradnice.
 * @author woxie
 */
public class Edge {

    /**
     * Souradnice pocatecniho Nodu.
     */
    private Dimension2D dimensionFrom;
    /**
     * Souradnice koncoveho Nodu.
     */
    private Dimension2D dimensionTo;
    /**
     * atribut to - Node, do ktereho vede dana hrana.
     */
    private Node to;
    /**
     *  Atribut length reprezentuje delku dane hrany.
     */
    private int length;

    /**
     * Konstruktor, vytvori hranu o dane vzdalenosti, nastavi koncovy uzel.
     * @param distance delka hrany
     * @param EndNode Node, kterym je hrana zakoncena
     */
    public Edge(int distance, Node endNode, Node startNode) {
        length = distance;
        to = endNode;
        dimensionFrom = startNode.getDimension();
        dimensionTo = endNode.getDimension();
    }

    /**
     * Metoda navracici delku hrany.
     * @return delku hrany
     */
    public int getLength() {
        return length;
    }

    /**
     * Metoda, ktera vraci koncovy uzel hrany.
     * @return koncovy Node hrany
     */
    public Node getEnd() {
        return to;
    }

    /**
     * Metoda vraci Dimenzi2D koncoveho bodu hrany.
     * @return Dimension2D pocatecniho bodu hrany
     */
    public Dimension2D getToDimension() {
        return dimensionTo;
    }

    /**
     * Metoda vraci Dimenzi2D pocatecniho bodu hrany.
     * @return Dimension2D pocatecniho bodu hrany
     */
    public Dimension2D getFromDimension() {
        return dimensionFrom;
    }

    /**
     * Metoda navraci x-ovou pozici koncoveho Nodu
     * @return X pozice koncoveho Nodu
     */
    public int getEndX() {
        return (int) dimensionTo.getWidth();
    }

    /**
     * Metoda navraci y-ovou pozici koncoveho Nodu
     * @return Y pozice koncoveho Nodu
     */
    public int getEndY() {
        return (int) dimensionTo.getHeight();
    }

    /**
     * Metoda navraci x-ovou pozici pocatecniho Nodu
     * @return X pozice pocatecniho Nodu
     */
    public int getStartX() {
        return (int) dimensionFrom.getWidth();
    }

    /**
     * Metoda navraci y-ovou pozici pocatecniho Nodu
     * @return X pozice pocatecniho Nodu
     */
    public int getStartY() {
        return (int) dimensionFrom.getHeight();
    }
}
