/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Exceptions;

/**
 * Vyjimka vyhozena, pokud algoritmus skoncil.
 * @author woxie
 */
public class AlgorithmFinishedException extends Exception {

    public AlgorithmFinishedException() {
        System.out.println("Algoritmus skoncil");
    }

}
