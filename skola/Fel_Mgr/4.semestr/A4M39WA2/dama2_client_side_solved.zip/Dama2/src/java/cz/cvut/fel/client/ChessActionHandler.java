package cz.cvut.fel.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

import cz.cvut.fel.shared.ChessCell;
import java.util.ArrayList;

public class ChessActionHandler {

    private static final ChessActionHandler instance = new ChessActionHandler();
    protected ArrayList<ChessCellListener> listeners = new ArrayList<ChessCellListener>();

    public static ChessActionHandler getInstance() {
        return ChessActionHandler.instance;
    }

    public void cellClicked(ChessCellViz cell, final Chessboard chessboard) {
        if (chessboard.getFirstSelected() == null) {
            chessboard.setFirstSelected(cell);
            cell.select();
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_SELECTED));
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_CLICKED));
            return;
        }

        if (chessboard.getFirstSelected().equals(cell)) {
            // znovu kliknuto na uz oznacene pole
            cell.unselect();
            chessboard.setFirstSelected(null);
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_DESELECTED));
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_CLICKED));
            return;
        }

        if (chessboard.getSecondSelected() == null) {
            chessboard.setSecondSelected(cell);
            cell.select();
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_SELECTED));
            distributeEvent(new CellEvent(cell.getChessCell(), CellEvent.CELL_CLICKED));

            // dalsi kroky vyresi server
            DamaEntryPoint.getDamaService().move(
                    chessboard.getFirstSelected().getChessCell(),
                    chessboard.getSecondSelected().getChessCell(),
                    new AsyncCallback<ChessCell[]>() {

                        @Override
                        public void onSuccess(ChessCell[] result) {
                            // vrati pole policek, ktera se maji zmenit
                            for (int i = 0; i < result.length; i++) {
                                ChessCell currentCell = result[i];
                                ChessCellViz chcv = chessboard.getCell(
                                        currentCell.getX(), currentCell.getY());
                                chcv.setChessCell(currentCell);
                            }
                            chessboard.getFirstSelected().unselect();
                            chessboard.getSecondSelected().unselect();
                            distributeEvent(new CellEvent(
                                    chessboard.getFirstSelected().getChessCell()
                                    , CellEvent.CELL_DESELECTED));
                            distributeEvent(new CellEvent(
                                    chessboard.getSecondSelected().getChessCell()
                                    , CellEvent.CELL_DESELECTED));
                            chessboard.setFirstSelected(null);
                            chessboard.setSecondSelected(null);

                        }

                        @Override
                        public void onFailure(Throwable caught) {
                            // TODO Auto-generated method stub
                        }
                    });
        }
    }

    void setListeners(ArrayList<ChessCellListener> listeners) {
        this.listeners = listeners;
    }

    protected void distributeEvent(CellEvent e) {
        for (ChessCellListener listener : this.listeners) {
            listener.cellUpdated(e);
        }
    }
}
