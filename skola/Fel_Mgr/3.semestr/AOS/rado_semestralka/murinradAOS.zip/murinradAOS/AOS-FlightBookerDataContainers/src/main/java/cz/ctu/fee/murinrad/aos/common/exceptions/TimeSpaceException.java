/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.exceptions;

/**
 *
 * @author Radovan Murin
 */
public class TimeSpaceException extends Exception {

    public TimeSpaceException(String message, Throwable cause) {
        super(message, cause);
    }
    
    
    
}
