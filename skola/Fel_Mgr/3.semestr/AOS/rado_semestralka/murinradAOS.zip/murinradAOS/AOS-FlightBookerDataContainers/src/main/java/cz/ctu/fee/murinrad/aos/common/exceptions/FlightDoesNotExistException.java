/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.exceptions;

/**
 *
 * @author Radovan Murin
 */
public class FlightDoesNotExistException extends Exception{

    public FlightDoesNotExistException(String message, Throwable cause) {
        super(message, cause);
    }
     
    
}
