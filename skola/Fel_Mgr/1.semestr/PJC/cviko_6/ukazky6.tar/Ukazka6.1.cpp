//============================================================================
// Name        : Ukazka1.cpp
// Author      : vikturek
// Description : Priklad demonstruje, datovou shodu mezi ukazatelem a
//               celocislenou promennou. Obe se lisi hlavne v tom, jak jsou
//               interpretovany prekladacem.
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int cislo;
	int *p_cislo;
	long int fakePointer;

	cislo = 5;
	cout << cislo << endl;	// Tiskne 5

	p_cislo = &cislo; // Adresu "cisla" ulozime do ukazatele
	*p_cislo = 10; // Dereference
	cout << cislo << endl;	// Tiskne 10

	fakePointer = (long int) &cislo; // A co ted?
	*(long int *)fakePointer = 15;  // Prekladac ji povazuje za ukazatel
	cout << cislo << endl;	// Tiskne 15

	return 0;
}
