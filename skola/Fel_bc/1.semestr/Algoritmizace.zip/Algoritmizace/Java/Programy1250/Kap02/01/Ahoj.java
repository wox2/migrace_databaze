/* N� prvn� program v Jav� - soubor Ahoj.java */
public class Ahoj {
  public static void main(String[] arg)
  {
   System.out.println("Ahoj, lidi");
  }
}
