package wsintro.topdown;

import org.apache.cxf.tools.wsdlto.WSDLToJava;

public class Generate {

    public static void main( String[] args ) {

        WSDLToJava.main( new String[]{
                "-impl",
                "-server",
                "-d",
                "src/main/java",
                "-p",
                "wsintro.topdown",
                "classpath:textservice.wsdl"
        } );
        System.out.println( "Done!" );
    }
}
