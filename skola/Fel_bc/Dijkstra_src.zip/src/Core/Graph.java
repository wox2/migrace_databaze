/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import java.util.ArrayList;
import java.util.List;

/**
 * Trida realizuje model strutktury nazvane graf.
 * @author woxie
 */
public class Graph {

    /**
     * List Nodu, ktere Graf obsahuje.
     */
    private List<Node> nodes;
    // private List<Edge> edges;
    /**
     * Pocet uzlu v grafu.
     */
    private int numberOfNodes;

    /**
     * Obecny konstruktor. Nastavuje pocet uzlu grafu na nula.
     */
    public Graph() {
        nodes = new ArrayList<Node>();
        numberOfNodes = 0;
    }

    /**
     * Metoda nastavuje vsem uzlum grafum nekonecne vzdalenosti.
     */
    public void setInfinityDistances() {
        for (Node node : nodes) {
            node.setDistance(Integer.MAX_VALUE);
        }
    }

    /**
     * Metoda nastavuje vsem uzlum predchudce jako null.
     */
    public void setNullPrecedessors() {
        for (Node node : nodes) {
            node.setPredecessor(null);
        }
    }

    /**
     * Metoda pridava uzel do grafu.
     * @param node Node, ktery ma byt pridan do Grafu
     */
    public void addNode(Node node) {

        nodes.add(node);
        numberOfNodes++;
    }

    /**
     * Metoda navraci pocet uzlu v grafu.
     * @return pocet Nodu v grafu
     */
    public int getNodesCount() {
        return numberOfNodes;
    }

    /**
     * Navrati node s zadanym jmenem. V nynejsi verzi vraci null, pokud nic nenalezne, v novejsi verzi by metoda
     * mela vyhazovat vyjimku
     * @param name jmeno nodu ktery se ma vratit
     * @return Node s zadanym jmenem
     */
    public Node getNode(String name) {
        Node node;

        for (int i = 0; i < numberOfNodes; i++) {
            node = nodes.get(i);
            if (node.getName().equals(name)) {
                return node;
            }
        }
        return null;
        // throw new NodeNotFoundException("Node "+ name +" not found");
    }

    /**
     * Metoda navrati List vsech uzlu
     * @return List Nodu Graphu
     */
    public List<Node> getNodes() {
        return nodes;
    }

    @Override
    public Graph clone() {
        /*   Graph graph = new Graph();
        for(Node node:this.nodes){
        Node newNode = new Node(node.getName(),node.getX(),node.getY());
        graph.addNode(newNode);
        }

        for(Node node:this.nodes){
        for(Edge edge:node.getEdges()){
        for(Node newNode:graph.nodes){
        if( newNode.getName().equals(null)){}
        }
        }
        }
         */
        return this;
    }
}
