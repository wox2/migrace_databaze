/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import java.awt.Dimension;
import java.awt.geom.Dimension2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Trida Node reprezentuje elementarni strukturu grafu - uzel. Neda se vytvorit deep copy -
 * pri klonovani jednoho Nodu by vznikla kopie cele struktury diky odkazu na predchudce.
 * @author woxie
 */
public class Node {

    /**
     * Velikost daneho Nodu. Navrhove spatne, ale pokud jsou souradnice v teto tride,
     * tak to tak musi byt...
     */
    public static final int velikostNodu = 30;
    /**
     * Promenna name by mela jednoznacne identifikovat Node - mela by byt unikatni.
     */
    private String name;
    /**
     * Vzdalenost distance urcuje vzdalenost pri prochazeni grafu od zdrojoveho (puvodniho) Nodu.
     */
    private int distance;
    /**
     * Predchudce Nodu pri prochazeni Dijkstrovym algoritmem. Pri vytvoreni noveho Nodu je predchudce null.
     */
    private Node predecessor;
    /**
     * List edges reprezentuje vsechny hrany, ktere vedou z daneho uzlu do zbylych uzlu. Predpoklad je, ze se 
     * neobjevuji zaporne hrany, smycky a multihrany jsou nadbytecne.
     */
    private List<Edge> edges;
    //   private String state;
    /**
     * Souradnice Nodu.
     */
    private final Dimension2D dimension;

    /**
     *  Vytvori Node s zadanym jmenem. Bez predka a bez pocize shodnotou vzdalenosti INTEGER.MAX_VALUE.
     * Zatim slepa vetev konstruktoru
     * @param name jmeno uzlu slouzici k jednoznacne identifikaci
     * @deprecated
     */
    public Node(String name) {
        this.distance = Integer.MAX_VALUE;
        predecessor = null;
        this.name = name;
        edges = new ArrayList<Edge>();
        dimension = null;

    }

    /**
     * Konstruktor vytvori Node s zadanym name, distance s maximalni hodnotou , s  predchudcem null, s x-ovou souradnici a s y-ovou souradnici.
     * @param name jmeno vytvareneho Nodu identifikujici tento Node
     */
    public Node(String name, int x, int y) {
        this.distance = Integer.MAX_VALUE;
        predecessor = null;
        this.name = name;
        edges = new ArrayList<Edge>();
        dimension = new Dimension(x, y);
    }

    /**
     * Konstruktor vytvori Node s zadanym name, hodnotou distance a predchudcem null.
     * Tento konstruktor je pouzit jen pri testovani prioritni fronty.
     * @param name jmeno vytvareneho Nodu
     * @param distance vzdalenost do vytvareneho Nodu.
     * @deprecated
     */
    public Node(String name, int distance) {
        this.distance = distance;
        predecessor = null;
        this.name = name;
        edges = new ArrayList<Edge>();
        dimension = new Dimension();
    }

    /**
     * Metoda navracejici vzdalenost urazenou do daneho Nodu.
     * @return vzdalenost do Nodu
     */
    public int getDistance() {
        return distance;
    }

    /**
     * Nastavi Nodu vzdalenost.
     * @param value vzdalenost do Nodu
     */
    public void setDistance(int value) {
        distance = value;
    }

    /**Metoda navracejici odkaz na predchudce Nodu.
     * @return predchudce Nodu
     */
    public Node getPredecessor() {
        return predecessor;
    }

    /** Metoda nastavujici precedessora jako predchudce Nodu.
     * @param predecessor predchudce Nodu
     */
    public void setPredecessor(Node predecessor) {
        this.predecessor = predecessor;
    }

    /**Metoda, ktera prida novou orientovanou hranu z Nodu do endNodu s velikosti length
     *
     * @param endNode koncovy uzel pridavane hrany
     * @param length delka pridavane hrany
     */
    public void addEdge(Node endNode, int length) {
        edges.add(new Edge(length, endNode, this));
    }

    /** Metoda vracici jmeno Nodu.
     * @return jmeno Nodu
     */
    public String getName() {
        return name;
    }

    /**
     * Vrati souradnice (Dimension2D) nodu.
     * @return dimension souradnice Nodu
     */
    public Dimension2D getDimension() {
        return dimension;
    }

    /**
     * Vrati x-ovou souradnici leveho horniho rohu opisujiciho obdelniku.
     * @return X souranici Nodu
     */
    public int getX() {
        return (int) dimension.getWidth();
    }

    /**
     * Metoda vraci y-ovou souradnici Nodu.
     * @return  Y souradnici Nodu
     */
    public int getY() {
        return (int) dimension.getHeight();
    }

    /**
     * List hran, ktere vychazeji z Nodu.
     * @return List<Edge> list hran, ktere vychazeji z Nodu
     */
    public List<Edge> getEdges() {
        return edges;
    }

    /**
     * Navrati hranu predchudce. V nynejsi verzi nevraci niv, pokud nic nenajde,
     * v novejsich by asi mela vyhazovat vyjimku.
     * @return Edge
     * 
     */
    public Edge getEdgeFromPredecessor() {
        for (Edge edge : predecessor.edges) {
            if (edge.getEnd().equals(this)) {
                return edge;
            }
        }
        return null;
    }

    /**
     *  Vraci kopii Nodu.
     * @return vraci kopii Nodu, v teto verzi jen melkou
     */
    @Override
    public Node clone() {
        return this;
    }
}
