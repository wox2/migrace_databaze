package wsintro.bottomup;

public class Main {

    public static void main( String[] args ) {

        System.out.println( "Starting Server ..." );

        // ToDo Startup server

        System.out.println( "Server is ready ..." );
    }
}
