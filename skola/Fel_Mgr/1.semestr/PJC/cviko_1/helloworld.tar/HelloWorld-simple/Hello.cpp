#include <stdio.h>
#include <iostream>

#define NUMBER 100

int main(){
	
	std::cout << "Hello world!" << std::endl;

	printf("%d/n", NUMBER);

	return 0;
}

