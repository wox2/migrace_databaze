// Soubor Kap06\07\Bal.java
// P��klad balen� a vybalov�n�

// JEN JDK 5

public class Bal
{
  public static void main(String[] s)
  {
    Integer n = 3;
    n++;
    System.out.printf("%d", n);
  }
}