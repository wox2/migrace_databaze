pref("extensions.webglinspector.boolpref", false);
pref("extensions.webglinspector.intpref", 0);
pref("extensions.webglinspector.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.webglinspector@noxa.org.description", "chrome://webglinspector/locale/overlay.properties");
