/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

/**
 * Trida znazornuje grafy, ktere jsou predpripravene pro pruchod Dijkstrou.
 * @author woxie
 */
public class Examples {

    private static Graph EXAMPLE1;
    private static Graph EXAMPLE2;
    private static Graph EXAMPLE3;

    /**
     * metoda navraci Example s danym jmenem, trida je synchronizovana jmeny s CheckBoxem v tride ProgramWin.
     * V pripade nenalezeni Examplu metoda vraci null.
     * @param example
     * @return priklad s zadanym jmenem nebo null
     */
    public static Graph getExample(String example) {
        if (example.equals("priklad1")) {
            return getExample1();
        }
        if (example.equals("priklad2")) {
            return getExample2();
        }
        if (example.equals("priklad3")) {
            return getExample3();
        }

        return null;
    }

    /**
     *  Metoda vrati EXAMPLE1
     * @return ukazkovy priklad EXAMPLE1
     */
    public static Graph getExample1() {
        if (EXAMPLE1 != null) {
            return EXAMPLE1;
        }
        Node a = new Node("a", 30, 200);
        Node b = new Node("b", 120, 90);
        Node c = new Node("c", 360, 150);
        Node d = new Node("d", 290, 240);
        Node e = new Node("e", 60, 330);
        Node f = new Node("f", 230, 330);
        Node g = new Node("g", 380, 410);


        a.addEdge(c, 1);
        a.addEdge(b, 3);
        a.addEdge(e, 9);

        b.addEdge(d, 2);

        c.addEdge(d, 5);
        c.addEdge(b, 1);

        d.addEdge(e, 4);
        d.addEdge(f, 1);

        f.addEdge(g, 2);
        f.addEdge(e, 1);

        Graph graph = new Graph();
        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);
        graph.addNode(d);
        graph.addNode(e);
        graph.addNode(f);
        graph.addNode(g);
        EXAMPLE1 = graph;
        return graph;
    }

    /**
     * Metoda vrati EXAMPLE2
     * @return ukazkovy priklad EXAMPLE2
     */
    public static Graph getExample2() {
        if (EXAMPLE2 != null) {
            return EXAMPLE2;
        }
        Graph graph = new Graph();
        Node a = new Node("a", 80, 100);
        Node b = new Node("b", 250, 420);
        Node c = new Node("c", 350, 140);
        Node d = new Node("d", 480, 250);
        Node e = new Node("e", 80, 270);

        a.addEdge(c, 5);
        a.addEdge(b, 3);

        b.addEdge(c, 1);
        b.addEdge(d, 2);
        b.addEdge(e, 4);

        d.addEdge(e, 1);
        d.addEdge(c, 9);

        e.addEdge(a, 2);
        e.addEdge(c, 8);

        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);
        graph.addNode(d);
        graph.addNode(e);
        EXAMPLE2 = graph;
        return graph;
    }

    /**
     * Metoda vrati EXAMPLE3
     * @return ukazkovy priklad EXAMPLE3
     */
    public static Graph getExample3() {
        if (EXAMPLE3 != null) {
            return EXAMPLE3;
        }
        Graph graph = new Graph();
        Node a = new Node("a", 270, 110);
        Node b = new Node("b", 360, 390);
        Node c = new Node("c", 250, 380);
        Node d = new Node("d", 540, 210);
        Node e = new Node("e", 67, 310);
        Node f = new Node("f", 50, 130);
        Node g = new Node("g", 150, 180);

        a.addEdge(b, 2);

        b.addEdge(c, 6);
        b.addEdge(d, 7);

        c.addEdge(f, 3);

        d.addEdge(e, 8);

        e.addEdge(f, 5);

        f.addEdge(d, 1);
        f.addEdge(g, 11);

        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);
        graph.addNode(d);
        graph.addNode(e);
        graph.addNode(f);
        graph.addNode(g);

        EXAMPLE3 = graph;
        return graph;
    }
}
