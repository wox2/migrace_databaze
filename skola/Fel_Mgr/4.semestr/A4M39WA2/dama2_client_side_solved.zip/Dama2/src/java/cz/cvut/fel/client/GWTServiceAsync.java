/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.cvut.fel.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 *
 * @author xklima
 */
public interface GWTServiceAsync {
    public void myMethod(String s, AsyncCallback<String> callback);
}
