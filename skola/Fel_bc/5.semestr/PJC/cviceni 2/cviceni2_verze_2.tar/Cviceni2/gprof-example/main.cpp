/*
 * 8. Hasičský dispečink
 * 
 * Je dána mapa města rozděleného do několika okrsků. V každém okrsku je jedna hasičská zbrojnice.
 * Celé město má jeden centrální dispečink. V ulicích města mohou být jednosměrky a v některých ulicích mohou být uzavírky.
 * Vaším úkolem je vytvořit program, který bude simulovat funkci dispečinku: při nahlášení lokality požáru musí program určit,
 * ve kterém okrsku k němu došlo, a nalézt všechny možné cesty z příslušné stanice k místu požáru. Pozor na uzavírky!
 * Formát vstupu a výstupu si zvolte sami. Jméno souboru program načte z příkazové řádky.
 */

/*
 * Reseni semestralni prace z predmetu X36PJC, zadani 8 - Hasicsky dispecink
 * Zpracoval Jindrich Basek - basekjin@fel.cvut.cz
 */

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

/**
 * Trida uzel reprezentuje uzel grafu, kazdy uzel je reprezentovan celym cislem vetsim nez nula
 */
class Uzel {
protected:
    Uzel *dalsi, *hlavni;                                                       /*ukazatel na dalsi uzel v seznamu sousedu uzlu, ukazatel na uzel v sezamu uzlu*/
    int cislo;                                                                  /*cislo uzlu*/
    bool uzavren;                                                               /*uzel uzavren - pouziva se pri hledani cesty, kdy cesta timto uzlem jiz vede*/
public:
    /**
     * Konstruktor tridy Uzel
     * Nastavy odkaz na sousedy na NULL a oznaci uzel jako otevreny
     *
     * @param int _cislo cislo uzlu
     */
    Uzel (int _cislo = 0): cislo(_cislo) {
        dalsi = NULL;
        hlavni = NULL;
        uzavren = false;
    }
    /**
     * Destruktor tridy Uzel
     * Smaze seznam sousedu
     */
    ~Uzel () {
        delete dalsi;
    }

    /**
     * Metoda navraci cislo uzlu
     *
     * @return int cislo uzlu
     */
    int getCislo() const {
        return cislo;
    }
    /**
     * Metoda nastavuje odkaz na souseda uzlu
     *
     * @param Uzel* dalsi odkaz na souseda uzlu
     */
    void setDalsi(Uzel* dalsi) {
        this->dalsi = dalsi;
    }
    /**
     * Metoda navraci odkaz na souseda uzlu
     *
     * @return Uzel* odkaz na souseda uzlu
     */
    Uzel* getDalsi() const {
        return dalsi;
    }
    /**
     * Metoda nastavuje, zda je uzel uzavren pro prohledavani
     *
     * @param bool uzavren uzel uzavren
     */
    void setUzavren(bool uzavren) {
        this->uzavren = uzavren;
    }
    /**
     * Metoda zjistuje, zda je uzel uzavren pro prohledavani
     *
     * @return bool uzel uzavren
     */
    bool isUzavren() const {
        return uzavren;
    }
    /**
     * Metoda nastavuje odkaz na uzel v seznamu uzlu
     *
     * @param Uzel* dalsi odkaz na uzel
     */
    void setHlavni(Uzel* hlavni) {
        this->hlavni = hlavni;
    }
    /**
     * Metoda navraci odkaz na uzel v seznamu uzlu
     *
     * @return Uzel* odkaz na uzel
     */
    Uzel* getHlavni() const {
        return hlavni;
    }
};

/**
 * Trida mapa reprezentuje jeden okrsek mesta, neorientovany graf, ktery ma pocetUzlu uzlu.
 * Graf je reprezentovan spojovym seznamem sousedu uzlu.
 * Trida umoznuje pridavat hrany do grafu, vypsat seznamy nasledovniku vsech uzlu a nalezeni vsech cest mezi dvema uzly
 */
class Mapa {
protected:
    Uzel *uzly;                                                                 /*seznam vsech uzlu*/
    Uzel *cesta;                                                                /*cesta z jednoho uzlu do druheho*/
    int pozar;                                                                  /*uzel, kde vypukl pozar*/
    int uzelStanice;                                                            /*uzel, ve kterem se nachazi hasicska stanice*/
    int pocetUzlu;                                                              /*pocet uzlu grafu*/
    int pocetHran;                                                              /*pocet hran grafu*/
    int pocetCest;                                                              /*pocet cest nalezenych mezi dvema uzly*/

    /**
     * Metoda prida uzlu cislo uzel souseda cislo soused, pokud tyto uzly v grafu jeste nejsou obsazeny, vytvori je
     *
     * @param int uzel cislo uzlu, ke kteremu se bude pridavat soused
     * @param int soused cislo uzlu souseda
     */
    void pridejSouseda (int uzel, int soused, bool uzavirka = false){
        Uzel * aktualni, * pUzel, * pSoused, * temp;

        if (uzel < 0 || soused < 0)
            throw ExCisloSpatne();                                              /*cislo uzlu musi byt vetsi nez nula*/

        if (uzel == soused)                                                     /*v grafu nesmi byt smycky*/
            throw ExSmycka();

        if (uzly == NULL){                                                      /*v grafu jeste neni zadny uzel, vytvoreni uzlu*/
            uzly = new Uzel(uzel);
            pUzel = uzly;
            pocetUzlu++;
        }
        else{
            aktualni = uzly;
            while (aktualni != NULL){                                           /*prochazeni seznamu uzlu*/
                if (aktualni->getCislo() == uzel){                              /*zjistovani, zda uzel, ze ktereho ma vest hrana jiz v grafu je*/
                    pUzel = aktualni;
                    break;
                }
                else {
                    if (aktualni->getHlavni() == NULL){                         /*pokud uzel v grafu neni, je do grafu pridan*/
                        temp = new Uzel(uzel);
                        aktualni->setHlavni(temp);
                        pUzel = aktualni->getHlavni();
                        pocetUzlu++;
                        break;
                    }
                    else{
                        aktualni = aktualni->getHlavni();                       /*dalsi uzel*/
                    }
                }
            }
        }

        aktualni = uzly;
        while (aktualni != NULL){                                               /*prochazeni seznamu uzlu*/
            if (aktualni->getCislo() == soused){                                /*zjistovani, zda uzel, do ktereho ma vest hrana jiz v grafu je*/
                pSoused = aktualni;
                break;
            }
            else {
                if (aktualni->getHlavni() == NULL){                             /*pokud uzel v grafu neni, je do grafu pridan*/
                    temp = new Uzel(soused);
                    aktualni->setHlavni(temp);
                    pSoused = aktualni->getHlavni();
                    pocetUzlu++;
                    break;
                }
                else{
                    aktualni = aktualni->getHlavni();                           /*dalsi uzel*/
                }
            }
        }

        if (!uzavirka){
            aktualni = pUzel;
            while (aktualni != NULL){                                           /*prochazeni seznamu sousedu*/
                if (aktualni->getCislo() == soused){                            /*zjistovani, zda uzel, ktery ma byt pridan do seznamu nasledniku tam jiz neni*/
                    throw ExDuplicita();
                    break;
                }
                else {
                    if (aktualni->getDalsi() == NULL){
                        pocetHran++;
                        if (uplnyGraf()){                                       /*pokud jiz neni graf uplny, a hrana jeste v grafu neexistuje, je hrana pridana do grafu*/
                            throw ExUplnyGraf();
                        }
                        temp = new Uzel(soused);                                /*pridani uzlu do seznamu nasledovniku*/
                        temp->setHlavni(pSoused);
                        aktualni->setDalsi(temp);
                        break;
                    }
                    else{
                        aktualni = aktualni->getDalsi();                        /*dalsi soused*/
                    }
                }
            }
        }
    }

    /**
     * Algoritmus, ktery hleda vsechny cesty z jednoho uzlu do druheho
     *
     * @param Uzel * uzel uzel, ke ktereho se zacne prochazet
     * @param Uzel * posledni posledni uzel, ktery se prochazel
     */
    void hledej(Uzel * uzel, Uzel * posledni) {
        Uzel * aktualni = uzel->getDalsi(), *projdi, *temp;

        if (uzel->getCislo() == pozar){                                         /*uzel, do ktereho se dorazilo je pozadovany cilovy uzel*/
            vypisCestu(cesta);                                                  /*vypsani nalezene cesty a zaznamenani nalezeni cesty*/
            pocetCest++;
        }
        else{
            uzel->setUzavren(true);                                             /*cesta dospela do uzlu, uzel nemuze byt na ceste vicekrat*/

            while (aktualni != NULL){                                           /*rekurzivni prochazeni vsech uzlu sousedicich s aktualnim uzlem*/
                projdi = aktualni;
                aktualni = aktualni->getDalsi();
                if (!projdi->getHlavni()->isUzavren()){                         /*uzel neni na prochazene ceste. bude se prochazet*/
                    temp = new Uzel(projdi->getCislo());                        /*zaznamenani uzlu do cesty*/
                    posledni->setDalsi(temp);
                    hledej(projdi->getHlavni(), posledni->getDalsi());          /*prohledavani od uzlu, ktery je v seznamu sousedu*/
                    delete posledni->getDalsi();
                    posledni->setDalsi(NULL);                                   /*vymazani uzlu z hledane cesty, uzly uz byly prozkoumany*/
                }
            }

            uzel->setUzavren(false);                                            /*vsichni sousedi uzlu jiz byly prozkoumani, uzel jiz neni uzavren, navraceni prohledavani k predchozimu uzlu*/
        }
    }

    /**
     * Metoda zjistuje, zda uzel s cislem uzel v seznamu uzlu
     *
     * @param int uzel cislo uzlu, ktery se hleda v seznamu uzlu
     * @return bool je mezi uzly
     */
    bool meziUzly(int uzel){
        Uzel *aktualni = uzly;
        while (aktualni != NULL){                                               /*prochazeni seznamu uzlu*/
            if (aktualni->getCislo() == uzel){                                  /*zjistovani, zda se uzel s cislem uzel nachazi v seznamu uzlu*/
                return true;                                                    /*je mezi uzly*/
            }
            else {
                if (aktualni->getHlavni() == NULL){
                    return false;                                               /*neni mezi uzly*/
                }
                else{
                    aktualni = aktualni->getHlavni();                           /*dalsi uzel*/
                }
            }
        }
        return false;
    }

    /**
     * Metoda zjistuje, zda je graf uplnym grafem
     *
     * @return bool graf je uplny
     */
    bool uplnyGraf(){
        return (pocetHran > 2*((pocetUzlu * (pocetUzlu - 1))/2));
    }

    /**
     * Trida reprezentujici chybovy stav
     */
    class ExUplnyGraf:public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        virtual const char* what() const throw(){
            return "Prilis mnoho cest, graf je uplny.";
        }
    };
    /**
     * Trida reprezentujici chybovy stav
     */
    class ExDuplicita:public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        virtual const char* what() const throw(){
            return "Vkladana cesta jiz v grafu existuje.";
        }
    };
    /**
     * Trida reprezentujici chybovy stav
     */
    class ExUzelMimo:public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        virtual const char* what() const throw(){
            return "Vstup v nespravnem formatu. Uzel v grafu neexistuje.";
        }
    };
    /**
     * Trida reprezentujici chybovy stav
     */
    class ExCisloSpatne:public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        virtual const char* what() const throw(){
            return "Vstup v nespravnem formatu. Cislo uzlu musi byt vetsi nez nula.";
        }
    };
     /**
     * Trida reprezentujici chybovy stav
     */
    class ExSmycka:public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        virtual const char* what() const throw(){
            return "Vstup v nespravnem formatu. V grafu nemohou byt smycky.";
        }
    };

public:
    /**
     * Konstruktor tridy Mapa - inicializace promennych
     */
    Mapa (){
        uzly = NULL;
        pocetCest = 0;
        pocetHran = 0;
        pocetUzlu = 0;
        pozar = 0;
        uzelStanice = 0;
        cesta = NULL;
    }
    /**
     * Destruktor tridy Mapa smaze vsechny uzly a jejich seznamy sousedu a nalezene cesty
     */
    ~Mapa (){
        Uzel * aktualni = uzly, * dalsi;

        while (aktualni != NULL){                                               /*prochazeni seznamu uzlu grafu*/
            dalsi = aktualni->getHlavni();
            delete aktualni;                                                    /*vymazani uzlu a seznamu sousedu uzlu*/
            aktualni = dalsi;                                                   /*dalsi uzel*/
        }
        delete cesta;
    }
    /**
     * Metoda vytvori cestu mezi uzly cislo uzel1 a cislo uzel2
     *
     * @param int uzel1 cislo prvniho uzlu incidujiciho s hranou
     * @param int uzel2 cislo druheho uzlu incidujiciho s hranou
     */
    void vlozCestu (int uzel1, int uzel2, bool uzavirka, bool jednosmerka){
        pridejSouseda (uzel1 - 1, uzel2 - 1, uzavirka);
        if (!jednosmerka && !uzavirka)
            pridejSouseda (uzel2 - 1, uzel1 - 1);
    }
    /**
     * Metoda vypise sousedy vsech uzlu
     */
    void vypis() const{
        Uzel * aktualni = uzly;

        while (aktualni != NULL){                                               /*prochazeni seznamu sousedu*/
            cout << "Naslednici uzlu " << aktualni->getCislo() + 1 << ": ";
            if (aktualni->getDalsi() == NULL)
                cout << endl;
            else
                vypisCestu(aktualni->getDalsi());
            aktualni = aktualni->getHlavni();                                   /*dalsi soused*/
        }
    }
    /**
     * Metoda vypise vsechny sousedy uzlu uzel
     *
     * @param Uzel * uzel uzel, jehoz sousedi se maji vypsat
     */
    void vypisCestu(Uzel * uzel) const{
        Uzel * aktualni = uzel;
        while (aktualni != NULL){                                               /*prochazeni vsech sousedu uzlu*/
            cout << aktualni->getCislo() + 1;                                   /*vypsani cisla uzlu*/
            if (aktualni->getDalsi() != NULL) cout << " ";
            else cout << endl;
            aktualni = aktualni->getDalsi();
        }
    }
    /**
     * Metoda nalezne a vypise vsechny cesty mezi dvema uzly - mezi uzlem stanice a uzlem pozaru
     *
     * @param bool vypisMapu spolu s nalezenymi cestami vypise i seznamy nasledniku vsech uzlu
     */
    void nalezniCesty(bool vypisMapu = false){
        Uzel *aktualni = uzly;
        static int pocetOkrsku = 0;

        if (uzelStanice == pozar){                                              /*hori pozarni stanice, cesty se nevyhledavaji*/
            cout << "Okrsek " << ++pocetOkrsku << endl;
            if (vypisMapu){
                cout << "Mapa okrsku (stanice v uzlu " << uzelStanice + 1 << ", pozar vypukl v uzlu " << pozar + 1 << "):" << endl;
                vypis();                                                        /*vypsani seznamu nasledniku*/
            }
            cout << "Hori pozarni stanice, nikam se nejede." << endl;
        }
        else{
            while (aktualni != NULL){                                           /*hledani uzlu stanice*/
                if (aktualni->getCislo() == uzelStanice){                       /*uzel stanice nalezen*/
                    break;
                }
                else {
                    if (aktualni->getHlavni() == NULL){                         /*uzel stanice nebyl v grafu nalezen, chyba*/
                        throw ExUzelMimo();
                    }
                    else{
                        aktualni = aktualni->getHlavni();                       /*dalsi uzel*/
                    }
                }
            }

            cesta = new Uzel(uzelStanice);
            cout << "Okrsek " << ++pocetOkrsku << endl;
            if (vypisMapu){
                cout << "Mapa okrsku (stanice v uzlu " << uzelStanice + 1 << ", pozar vypukl v uzlu " << pozar + 1 << "):" << endl;
                vypis();                                                        /*vypsani seznamu nasledniku*/
            }
            cout << "Nalezene cesty:" << endl;
            hledej(aktualni, cesta);                                            /*nalezeni vsech cest mezi uzlem stanice a uzlem pozaru*/
            cout << "Existuje " << pocetCest << " cest z hasicske stanice (uzel " << uzelStanice + 1 << ") do mista pozaru (uzel " << pozar + 1 << ")." << endl;
        }
        
    }

    /**
     * Metoda nastavuje uzel stanice
     *
     * @param int uzelStanice uzel hasicske stanice
     */
    void setUzelStanice(int uzelStanice) {
        if (uzelStanice < 0)
            throw ExCisloSpatne();                                              /*cislo uzlu musi byt vetsi nez nula*/
        if (meziUzly(uzelStanice - 1)){                                         /*uzel stanice v grafu existuje*/
                this->uzelStanice = uzelStanice - 1;                            /*zaznamenani cisla stanice*/
        }
        else
            throw ExUzelMimo();
    }
    /**
     * Metoda nastavuje uzel kde vznikl pozar
     *
     * @param int pozar uzel pozaru
     */
    void setPozar(int pozar) {
        if (pozar < 0)
            throw ExCisloSpatne();                                              /*cislo uzlu musi byt vetsi nez nula*/
        if (meziUzly(pozar - 1)){                                               /*uzel pozaru v grafu existuje*/
                this->pozar = pozar - 1;                                        /*zaznamenani cisla pozaru*/
        }
        else
            throw ExUzelMimo();
    }
};

/**
 * Trida reprezentujici napovedu
 */
class Manual{
public:
    /**
     * Metoda vypisuje napovedu k programu
     */
    static void napoveda(){
        cout << "Program firetruck slouzi pro vyhledavani vsech cest mezi dvema uzly grafu." << endl << endl <<
                "Uziti: firetruck [-help] [cesta…] [-m]" << endl << endl <<
                "Je dana mapa mesta rozdeleneho do nekolika okrsku. V kazdem okrsku je jedna hasicska zbrojnice. Cele mesto ma jeden centralni dispecink. V ulicich mesta mohou byt jednosmerky a v nekterych ulicich mohou byt uzavirky. Program simuluje funkci dispecinku: pri nahlaseni lokality pozaru program nalezne vsechny mozne cesty z prislusne stanice k mistu pozaru." << endl << endl <<
                "Prepinace:" << endl <<
                "-m vypise spolu s nalezenymi cestami i seznam nasledniku uzlu okrsku" << endl <<
                "-help vypise tuto napovedu" << endl <<
                "ostatni parametry programu jsou textove soubory s parametry okrsku" << endl <<
                "pokud nejsou mezi parametry zadne soubory s parametry okrsku, jsou parametry nacitany ze standartniho vstupu" << endl << endl <<
                "Format vstupu" << endl <<
                "Zadavani mapy okrsku zacina zadanim hrany mezi dvema uzly grafu. Na radku je zadano cislo uzlu, oddelovaci znak a druhe cislo uzlu. Radek je zakoncen znakem noveho radku. Pokud je mezi cisly uzlu mezera, je mezi uzly vytvorena obousmerna cesta. Pokud je mezi cisly uzlu znak minus -, je vytvorena jednosmerna cesta z prvniho uzlu do druheho. Pokud je mezi cisly uzlu znak x, je cesta meze uzly uzavrena. Pokud uzly s pozadovanymi cisly v grafu neexistuji, jsou automaticky vytvoreny. Zadavani mapy okrsku konci, pokud je mezi cisly uzlu znak plus +, potom je prvni uzel uzlem hasicske stanice a druhy uzel uzlem, kde vypukl pozar." << endl;
    }
};

/**
 * Trida slouzi pro zpracovani vstupnich dat pro program
 */
class Zpracovani{
protected:
    /**
     * Trida reprezentujici chybovy stav
     */
    class ExVstup: public exception {
    public:
        /**
         * Metoda vraci chybovou zpravu
         */
        const char* what() const throw(){
            return "Vstup v nespravnem formatu. Neocekavany znak.";
        }
    };
public:
    /**
     * Metoda zpracovava vstup programu, vytvari mapy okrsku s pozary a stanicemi a vypisuje vsechny cesty mezi pozarem a stanici
     */
    static void zpracuj(istream& input, bool vypisMapu = false){
        Mapa * mapa = NULL;
        char c;
        int n1, n2;
        bool jednosmerka = false;
        bool konec = false;
        bool uzavirka = false;

        try {
            mapa = new Mapa();                                                  /*vytvoreni mapy okrsku*/
            while (input.good()){
                c = input.get();
                if (input.eof())
                    break;
                if (input.good()){
                    if ((c >= '0') && (c <= '9')){                              /*cislo prvniho uzlu incidujiciho s hranou bylo zadano spravne*/
                        input.unget();
                        input >> n1;
                    }
                    else{
                        throw ExVstup();
                    }
                }
                c = input.get();
                if (input.eof())
                    break;
                if (input.good()){
                    if (c == ' '){                                              /*silnice mezi uzly bude obousmerna*/
                        jednosmerka = false;
                        uzavirka = false;
                    }
                    else if (c == '-'){                                         /*silnice mezi uzlu bude jednosmerna*/
                        jednosmerka = true;
                        uzavirka = false;
                    }
                    else if (c == 'x'){                                         /*silnice mezi uzly bude uzavrena*/
                        jednosmerka = false;
                        uzavirka = true;
                    }
                    else if (c == '+'){                                         /*timto radkem se ukoncuje zadavani okrsku, cislo pred + je uzel stanice a cislo za + je uzel pozaru*/
                        konec = true;
                    }
                    else {                                                      /*spatny znak*/
                        throw ExVstup();
                    }
                }
                c = input.get();
                if (input.eof())
                    break;
                if (input.good()){
                    if ((c >= '0') && (c <= '9')){                              /*cislo druheho uzlu incidujiciho s hranou bylo zadano spravne*/
                        input.unget();
                        input >> n2;
                    }
                    else{
                        throw ExVstup();
                    }
                }
                c = input.get();
                if (input.eof() && konec){
                    mapa->setUzelStanice(n1);                                   /*nastaveni uzlu stanice*/
                    mapa->setPozar(n2);                                         /*nastaveni uzlu pozaru*/
                    mapa->nalezniCesty(vypisMapu);                              /*nalezeni cest*/
                    konec = false;
                    delete mapa;
                    mapa = new Mapa();                                          /*vytvoreni mapy okrsku*/
                }
                if (input.eof() && !konec){
                    break;
                }
                if (input.good()){
                    if (c != '\n' && c != '\r'){                                /*za cislem druheho uzlu musi byt znak noveho radku*/
                        throw ExVstup();
                    }
                    if (c == '\r'){
                        c = input.get();
                        if (input.good() && c != '\n')
                            input.unget();
                    }
                }

                if (konec){                                                     /*ukonceno zadavani okrsku*/
                    mapa->setUzelStanice(n1);                                   /*nastaveni uzlu stanice*/
                    mapa->setPozar(n2);                                         /*nastaveni uzlu pozaru*/
                    mapa->nalezniCesty(vypisMapu);                              /*nalezeni cest*/
                    konec = false;
                    delete mapa;
                    mapa = new Mapa();                                          /*vytvoreni mapy okrsku*/
                }
                else
                    mapa->vlozCestu(n1, n2, uzavirka, jednosmerka);             /*vlozeni cesty*/
            }
            delete mapa;

        }
        catch (...) {                                                           /*v pripade chyby smazani mapy*/
            delete mapa;
            mapa = NULL;
            throw;
        }
    }
};

int main(int argc, char** argv) {
    ifstream input;
    bool vypisMapu = false;
    int pocetSouboru = 0;

    try{
        for (int i = 1; i < argc; i++){                                         /*prozkoumani parametru programu*/
            if (!strcmp (argv[i],"-m")){                                        /*bude se vypisovat i mapa okrsku*/
                vypisMapu = true;
            }
            else if (!strcmp (argv[i],"-help") || !strcmp (argv[i],"--help")){  /*vypsani napovedy*/
                Manual::napoveda();
                return (EXIT_SUCCESS);
            }
            else{                                                               /*parametrem je nazev souboru*/
                pocetSouboru++;
            }
        }

        if (!pocetSouboru){                                                     /*program spusten bez zadanych vstupnich souboru, definice se budou nacitat ze standartniho vstupu*/
            Zpracovani::zpracuj(cin, vypisMapu);
            return (EXIT_SUCCESS);
        }
        else{                                                                   /*program spusten s parametry, definice se budou nacitat ze souboru, jejichz jmena jsou uvedena jako parametry programu*/
            for (int i = 1; i < argc; i++){
                if (strcmp (argv[i],"-m")){
                    input.open(argv[i], ios::in);
                    if (!input){                                                /*chyba pri otevreni souboru*/
                        cerr << "Nepodarilo se otevrit soubor: " << argv[i] << endl;
                        return (EXIT_FAILURE);
                    }
                    else{                                                       /*zpracovani souboru*/
                        Zpracovani::zpracuj(input, vypisMapu);
                        input.close();
                    }
                }
            }
        }
        return (EXIT_SUCCESS);
    }
    catch (exception& ex){                                                      /*zachyceni chybovych stavu a vypsani chybovych zprav*/
        cerr << ex.what() << endl;
        return (EXIT_FAILURE);
    }
}
