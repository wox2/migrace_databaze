/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import Exceptions.HasNoNextException;

/**
 * Interface pro iterator hran.
 * @author woxie
 */
public interface MyIterator {

    /**
     * Metoda urcuje, jestli je dalsi hrana
     * @return vraci hodnotu typu boolean vyjadrujici, jestli je dalsi hrana
     */
    boolean hasNext();

    /**
     * Metoda vraci dalsi hranu nebo vyhazuje vyjimku.
     * @return vraci dalsi Node, pripadne vyhazuje vyjimku.
     * @throws HasNoNextException vyhozena vyjimka, pokud neexistuje dalsi hrana.
     */
    Object next() throws HasNoNextException;

    /**
     * Nastavi aktualni Node
     * @param node Node, ktery ma byt  nastaveny jako aktualni
     */
    void setActualNode(Node node);
}
