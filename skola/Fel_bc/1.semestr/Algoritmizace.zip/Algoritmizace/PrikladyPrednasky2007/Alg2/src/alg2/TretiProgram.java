package alg2;

import java.util.*;

public class TretiProgram {
  public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
      int x, y, z;
   System.out.println("zadejte dv� cel� ��sla");
    x = sc.nextInt();
    y = sc.nextInt();z=sc.nextInt();
 
   
   System.out.println("sou�et ��sel " + x + " "+ y + " je " +z);

  }
 
}
