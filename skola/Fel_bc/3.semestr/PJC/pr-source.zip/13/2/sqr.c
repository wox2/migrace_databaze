/* sqr.c � implementace modulu, ale v C, ne v C++ */
#include "sqr.h"

double sqr ( double x )
 {
   return ( x * x );
 }
