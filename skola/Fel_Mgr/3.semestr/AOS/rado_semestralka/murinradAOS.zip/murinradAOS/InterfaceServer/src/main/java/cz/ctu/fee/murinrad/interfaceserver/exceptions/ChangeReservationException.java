/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.interfaceserver.exceptions;

/**
 *
 * @author Radovan Murin
 */
public class ChangeReservationException extends Exception {

    public ChangeReservationException(String message, Throwable cause) {
        super(message, cause);
    }
    
    
    
}
