/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import cz.cvut.fel.client.DamaService;
import cz.cvut.fel.shared.ChessCell;
import cz.cvut.fel.shared.Jewel;
import java.util.ArrayList;

/**
 *
 * @author xklima
 */
public class DamaServiceImpl extends RemoteServiceServlet implements DamaService {

    @Override
    public ChessCell[][] startDama() throws IllegalArgumentException {
        Dama dama = new Dama();
        ChessCell[][] chessboard = dama.getAllCells();
        // zapamatuj si v session posledni stav damy
        saveDama(dama);
        return chessboard;
    }

    @Override
    public ChessCell[] cellClicked(ChessCell chessCell) {
        ArrayList<ChessCell> toChange = new ArrayList<ChessCell>();
        if (chessCell.getJewel() != null) {
            chessCell.getJewel().setType(Jewel.ADVANCED);
            toChange.add(chessCell);
        }
        ChessCell[] toReturn = new ChessCell[toChange.size()];
        toChange.toArray(toReturn);

        return toReturn;
    }

    @Override
    public ChessCell[] move(ChessCell from, ChessCell to) {
        ArrayList<ChessCell> toChange = new ArrayList<ChessCell>();
        Dama dama = loadDama();
        // logika pro hybani s kameny
        // nejprve se ujistim, ze policko to je prazdne a ze policko from je plne
        if (to.getJewel() != null || from.getJewel() == null) {
            return new ChessCell[0];
        }
        // pravidla pro hybani s obyc kameny
        if (from.getJewel().getType() == Jewel.NORMAL) {
            moveNormalJewel(from, to, dama, toChange);
        } else {
            // pravidla pro damu
            moveDama(from,to, dama, toChange);
        }

        ChessCell[] toReturn = new ChessCell[toChange.size()];
        toChange.toArray(toReturn);
        dama.setCells(toReturn);
        saveDama(dama);
        return toReturn;
    }

    public void saveDama(Dama dama) {
        getThreadLocalRequest().getSession().setAttribute("dama", dama);
    }

    public Dama loadDama() {
        return (Dama) getThreadLocalRequest().getSession().getAttribute("dama");
    }

    private void moveNormalJewel(ChessCell from, ChessCell to, Dama dama, ArrayList<ChessCell> toChange) {
        // nejprve se ujistim, ze bily se hybe nahoru a cerny dolu a po diagonale
        int koef = from.getJewel().getColor() == Jewel.BLACK ? 1 : -1;


        if (to.getX() == from.getX() + koef) { // posun o jedno policko (nepreskakuji nikoho)
            moveOneCell(from, to, toChange);
        } else {
            // posun o 2 policka (zatim neuvazuji moznost, ze by se skakalo pres vice souperu

            if ((to.getX() == from.getX() + koef + koef) && (Math.abs(to.getY() - from.getY()) == 2)) {
                moveTwoCells(from, to, toChange, dama);

            } else {
                // posun o vice nez 2 policka - nelze u obyc kamane
                
            }
        }
    }

    private void moveOneCell(ChessCell from, ChessCell to, ArrayList<ChessCell> toChange) {
        if (Math.abs(to.getY() - from.getY()) == 1) { // v ose y se to muze hybat do strany libovolne
            to.setJewel(from.getJewel());
            to.getJewel().setMoved(true);
            checkDama(to);
            from.setJewel(null);
            toChange.add(to);
            toChange.add(from);
        }
    }

    private void moveTwoCells(ChessCell from, ChessCell to,
            ArrayList<ChessCell> toChange, Dama dama) {
        ChessCell between = dama.getCell(from.getX() + ((to.getX() - from.getX()) / 2),
                from.getY() + (to.getY() - from.getY()) / 2);

        if (between.getJewel() == null
                && (from.getX() == 1 || from.getX() == 6)
                && !from.getJewel().isMoved()) {
            // pohyb o dve policka pres prazdne policko
            // to se smi jenom u kamenu, ktere jsou v prvni rade a dosud s nimi
            //nebylo pohnuto

            to.setJewel(from.getJewel());
            to.getJewel().setMoved(true);
            from.setJewel(null);
            toChange.add(from);
            toChange.add(to);
            return;
        } else {
            if (between.getJewel() == null || between.getJewel().getColor() == from.getJewel().getColor()) {
                // neni mozne udelat tento pohyb, protoze skacu pres prazdne policko
                // nebo pres kamen se stejnou barvou
                return;
            }
        }

        // ok, povoleno
        to.setJewel(from.getJewel());
        to.getJewel().setMoved(true);
        checkDama(to);
        from.setJewel(
                null);
        between.setJewel(
                null);
        toChange.add(to);
        toChange.add(from);
        toChange.add(between);
    }

    private void checkDama(ChessCell c) {
        if (c.getX()==0 || c.getX() == 7 && c.getJewel() != null ) {
            c.getJewel().setType(Jewel.ADVANCED);
        }
    }

    private void moveDama(ChessCell from, ChessCell to, Dama dama, ArrayList<ChessCell> toChange) {
        // jednoduchy test - cilove policko nesmi byt obsazeno
        if (to.getJewel() != null) return;
        // kontrola, ze se pohybuji po diagonale
        if (Math.abs(to.getX()-from.getX()) != Math.abs(to.getY()-from.getY())) {
            // nepohybuji se po diagonale, neresim
            return;
        }
        // ktere kameny jsou mezi nami?
        ChessCell between = null;
        int stepX = (int)Math.signum(to.getX()-from.getX());
        int stepY = (int)Math.signum(to.getY() - from.getY());
        // ted to odkrokuju
        int x = from.getX()+stepX;
        int y = from.getY()+stepY;
        while (x != to.getX()) {
            ChessCell currentCell = dama.getCell(x, y);
            if (currentCell.getJewel() == null) {
                // prazdne policko, to nicemu nevadi
            } else {
                if  (currentCell.getJewel().getColor() ==
                    from.getJewel().getColor()) {
                    // nemuzu skakat pres svoje vlastni kameny
                    return;
                } else {
                    // skvele, skacu pres cizi kamen - pozor, muzu skocit jen pres jeden
                    if (between != null) {
                        // smula, uz jsem v minulosti pres jeden skocil, takze nic
                        return;
                    } else {
                        // skvele, skacu pres prvni z nich, takze si ho zapamatuju
                        between = currentCell;
                    }
                }
            }
            x += stepX;
            y += stepY;
        }
        // aplikuji pohyb
        if (between != null) {
            between.setJewel(null);
            toChange.add(between);
        }
        to.setJewel(from.getJewel());
        from.setJewel(null);
        toChange.add(from);
        toChange.add(to);
    }

    public ChessCell[][] getDama() {
        Dama dama = loadDama();
        if (null == dama) {
            return startDama();
        } else {
            return dama.getAllCells();
        }
    }

}



