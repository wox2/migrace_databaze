/* S��t�n� dvou ��sel - prvn� pokus
   soubor kap03\03\Soucet.java
*/
public class Soucet {
  public static void main(String[] arg){
   int i = 12, j = 25, k;	// Prvn� a druh� s��tanec, v�sledek
   k = i+j;			// Vypo�ti v�sledek
   System.out.println(	"Soucet cisel " + i + 
			" + " + j + " je " + k);
  }
}
