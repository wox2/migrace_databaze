SET FOREIGN_KEY_CHECKS=0;


DROP TABLE IF EXISTS Ctenar
;
DROP TABLE IF EXISTS jeRezervovana
;
DROP TABLE IF EXISTS Pokuta
;
DROP TABLE IF EXISTS Rezervace
;
DROP TABLE IF EXISTS Vypujcka
;
DROP TABLE IF EXISTS Vytisk
;
DROP TABLE IF EXISTS Autor
;
DROP TABLE IF EXISTS jeNapsana
;
DROP TABLE IF EXISTS Kniha
;
DROP TABLE IF EXISTS Nakladatelstvi
;
DROP TABLE IF EXISTS Regal
;
DROP TABLE IF EXISTS Zanr
;
DROP TABLE IF EXISTS zarazenaDo
;

CREATE TABLE Ctenar
(
	cisloPrukazky INTEGER,
	email VARCHAR(50),
	jmeno VARCHAR(50),
	prijmeni VARCHAR(50),
	telefon VARCHAR(50),
	ctenarID INTEGER NOT NULL,
	PRIMARY KEY (ctenarID)
) 
;


CREATE TABLE jeRezervovana
(
	knihaID INTEGER,
	rezervaceID INTEGER,
	KEY (knihaID),
	KEY (rezervaceID)
) 
;


CREATE TABLE Pokuta
(
	cena DOUBLE,
	datum DATE,
	duvod VARCHAR(255),
	mena VARCHAR(5),
	pokutaID INTEGER NOT NULL,
	vypujckaID INTEGER,
	PRIMARY KEY (pokutaID),
	KEY (vypujckaID)
) 
;


CREATE TABLE Rezervace
(
	datumZarezervovani DATE,
	platnaDo DATE,
	pocetDniRezervace INTEGER,
	rezervaceID INTEGER NOT NULL,
	ctenarID INTEGER,
	PRIMARY KEY (rezervaceID),
	KEY (ctenarID)
) 
;


CREATE TABLE Vypujcka
(
	datumVraceni DATE,
	datumVypujceni DATE,
	vypujcenaDo DATE,
	vypujckaID INTEGER NOT NULL,
	ctenarID INTEGER,
	vytiskID INTEGER,
	PRIMARY KEY (vypujckaID),
	KEY (ctenarID),
	KEY (vytiskID)
) 
;


CREATE TABLE Vytisk
(
	datumVyrazeni DATE,
	evidencniCislo VARCHAR(50),
	porizovaciCena DOUBLE,
	rokNakupu INTEGER,
	vypujckaID INTEGER,
	vytiskID INTEGER NOT NULL,
	knihaID INTEGER,
	PRIMARY KEY (vytiskID),
	KEY (vypujckaID),
	KEY (knihaID)
) 
;


CREATE TABLE Autor
(
	jmeno VARCHAR(50),
	prijmeni VARCHAR(50),
	autorID INTEGER NOT NULL,
	PRIMARY KEY (autorID)
) 
;


CREATE TABLE jeNapsana
(
	autorID INTEGER,
	knihaID INTEGER,
	KEY (autorID),
	KEY (knihaID)
) 
;


CREATE TABLE Kniha
(
	isbn VARCHAR(50),
	klicovaSlova VARCHAR(50),
	nazev VARCHAR(50),
	obsah VARCHAR(50),
	rokVydani INTEGER,
	knihaID INTEGER NOT NULL,
	regalID INTEGER,
	nakladatelstviID INTEGER,
	PRIMARY KEY (knihaID),
	KEY (regalID),
	KEY (nakladatelstviID)
) 
;


CREATE TABLE Nakladatelstvi
(
	misto VARCHAR(50),
	nazev VARCHAR(50),
	nakladatelstviID INTEGER NOT NULL,
	PRIMARY KEY (nakladatelstviID)
) 
;


CREATE TABLE Regal
(
	oznaceni VARCHAR(50),
	cisloMistnosti VARCHAR(50),
	regalID INTEGER NOT NULL,
	PRIMARY KEY (regalID)
) 
;


CREATE TABLE Zanr
(
	nazev VARCHAR(50),
	popis VARCHAR(50),
	zanrID INTEGER NOT NULL,
	PRIMARY KEY (zanrID)
) 
;


CREATE TABLE zarazenaDo
(
	zanrID INTEGER,
	knihaID INTEGER,
	KEY (zanrID),
	KEY (knihaID)
) 
;



SET FOREIGN_KEY_CHECKS=1;


ALTER TABLE jeRezervovana ADD CONSTRAINT Kniha 
	FOREIGN KEY (knihaID) REFERENCES Kniha (knihaID)
;

ALTER TABLE jeRezervovana ADD CONSTRAINT Rezervace 
	FOREIGN KEY (rezervaceID) REFERENCES Rezervace (rezervaceID)
;

ALTER TABLE Pokuta ADD CONSTRAINT udelenaZa 
	FOREIGN KEY (vypujckaID) REFERENCES Vypujcka (vypujckaID)
;

ALTER TABLE Rezervace ADD CONSTRAINT maRezervovano 
	FOREIGN KEY (ctenarID) REFERENCES Ctenar (ctenarID)
;

ALTER TABLE Vypujcka ADD CONSTRAINT maVypujceno 
	FOREIGN KEY (ctenarID) REFERENCES Ctenar (ctenarID)
;

ALTER TABLE Vypujcka ADD CONSTRAINT jeVypujcen 
	FOREIGN KEY (vytiskID) REFERENCES Vytisk (vytiskID)
;

ALTER TABLE Vytisk ADD CONSTRAINT maExemplare 
	FOREIGN KEY (knihaID) REFERENCES Kniha (knihaID)
;

ALTER TABLE jeNapsana ADD CONSTRAINT Autor 
	FOREIGN KEY (autorID) REFERENCES Autor (autorID)
;

ALTER TABLE jeNapsana ADD CONSTRAINT Kniha 
	FOREIGN KEY (knihaID) REFERENCES Kniha (knihaID)
;

ALTER TABLE Kniha ADD CONSTRAINT jeUmistena 
	FOREIGN KEY (regalID) REFERENCES Regal (regalID)
;

ALTER TABLE Kniha ADD CONSTRAINT jeVydana 
	FOREIGN KEY (nakladatelstviID) REFERENCES Nakladatelstvi (nakladatelstviID)
;

ALTER TABLE zarazenaDo ADD CONSTRAINT Zanr 
	FOREIGN KEY (zanrID) REFERENCES Zanr (zanrID)
;

ALTER TABLE zarazenaDo ADD CONSTRAINT Kniha 
	FOREIGN KEY (knihaID) REFERENCES Kniha (knihaID)
;
