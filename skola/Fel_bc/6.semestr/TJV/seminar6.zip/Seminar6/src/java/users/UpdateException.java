package users;

public class UpdateException extends Exception {

    public UpdateException(String message) {
        super(message);
    }
}
