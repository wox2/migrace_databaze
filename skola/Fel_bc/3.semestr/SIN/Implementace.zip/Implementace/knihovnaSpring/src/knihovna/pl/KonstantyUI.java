package knihovna.pl;

/**
 * T��da obsahuje popisky komponent pro u�ivatelsk� rozhran�.
 * @author Ji�� Mlejnek
 * @version 1.0
 * @created 13-IX-2009 19:59:20
 */
public class KonstantyUI {
	public static final String NAZEV_OKNA="Aplikace knihovna";
	public static final String SEZNAM_VYPUJCENE_VYTISKY="V�puj�en� v�tisky";
	public static final String POPISEK_AKTUALNI_INFORMACE="Aktu�ln� informace";
	public static final String POPISEK_UZIVATEL="U�ivatel:";
	public static final String POPISEK_EVIDENCNI_CISLO="Eviden�n� ��slo:";
	public static final String TLACITKO_ZPRACOVAT_VYTISK="Zpracovat v�tisk";
	public static final String TLACITKO_PRIHLASIT_CTENARE="P�ihl�sit �ten��e";
	public static final String SEZNAM_VOLNE_VYTISKY="Vr�cen� v�tisky";
	public static final String NADPIS="Informa�n� syst�m knihovny";

	

}