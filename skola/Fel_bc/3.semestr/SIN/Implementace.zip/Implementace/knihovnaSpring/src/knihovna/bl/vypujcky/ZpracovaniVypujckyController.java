package knihovna.bl.vypujcky;
import knihovna.dl.entity.Ctenar;

/**
 * T��da implementuj�c� rozhran� pro u�ivatelsk� rozhran� umo��uj�c� p�ed�vat
 * dom�nov� vrstv� po�adavky z prezenta�n� vrstvy. Jedn� se o tzv. use case controller.
 * @author Ji�� Mlejnek
 * @version 1.0
 * @updated 04-IX-2009 19:36:45
 */
public class ZpracovaniVypujckyController implements IZpracovaniVypujckyController{

	private SpravceVytisku spravceVytisku;
	
	
	public SpravceVytisku getSpravceVytisku() {
		return spravceVytisku;
	}

	public void setSpravceVytisku(SpravceVytisku spravceVytisku) {
		this.spravceVytisku = spravceVytisku;
	}

	private SpravceCtenaru spravceCtenaru;
	
	
	public SpravceCtenaru getSpravceCtenaru() {
		return spravceCtenaru;
	}

	public void setSpravceCtenaru(SpravceCtenaru spravceCtenaru) {
		this.spravceCtenaru = spravceCtenaru;
	}

	public Ctenar aktualniCtenar;
	
	private ViewVypujckyController viewVypujckyController;

	public ViewVypujckyController getViewVypujckyController() {
		return viewVypujckyController;
	}
	public void setViewVypujckyController(
			ViewVypujckyController viewVypujckyController) {
		this.viewVypujckyController = viewVypujckyController;
	}

	public ZpracovaniVypujckyController(){

	}

	/**
	 * Realizuje p��pad u�it� "V�puj�it/vr�tit knihu". 
	 * Na z�klad� eviden�n�ho ��sla dohled� v�tisk dan� knihy podle stavu v�tisku zap�e novou v�pij�ku, 
	 * �i k existuj�c� v�ouj�ce zp�e datum vr�cen�.
	 * @param evidencniCislo	��slo v�tisku knihy, odpov�daj�c� ��rov�mu k�du na v�tisku.
	 */
	public void zapisKnihu(String evidencniCislo){
		VytiskDTO vytisk = this.spravceVytisku.vyhledejVytisk(evidencniCislo);
		//TODO: vyplnit aktualne prihlasenyho ctenare
		vytisk.zpracuj(new Ctenar());
		this.spravceVytisku.ulozVytisk(vytisk);
		viewVypujckyController.aktualizuj();
	} 	

	/**
	 * Zaznamen� �ten��e, ke kter�mu maj� b�t n�sledn� v�echny v�puj�ky zaznamen�v�ny.
	 * Typicky prob�h� po na�ten� �ten��sk� pr�kazky.
	 * 
	 * @param cisloPrukazky    ��slo �ten��sk� pr�kazky na kterou maj� b�t n�sledn�
	 * v�echny v�puj�ky zaznamen�v�ny.
	 */
	public void zadejCtenare(String cisloPrukazky){

	}

	/**
	 * Odhl�s� aktu�ln�ho �ten��e. Dal�� v�puj�ky ji� nebudou zapisov�nay na jeho jm�no.
	 */
	public void odhlasCtenare(){

	}
}