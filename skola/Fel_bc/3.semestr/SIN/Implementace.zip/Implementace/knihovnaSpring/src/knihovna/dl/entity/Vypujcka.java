package knihovna.dl.entity;



import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;




/**
 * @author Jirka
 * @version 1.0
 * @created 16-VIII-2009 20:21:28
 */
@Entity
@Table(name="vypujcka")
public class Vypujcka implements Serializable {

	@Id
	private int vypujckaid;
	private Date datumvraceni;
	private Date datumvypujceni;
	private Date vypujcenado;
	private int ctenarid;
	private int vytiskid;
	private static final long serialVersionUID = 1L;

	public Vypujcka(){

	}

	public int getVypujckaid(){
		return vypujckaid;
	}

	/**
	 * 
	 * @param vypujckaid
	 */
	public void setVypujckaid(int vypujckaid){
		this.vypujckaid=vypujckaid;
	}

	public Date getDatumvraceni(){
		return datumvraceni;
	}

	/**
	 * 
	 * @param datumvraceni
	 */
	public void setDatumvraceni(Date datumvraceni){
		this.datumvraceni=datumvraceni;
	}

	public Date getDatumvypujceni(){
		return datumvypujceni;
	}

	/**
	 * 
	 * @param datumvypujceni
	 */
	public void setDatumvypujceni(Date datumvypujceni){
		this.datumvypujceni=datumvypujceni;
	}

	public Date getVypujcenado(){
		return vypujcenado;
	}

	/**
	 * 
	 * @param vypujcenado
	 */
	public void setVypujcenado(Date vypujcenado){
		this.vypujcenado=vypujcenado;
	}

	public int getCtenarid(){
		return ctenarid;
	}

	/**
	 * 
	 * @param ctenarid
	 */
	public void setCtenarid(int ctenarid){
		this.ctenarid=ctenarid;
	}

	public int getVytiskid(){
		return vytiskid;
	}

	/**
	 * 
	 * @param vytiskid
	 */
	public void setVytiskid(int vytiskid){
		this.vytiskid=vytiskid;
	}

}