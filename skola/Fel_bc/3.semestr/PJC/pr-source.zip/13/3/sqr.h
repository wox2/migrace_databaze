/* sqr.h  - poskytuje funkci pro druhou mocninu */
#ifndef __sqr_h__3490304930493__
#define __sqr_h__3490304930493__

#ifdef __cplusplus
extern "C" { 
#endif /* __cplusplus */
 
double sqr ( double x );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  /* __sqr_h__3490304930493__ */
