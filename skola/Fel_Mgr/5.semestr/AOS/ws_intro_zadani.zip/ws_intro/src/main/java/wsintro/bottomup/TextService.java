package wsintro.bottomup;

public class TextService implements TextManipulator {

    @Override
    public String concatenate( String prefix, String suffix ) throws InputException {
        if ( prefix == null || suffix == null )
            throw new InputException( "Input parameters are empty." );
        else
            return prefix + suffix;
    }
}
