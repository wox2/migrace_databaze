%CHARTOSTRUCT convert logical to struct.
%    struct = LOGICALTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml

%   Author(s): P. Sucha
%   Copyright (c) 2006
%   $Revision: 2892 $  $Date: 2009-03-18 10:20:37 +0100 (st, 18 III 2009) $

