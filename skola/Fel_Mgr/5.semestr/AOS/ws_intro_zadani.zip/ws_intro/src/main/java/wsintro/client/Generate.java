package wsintro.client;

import org.apache.cxf.tools.wsdlto.WSDLToJava;

public class Generate {

    public static void main( String[] args ) {

        WSDLToJava.main( new String[]{
                "-client",
                "-d",
                "src/main/java",
                "-p",
                "wsintro.client",
                "http://localhost:8080/TextService?wsdl"
        } );
        System.out.println( "Done!" );
    }
}
