/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package network;

/**
 *
 * @author sprinkler
 */
public class NetworkException extends Exception{

    public NetworkException(String message) {
        super(message);
    }
}
