/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import cz.cvut.fel.shared.ChessCell;

/**
 *
 * @author xklima
 */
@RemoteServiceRelativePath("damaservice")
public interface DamaService extends RemoteService {
    ChessCell[][] startDama() throws IllegalArgumentException;
    ChessCell[] cellClicked(ChessCell chessCell);
    ChessCell[] move(ChessCell from, ChessCell to);
    ChessCell[][] getDama();
}
