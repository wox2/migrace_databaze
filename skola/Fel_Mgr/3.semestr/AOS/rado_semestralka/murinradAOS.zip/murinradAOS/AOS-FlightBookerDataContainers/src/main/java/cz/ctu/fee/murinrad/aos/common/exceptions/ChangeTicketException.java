/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ctu.fee.murinrad.aos.common.exceptions;

/**
 *
 * @author murinr
 */
public class ChangeTicketException extends Exception {

    public ChangeTicketException(String message, Throwable cause) {
        super(message, cause);
    }
     
}
