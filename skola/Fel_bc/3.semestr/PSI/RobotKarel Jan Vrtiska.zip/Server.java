/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robot_server;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jan Vrtiška
 */
public class Server implements Runnable {

    private Point souradnice = new Point();
    private Point smer = new Point();
    private OutputStream out;
    private InputStream in;
    private String osloveni;
    private boolean porucha = false, konec = false;
    private int okKroky = 0;
    private String prijataZprava;
    private PrintWriter out2;
    private BufferedReader in2;
    private int porouchanyBlok;
    private String inBuffer = "";

    public static void main(String[] args) throws IOException, InterruptedException {
      int  port = Integer.decode(args[0]);
      ServerSocket serverSoket = new ServerSocket(port);
        //serverSoket.setReceiveBufferSize(10000);

        while (true) {
           // Thread.sleep(10000);
           Socket soket = serverSoket.accept();
           soket.setSoTimeout(6000000);
           soket.setTcpNoDelay(true);
            Thread vlakno = new Thread(new Server(soket));
            vlakno.start();
        }

    }

    public Server(Socket _soket) throws IOException {
        Socket soket = _soket;
        out = soket.getOutputStream();
        in = soket.getInputStream();
        in2 = new BufferedReader(new InputStreamReader(in));
        out2 = new PrintWriter(out);
        osloveni = vyberOsloveni();
        vytvorRobota();
    }

    public  void vytvorRobota() {
        souradnice.x = (int) ((Math.random() * 16) - (Math.random() * 16));
        souradnice.y = (int) ((Math.random() * 16) - (Math.random() * 16));
        int rsmer = (int) (Math.random() * 3);
        System.out.println("generovaný smer: " + rsmer);
        switch (rsmer) {
            case 0: {
                smer.x = 0;
                smer.y = 1;
                break;
            }
            case 1: {
                smer.x = -1;
                smer.y = 0;
                break;
            }
            case 2: {
                smer.x = 0;
                smer.y = -1;
                break;
            }
            case 3: {
                smer.x = 1;
                smer.y = 0;
                break;
            }
        }
    }

    public  String vyberOsloveni() {
        int nahoda = (int) (Math.random() * 2);
        String tosloveni = "";

        switch (nahoda) {
            case 0: {
                osloveni = "antiteacher";
                break;
            }
            case 1: {
                osloveni = "Plechova krabice";
                break;
            }
            case 2: {
                osloveni = "Kopo srotu";
                break;
            }

        }
        return osloveni;

    }

    private  void posli(int i) {
        switch (i) {
            case 220: {
                out2.write(i + " Ahoj, tady je robot. Oslovuj mne " + osloveni + ".\r\n");
                out2.flush();
                prectiPrikaz();
                break;
            }
            case 221: {
                out2.write(i + " USPECH Kobyla ma maly bok.\r\n");
                out2.flush();
                konec();
                break;
            }
            case 250: {
                out2.write(i + " OK (" + souradnice.x + "," + souradnice.y + ")\r\n");
                out2.flush();
                prectiPrikaz();
                break;
            }
            case 500: {
                out2.write(i + " NEZNAMY PRIKAZ\r\n");
                out2.flush();
                prectiPrikaz();
                break;
            }
            case 530: {
                out2.write(i + " HAVARIE\r\n");
                out2.flush();
                konec();
                break;
            }
            case 550: {
                out2.write(i + " NELZE ZVEDNOUT ZNACKU\r\n");
                out2.flush();
                konec();
                break;
            }
            case 570: {
                out2.write(i + " PORUCHA BLOK " + porouchanyBlok + "\r\n");
                out2.flush();
                prectiPrikaz();
                break;
            }
            case 571: {
                out2.write(i + " NENI PORUCHA\r\n");
                out2.flush();
                konec();
                break;
            }
            case 572: {
                out2.write(i + " ROBOT SE ROZPADL\r\n");
                out2.flush();
                konec();
                break;
            }
        }
    }

    private  void krok() {
        if(porucha==false){
        if(! porouchany()){
        souradnice.x += smer.x;
        souradnice.y += smer.y;
        System.out.println("souradnice= " + souradnice.x + " " + souradnice.y);

        if (souradnice.x > 17 || souradnice.x < -17 || souradnice.y > 17 || souradnice.y < -17) {
            posli(530);

        } else {
            posli(250);
        }
        }
        else posli(570);
    }
        else{
        posli(572);
        }
    }

    private  void vlevo() {
        if (smer.x == 0 && smer.y == 1) {
            smer.x = -1;
            smer.y = 0;
        } else if (smer.x == -1 && smer.y == 0) {
            smer.x = 0;
            smer.y = -1;
        } else if (smer.x == 0 && smer.y == -1) {
            smer.x = 1;
            smer.y = 0;
        } else if (smer.x == 1 && smer.y == 0) {
            smer.x = 0;
            smer.y = 1;
        }
         posli(250);
    }

    private  void opravit() {
         int o = prijataZprava.length() - 3;
         int prijatyBlok = Integer.parseInt(prijataZprava.substring(o,o+1));
          if (prijatyBlok<1||prijatyBlok>9) {posli(500);return;}
        if (porucha) {
           
            if (prijatyBlok == porouchanyBlok) {
                porucha = false;
                posli(250);
            }
        }
        posli(571);
    }

    private  void vyzvedni() {
        if (souradnice.x == 0 && souradnice.y == 0) {
            posli(221);

        } else {
            posli(550);
        }
    }

    private  void konec() {
        try {
            in2.close();
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        out2.close();       
    }

    public  boolean porouchany() {
        int tporucha = (int) (Math.random() * 10);
        if (tporucha == 5 || tporucha == 10 || okKroky == 10) {
            porucha = true;
            okKroky = 0;
            porouchanyBlok = (int) (Math.random() * 8 + 1);
            return true;
        }
        okKroky++;
        return false;
    }

    public  boolean kontrolaOsloveni() {
        System.out.println("Osloveni je: " + osloveni);
        int delkaVybranehoOsloveni = osloveni.length();
         if((prijataZprava.length())<=osloveni.length()) {
         return false;}
         else{
        String osloveniVeZprave = prijataZprava.substring(0, delkaVybranehoOsloveni);
        if (osloveniVeZprave.equals(osloveni)) {
            return true;
        } else {
            return false;
        }
    }
    }

    public  void zjisteniPrikazu() {
        if(!kontrolaOsloveni()) posli(500);
        else{
        System.out.println("[zjisteni prikazu] prijata zprava " + prijataZprava);
        System.out.println("[zjisteni prikazu] delka osloveni: " + osloveni.length());
        if((prijataZprava.length())<=osloveni.length()) posli(500);
        else{
        String prikaz = prijataZprava.substring(osloveni.length() + 1);
        char k = prikaz.charAt(0);
        System.out.println("znak je " + k);
        switch (k) {
            case 'K': {
                if (prijataZprava.length() == (osloveni.length() + 7)) {
                    krok();
                    System.out.println("krok");
                } else {
                    posli(500);
                }
                break;
            }
            case 'V': {
                if (prijataZprava.length() == (osloveni.length() + 8)) {
                    vlevo();
                    System.out.println("vlevo");
                } else {
                    posli(500);
                }
                break;
            }
            case 'O': {
                if (prijataZprava.length() == (osloveni.length() + 12)) {
                    opravit();
                    System.out.println("opravit");
                } else {
                    posli(571);
                }
                break;
            }
            case 'Z': {
                if (prijataZprava.length() == (osloveni.length() + 9)) {
                    vyzvedni();
                    System.out.println("zvedni");
                } else {
                    posli(550);
                }
                break;
            }

        }
        }
    }
    }

    public  void prectiPrikaz() {
        int znak;
        try {
            System.out.println("ctu prikaz");
            String precteno = "";
            StringBuffer buffer= new StringBuffer();
            buffer.append( this.inBuffer );
            this.inBuffer = "";
            char [] b = new char[1000];
            int index = 0;

            while ((znak = in2.read( b )) != -1) {
                buffer.append( b, 0, znak);
                if ( ( index = buffer.indexOf("\r\n") ) != -1 ) {
                    break;
                }
            }
            System.out.println("indexy: "+ index +" - "+ buffer.length() );
            if ( index != buffer.length() - 2 ) {
                System.out.println("schovavam do buferu: "+ index +" != "+ buffer.length() );
                this.inBuffer = buffer.substring(index+2);
            }
            precteno = buffer.substring(0, index) + "\r\n";
            if(precteno.length()>100) precteno=precteno.substring(0,100);
            if(precteno.equals("")){konec();}
            else prijataZprava = precteno;
            System.out.println(prijataZprava);
            zjisteniPrikazu();
        } catch (IOException ex){
           konec();
        }
    }
    public void run() {
        posli(220);
        prectiPrikaz();
    }
}
