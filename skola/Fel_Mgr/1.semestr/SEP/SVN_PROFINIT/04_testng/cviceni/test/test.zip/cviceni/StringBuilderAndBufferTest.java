package cviceni;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class StringBuilderAndBufferTest {
	static final int MAX = 10000;
	static final String appended = "ab";

    static StringBuilder builderAppend = new StringBuilder();
    static StringBuffer bufferAppend = new StringBuffer();
    
    static StringBuilder builderAppendDelete = new StringBuilder();
    static StringBuffer bufferAppendDelete = new StringBuffer();
    
    

    @Test(groups = "want", threadPoolSize = 4, invocationCount = MAX)
    public void testBuilderAppendDelete() {
        builderAppendDelete.append(appended);
        builderAppendDelete.delete(0, appended.length());
    }

    @Test(groups= "want", threadPoolSize = 4, invocationCount = MAX)
    public void testBufferAppendDelete() {
        bufferAppendDelete.append(appended);
        bufferAppendDelete.delete(0, appended.length());
    }


    @Test(groups = "want", threadPoolSize = 4, invocationCount = MAX)
    public void testBuilderAppend() {
        builderAppend.append(appended);
    }

    @Test(groups= "want", threadPoolSize = 4, invocationCount = MAX)
    public void testBufferAppend() {
        bufferAppend.append(appended);
    }

    @AfterClass(groups = {"want"})
    public void checkAppend() {
    	Assert.assertEquals(bufferAppend.toString().length(), MAX * appended.length());
        Assert.assertEquals(builderAppend.toString().length(), MAX * appended.length());

        for(int i = 0 ; i < MAX * appended.length() - 1 ; i ++){
        	Assert.assertNotEquals(bufferAppend.toString().charAt(i), bufferAppend.toString().charAt(i + 1));
        	Assert.assertNotEquals(builderAppend.toString().charAt(i), builderAppend.toString().charAt(i + 1));
        }
        
    }
    
    @AfterClass(groups = {"want"})
    public void checkAppendDelete(){
    	Assert.assertEquals(builderAppendDelete.toString().length(), 0);
        Assert.assertEquals(bufferAppendDelete.toString().length(), 0);
    }
    
    
}
