
import java.net.*;
import java.io.*;
import java.util.Random;

/**
 * @author woxie alias Martin Lukes         
 */
public class Server implements Runnable {

    /**
     * prichozi zprava
     */
    private String message = "";
    /**
     * Robot simulujici robota chodiciho po meste pro danou instanci Serveru
     */
    private Robot karel;
    private PrintWriter out = null;
    private BufferedReader in = null;
    private boolean breakFlag;
    private boolean continueFlag;
    /**
     * socket Clienta
     */
    private Socket client;
    private String nick = "Ty pekelny stroji Ty pekelny stroji Ty pekelny stroji";          //osloveni

    public static void main(String[] args) throws IOException {
        Socket clientSocket = null;
        //port na kterym Server nasloucha
        // int  port = Integer.decode(args[0]);
        int port = 3555;
        ServerSocket serverSocket = new ServerSocket(port);
        boolean isReady = true;

        while (isReady) {

            try {
                clientSocket = serverSocket.accept();
                clientSocket.setSoTimeout(600000);
                clientSocket.setTcpNoDelay(true);
            } catch (IOException e) {
                System.err.println("Accept failed.");
                System.exit(1);
            }
            System.out.println("client accepted from: " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());
            if (clientSocket != null) {
                Thread vlakno = new Thread(new Server(clientSocket));
                vlakno.start();
            }
            if (!isReady) {
                break;
            }
        }
        clientSocket.close();
        serverSocket.close();
    }

    public Server(Socket clientSocket) {
        this.client = clientSocket;
        breakFlag = false;
        continueFlag = false;
    }

    public void printAndSendCommand(String command) {
        System.out.println(command);
        out.print(command + "\r\n");
        out.flush();
    }

    public void printAndSendOk() {
        System.out.println("250 OK (" + karel.getEnergy() + "," + karel.getLocation() + ")");
        out.print("250 OK (" + karel.getEnergy() + "," + karel.getLocation() + ")\r\n");
        out.flush();
    }

    public boolean isRepairCommand(String message) {
        return (message.equals(nick + " OPRAVIT 1") || message.equals(nick + " OPRAVIT 2")
                || message.equals(nick + " OPRAVIT 3") || message.equals(nick + " OPRAVIT 4")
                || message.equals(nick + " OPRAVIT 5") || message.equals(nick + " OPRAVIT 6")
                || message.equals(nick + " OPRAVIT 7") || message.equals(nick + " OPRAVIT 8")
                || message.equals(nick + " OPRAVIT 9"));
    }

    public String readLn() {
        String incomingMessage = "";
        int nummerOfChar = -1;                       //cislo znaku

        boolean isRFound = false;                          //boolean znacici, jestli byl nalezen znak \r
        while (true) {
            try {
                nummerOfChar = in.read();
            } catch (Exception e) {
                System.out.println(e);
                return "";
            }
            if (nummerOfChar == -1) {
                break;
            }
            if (nummerOfChar == (int) '\r') {                   //\r objeven
                isRFound = true;
            } else if (nummerOfChar == (int) ('\n') && isRFound) {    //nasleduje-li \n
                break;
            } else {
                incomingMessage = incomingMessage + ((char) nummerOfChar);
                isRFound = false;
                if (incomingMessage.length() > 512) {
                    breakFlag = true;
                }
            }
        }
        return incomingMessage;
    }

    public boolean hasToFinishCycle() {
        if (breakFlag || continueFlag) {
            return false;
        }
        return true;
    }

    public void turnRobotLeft() {
        try {
            karel.turnLeft();
            printAndSendOk();
            continueFlag = true;
        } catch (RobotExhaustedException ex) {
            printAndSendCommand("540 BATERIE PRAZDNA ");
            breakFlag = true;
        }
    }

    public void doStepWithRobot() {
        try {
            karel.doStep();
        } catch (RobotExhaustedException ex) {
            printAndSendCommand("540 BATERIE PRAZDNA");
            breakFlag = true;
        } catch (RobotDestroyedException e) {
            printAndSendCommand("572 ROBOT SE ROZPADL");
            breakFlag = true;
        } catch (RobotBrokenException e) {
            printAndSendCommand("570 PORUCHA BLOK " + e.brokenBlock);
            continueFlag = true;
        }

        if(!hasToFinishCycle()){
            return;
        }
        
        if (karel.isInsideTheCity()) {
            printAndSendOk();
            continueFlag = true;
        } else {
            printAndSendCommand("530 HAVARIE");
            breakFlag = true;
        }
    }

    public void pickUpSignWithRobot() {
        if (karel.isAtZeroZero()) {   // pokud je na pocatku, vyzvedne tajemstvi
            printAndSendCommand("221 USPECH Vsichni milujeme progtest...");
            breakFlag = true;
        } else {
            printAndSendCommand("550 NELZE ZVEDNOUT ZNACKU");
            breakFlag = true;
        }
    }

    public void repairRobot() {
        if (karel.getBrokenBlock() == (int) message.charAt(message.length() - 1) - (int) '0') {
            printAndSendOk();
            karel.repair(karel.getBrokenBlock());
            continueFlag= true;
        } else {
            printAndSendCommand("571 NENI PORUCHA");
            breakFlag = true;
        }
    }

    public void chargeRobot(){
            try {
                    karel.reacharge();
                } catch (RobotBrokenException ex) {
                    printAndSendCommand("570 PORUCHA BLOK " + ex.brokenBlock);
                    continueFlag = true;
                } catch (RobotDestroyedException ex) {
                    printAndSendCommand("572 ROBOT SE ROZPADL");
                    breakFlag = true;
                }
            if(!hasToFinishCycle()){
                return;
            }
                printAndSendOk();
                continueFlag = true;
    }

    @Override
    public void run() {
        try {
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        } catch (IOException e) {
            System.err.println(e);
            System.exit(1);
        }
        karel = new Robot();

        printAndSendCommand("220 Dokazal jsi se pripojit, peklo zacalo. Oslovuj mne " + nick + ".");

        while (!breakFlag) {
            continueFlag = false;
            message = readLn();

            if (!hasToFinishCycle()) {
                continue;
            }
            System.out.println(message);

            if (message.equals(nick + " VLEVO") && !breakFlag) {
                turnRobotLeft();
            }
            if (!hasToFinishCycle()) {
                continue;
            }

            if (message.equals(nick + " KROK")) {
                doStepWithRobot();
            }

            if (!hasToFinishCycle()) {
                continue;
            }

            if ((message.equals(nick + " ZVEDNI"))) {
                pickUpSignWithRobot();
            }

            if (!hasToFinishCycle()) {
                continue;
            }

            if (isRepairCommand(message)) {
                repairRobot();
            }

            if (!hasToFinishCycle()) {
                continue;
            }

            if (message.equals(nick + " NABIT")) {
                chargeRobot();
            }
            
            if (!hasToFinishCycle()) {
                continue;
            }

            System.out.println(message);
            printAndSendCommand("500 NEZNAMY PRIKAZ");
        }
        out.close();
        try {
            in.close();
        } catch (IOException ex) {
        }
    }
}

/**
 * Exception vyvolana rozpadnutim robota
 * @author woxie
 */
class RobotDestroyedException extends Exception {

    public RobotDestroyedException() {
    }
}

/**
 * Exception vyvolana rozbitim robota
 * @author woxie
 */
class RobotBrokenException extends Exception {

    int brokenBlock;

    public RobotBrokenException(int block) {
        brokenBlock = block;
    }
}

/**
 * Exception vyvolana vybitim robota
 * @author woxie
 */
class RobotExhaustedException extends Exception {
}

/**
 *  Trida signalizujici, ze byla prekrocena maximalni delka zpravy
 * @author woxie
 */
class StringLongerThanBoundException extends Exception {
}

/**
 * Trida reprezentuje robota, ktery chodi po meste.
 * @author woxie
 */
class Robot {

    /** YPlusDirection */
    public static final int NORTH = 0;
    /** XPlusDirection */
    public static final int EAST = 3;
    /** YMinusDirection */
    public static final int SOUTH = 2;
    /** XMinusDirection */
    public static final int WEST = 1;
    /**
     * X-ova pozice robota
     */
    private int x;
    /**
     * Y-ova pozice robota
     */
    private int y;
    /**
     * Smer natoceni robota
     */
    private int dir;
    /**
     * pocet kroku, ktere robot vykonal
     */
    private int count = 0;
    /**
     * Flag znacici, jestli je robot znicen
     */
    private boolean broken = false;
    /**
     * Cislo naposledy porouchaneho bloku
     */
    private int brokenBlock = 0;
    /**
     * Robotova energie.
     */
    private int energy;

    /**
     * Konstruktor vytvori robota na nahodne pozici s energii 100.
     */
    public Robot() {
        Random r = new Random();             //random location
        x = r.nextInt(33) - 16;
        y = r.nextInt(33) - 16;
        dir = r.nextInt(4);
        energy = 100;
    }

    /**
     * Ziska robotovu pozici jako String
     * @return String znacici robotovu pozici
     */
    public String getLocation() {                       //vrati umisteni robota
        return x + "," + y;
    }

    /**
     * Otoci robota vlevo.
     */
    public void turnLeft() throws RobotExhaustedException {
        energy -= 10;
        if (isExhausted()) {
            throw new RobotExhaustedException();

        }
        dir = ((dir + 1) % 4);
    }

    /**
     * Opravi robotovi blok.
     * @param repairedBlock Opravovany blok
     */
    public void repair(int repairedBlock) {
        broken = false;
    }

    /**
     * Udela krok. Vyhodi vyjimku , pokud je robot znicen ( = pokud se rozpadl ) ci je porouchan.
     * @throws RobotDestroyedException vyjimka znaci, ze se robot rozpadl
     * @throws RobotBrokenException vyjimka znaci, ze se robot porouchal
     */
    public void doStep() throws RobotDestroyedException, RobotBrokenException, RobotExhaustedException {
        Random rand = new Random();
        if (broken) {
            throw new RobotDestroyedException();
        }

        int random = rand.nextInt(10);
        if (count == 10 || random == 5) {
            broken = true;
            brokenBlock = rand.nextInt(9) + 1;
            count = 0;
            throw new RobotBrokenException(brokenBlock);
        } else {
            energy -= 10;
            if (isExhausted()) {
                throw new RobotExhaustedException();

            }
            count++;
            switch (dir) {
                case NORTH:
                    y++;
                    break;
                case WEST:
                    x--;
                    break;
                case SOUTH:
                    y--;
                    break;
                case EAST:
                    x++;
                    break;
            }
        }
    }

    /**
     * Vrati blok, ktery se porouchal.
     * @return porouchany blok
     */
    public int getBrokenBlock() {
        return brokenBlock;
    }

    /**
     * Vrati hodnotu true, pokud je robot na pozici (0,0) jinak false
     * @return true, pokud je robot na pocatku, jinak false
     */
    public boolean isAtZeroZero() {
        if (y == 0 && x == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Vrati hodnotu true, pokud je robot v meste, jinak false.
     * @return true, pokud je robot uvnitr mesta, jinak false
     */
    public boolean isInsideTheCity() {
        if (y > 17 || x > 17 || y < -17 || x < -17) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Vrati robotovu energii
     * @return robotova energie
     */
    public int getEnergy() {
        return energy;
    }

    /**
     * Vrati true, pokud je robot bez stavy, jinak false
     * @return true, pokud je robot bez energie, jinak false
     */
    public boolean isExhausted() {
        if (energy <= 0) {
            return true;

        }
        return false;
    }

    /**
     * Znovu nabije robota.
     * @throws RobotBrokenException vyjimka vyhozena, pokud se robot poroucha pri nabijeni
     * @throws RobotDestroyedException vyjimka vyhozena, pokud je robot jiz porouchan a mel by se nabit.
     */
    public void reacharge() throws RobotBrokenException, RobotDestroyedException {
        if (broken) {
            throw new RobotDestroyedException();

        }
        Random r = new Random();
        int rand = r.nextInt(3);
        if (rand == 2) {
            energy = 1;
            broken = true;
            brokenBlock = r.nextInt(9) + 1;
            throw new RobotBrokenException(brokenBlock);
        }
        energy = 100;
    }
}
