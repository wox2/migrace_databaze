#include "printWorld.h"

void printWorld(){
	std::cout << "world!" << std::endl;
}
