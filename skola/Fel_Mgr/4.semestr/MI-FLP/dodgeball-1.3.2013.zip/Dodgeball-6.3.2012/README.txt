Rewrite the absolute paths in files aimaload.lisp and AIMA/aima.lisp to point to your instalation.

Other issues are addressed in file Rules.pdf and at the FAQ on course website edux.fit.cvut.cz/courses/MI-FLP
